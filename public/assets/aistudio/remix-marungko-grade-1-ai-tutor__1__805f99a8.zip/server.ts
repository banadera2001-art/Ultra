import express from 'express';
import path from 'path';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { evaluatePronunciationStrict, normalizeFilipinoTranscript } from './src/utils/pronunciationValidator';
import { censorProfanity } from './src/utils/profanityFilter';

/**
 * Convert 24kHz 16-bit Mono PCM buffer to Standard WAV Data URL
 */
function pcmToWav(pcmBase64: string, sampleRate = 24000, numChannels = 1): string {
  const pcmBuffer = Buffer.from(pcmBase64, 'base64');
  const wavHeader = Buffer.alloc(44);
  const dataLen = pcmBuffer.length;
  const fileLen = 36 + dataLen;

  wavHeader.write('RIFF', 0);
  wavHeader.writeUInt32LE(fileLen, 4);
  wavHeader.write('WAVE', 8);
  wavHeader.write('fmt ', 12);
  wavHeader.writeUInt32LE(16, 16);
  wavHeader.writeUInt16LE(1, 20); // PCM format
  wavHeader.writeUInt16LE(numChannels, 22);
  wavHeader.writeUInt32LE(sampleRate, 24);
  wavHeader.writeUInt32LE(sampleRate * numChannels * 2, 28);
  wavHeader.writeUInt16LE(numChannels * 2, 32);
  wavHeader.writeUInt16LE(16, 34); // 16-bit
  wavHeader.write('data', 36);
  wavHeader.writeUInt32LE(dataLen, 40);

  const wavBuffer = Buffer.concat([wavHeader, pcmBuffer]);
  return `data:audio/wav;base64,${wavBuffer.toString('base64')}`;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Cache for generated high-quality TTS audio
  const ttsCache = new Map<string, string>();

  // Middleware for parsing JSON bodies with high limit for canvas base64 images
  app.use(express.json({ limit: '20mb' }));

  // Environment keys
  const geminiApiKey = process.env.GEMINI_API_KEY;

  // Supported fast and multimodal Gemini models with verified uptime
  const GEMINI_MODELS = ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-flash-latest'];

  const ai = geminiApiKey
    ? new GoogleGenAI({
        apiKey: geminiApiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      })
    : null;

  // Helper to execute Gemini generation across available models with 12s timeout for vision
  async function callGeminiJson(contents: any): Promise<any | null> {
    if (!ai) return null;
    for (const modelName of GEMINI_MODELS) {
      try {
        const callPromise = ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('TIMEOUT')), 12000)
        );

        const response: any = await Promise.race([callPromise, timeoutPromise]);
        if (response && response.text) {
          const parsed = JSON.parse(response.text.trim());
          return parsed;
        }
      } catch (err: any) {
        console.warn(`[Gemini] model ${modelName} call failed:`, err?.message || err);
      }
    }
    return null;
  }

  // Multi-tier Groq API Key Pool with automatic failover on 429 rate limit or quota exhaustion
  // The first key is used primarily; if rate limited (429), it immediately rolls over to Groq 1, Groq 2, Groq 3, Groq 4
  const GROQ_API_KEYS: string[] = [
    process.env.GROQ_API_KEY || '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', // Primary / Default
    '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', // Groq 1
    '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', // Groq 2
    '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', // Groq 3
    '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', // Groq 4
  ].filter((k): k is string => Boolean(k && k.trim()));

  const groqApiKey = GROQ_API_KEYS[0] || '';
  const hasGroqKeys = GROQ_API_KEYS.length > 0;
  let activeGroqKeyIndex = 0;
  const groqKeyCooldowns = new Map<number, number>();

  // Rock-solid Groq models: Llama 3.3 70B & Llama 3.1 8B offer instant JSON formatting without status 400
  const GROQ_MODELS = [
    'llama-3.3-70b-versatile',
    'llama-3.1-8b-instant',
    'openai/gpt-oss-120b',
    'openai/gpt-oss-20b',
  ];

  async function callGroqJson(
    messages: Array<{ role: string; content: string }>,
    timeoutMs = 8000,
    maxTokens = 1500
  ): Promise<any | null> {
    if (GROQ_API_KEYS.length === 0) return null;
    const totalKeys = GROQ_API_KEYS.length;
    const now = Date.now();

    // Iterate through keys starting from current active key, switching to fallbacks if rate limited
    for (let keyOffset = 0; keyOffset < totalKeys; keyOffset++) {
      const keyIndex = (activeGroqKeyIndex + keyOffset) % totalKeys;
      const apiKey = GROQ_API_KEYS[keyIndex];
      if (!apiKey) continue;

      // Check if key is currently cooling down from a recent 429
      const cooldownUntil = groqKeyCooldowns.get(keyIndex) || 0;
      if (now < cooldownUntil && keyOffset < totalKeys - 1) {
        // Skip cooling key if other keys are available in the fallback pool
        continue;
      }

      // Try available models with this key
      for (const model of GROQ_MODELS) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), timeoutMs);

          // Prepend concise instruction to ensure direct JSON response
          const tunedMessages = messages.map((m, idx) => {
            if (idx === 0 && m.role === 'system') {
              return {
                ...m,
                content: `${m.content}\n\nIMPORTANT: Output strictly the valid JSON document without markdown code fences or conversational text.`,
              };
            }
            return m;
          });

          const requestBody: any = {
            model,
            messages: tunedMessages,
            response_format: { type: 'json_object' },
            temperature: 0.7,
            max_completion_tokens: maxTokens,
          };

          // Enforce minimal reasoning tokens (drops reasoning from ~220 tokens down to ~15 tokens)
          if (model.includes('gpt-oss')) {
            requestBody.reasoning_effort = 'low';
          }

          const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            signal: controller.signal,
            headers: {
              'Authorization': `Bearer ${apiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody),
          });
          clearTimeout(timeout);

          if (res.ok) {
            const data = await res.json();
            const content = data?.choices?.[0]?.message?.content;
            if (content) {
              let cleaned = content.trim();
              if (cleaned.startsWith('```json')) cleaned = cleaned.replace(/^```json\s*/i, '').replace(/\s*```$/, '');
              else if (cleaned.startsWith('```')) cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
              const parsed = JSON.parse(cleaned.trim());

              // Successful response: persist this key as the active key and clear any cooldown
              activeGroqKeyIndex = keyIndex;
              groqKeyCooldowns.delete(keyIndex);
              return parsed;
            }
          } else if (res.status === 429) {
            console.warn(`[Groq AI] Key #${keyIndex + 1} (${apiKey.substring(0, 10)}...) hit 429 rate limit on model ${model}. Switching to next fallback Groq key...`);
            // Mark 45-second cooldown on this key
            groqKeyCooldowns.set(keyIndex, Date.now() + 45000);
            // Move active index to next key in pool
            activeGroqKeyIndex = (keyIndex + 1) % totalKeys;
            // Break from model loop to immediately try the next key in the pool
            break;
          } else {
            const errText = await res.text();
            console.warn(`[Groq AI] Key #${keyIndex + 1} model ${model} returned status ${res.status}:`, errText.slice(0, 150));
            if (res.status === 401 || res.status === 403) {
              // Authentication error: put on longer cooldown and advance key
              groqKeyCooldowns.set(keyIndex, Date.now() + 300000);
              activeGroqKeyIndex = (keyIndex + 1) % totalKeys;
              break;
            }
            continue;
          }
        } catch (err: any) {
          console.warn(`[Groq AI] Key #${keyIndex + 1} model ${model} call failed:`, err?.message || err);
        }
      }
    }
    return null;
  }

  // Helper to normalize text for natural Tagalog and English TTS pronunciation
  // Prevents acronym spelling and ensures authentic Grade 1 Filipino vowel sounds (A as "Ah", I as "Ih")
  function normalizeTtsText(rawText: string): string {
    if (!rawText) return '';
    let text = rawText.trim();

    // 1. Strip outer slashes /.../ or brackets [...] without deleting the word inside
    text = text.replace(/^\/+|\/+$/g, '');
    text = text.replace(/^\[+|\]+$/g, '');

    // 2. Strip quotes, backticks, asterisks, and emojis
    text = text.replace(/["'“”‘’`*]/g, '');
    text = text.replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}]/gu, '');

    // 3. Remove hyphens within words (e.g. "ba-gay" -> "bagay", "pag-ka-ka-i-sa" -> "pagkakaisa")
    text = text.replace(/\b([a-zA-Z]+)-([a-zA-Z]+)\b/g, '$1$2');
    text = text.replace(/\b([a-zA-Z]+)-([a-zA-Z]+)-([a-zA-Z]+)\b/g, '$1$2$3');

    // 4. Convert all-caps words to lowercase so TTS engines pronounce words instead of spelling acronyms
    text = text.toLowerCase();

    // 5. Authentic Filipino Vowel Pronunciation Fix
    // Single Latin 'a' is pronounced "ey" in English TTS and single 'i' is pronounced "ay".
    // Transform single vowels and syllable guides to true phonetic sounds:
    if (text === 'a') return 'ah';
    if (text === 'i') return 'ih';
    if (text === 'e') return 'eh';
    if (text === 'o') return 'oh';
    if (text === 'u') return 'oo';

    text = text.replace(/\b(titik|letra|tunog|letrang)\s+a\b/gi, '$1 ah');
    text = text.replace(/\b(titik|letra|tunog|letrang)\s+i\b/gi, '$1 ih');
    text = text.replace(/\b(titik|letra|tunog|letrang)\s+e\b/gi, '$1 eh');
    text = text.replace(/\b(titik|letra|tunog|letrang)\s+o\b/gi, '$1 oh');
    text = text.replace(/\b(titik|letra|tunog|letrang)\s+u\b/gi, '$1 oo');

    text = text.replace(/\ba\s*[\+\-]\s*/g, 'ah ');
    text = text.replace(/\bi\s*[\+\-]\s*/g, 'ih ');

    text = text.replace(/\ba\b/g, 'ah');
    text = text.replace(/\bi\b/g, 'ih');

    return text.trim();
  }

  // --- Health Check ---
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: Date.now() });
  });

  // --- API ROUTE: Free, Unlimited & Fluent Tagalog and English Text-to-Speech (TTS) ---
  app.post('/api/ai/tts', async (req, res) => {
    try {
      const { text, lang = 'tl' } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: 'Missing text parameter' });
      }

      const trimmedText = text.trim();
      const speechText = normalizeTtsText(trimmedText);
      const isEnglish = lang === 'en' || lang === 'english';
      const targetLang = isEnglish ? 'en' : 'tl';
      const cacheKey = `${targetLang}:${speechText.toLowerCase()}`;

      // 1. Return immediately from server memory cache if available
      if (ttsCache.has(cacheKey)) {
        return res.json({ audioUrl: ttsCache.get(cacheKey) });
      }

      // 2. High-Fidelity, Free & Unlimited Native TTS (Filipino & English Neural Voice)
      try {
        const googleTtsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${targetLang}&q=${encodeURIComponent(speechText)}`;
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2000);
        const googleRes = await fetch(googleTtsUrl, {
          signal: controller.signal,
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            Referer: 'https://translate.google.com/',
          },
        });
        clearTimeout(timeoutId);

        if (googleRes.ok) {
          const arrayBuf = await googleRes.arrayBuffer();
          const base64Mp3 = Buffer.from(arrayBuf).toString('base64');
          const audioUrl = `data:audio/mp3;base64,${base64Mp3}`;

          // Keep bounded LRU cache
          if (ttsCache.size > 500) {
            const firstKey = ttsCache.keys().next().value;
            if (firstKey) ttsCache.delete(firstKey);
          }
          ttsCache.set(cacheKey, audioUrl);
          return res.json({ audioUrl });
        }
      } catch (googleErr) {
        // Fall through to browser Web Speech API
      }

      // 3. Return null immediately so client uses browser Web Speech synthesis with zero latency
      return res.json({ audioUrl: null });
    } catch (err) {
      console.error('TTS endpoint error:', err);
      res.status(500).json({ error: 'Failed to generate speech' });
    }
  });

  // --- API ROUTE 1: Evaluate Reading ---
  app.post('/api/ai/evaluate-reading', async (req, res) => {
    try {
      const { targetText, spokenTranscript, category } = req.body;

      if (!targetText) {
        return res.status(400).json({ error: 'Missing targetText parameter' });
      }

      // Step 1: Normalize transcript for Filipino phonology and E/I, O/U vowel sensitivity
      const normalizedSpoken = normalizeFilipinoTranscript(
        String(spokenTranscript || ''),
        String(targetText)
      );

      // Step 2: Run strict deterministic phonetics validator
      const strictResult = evaluatePronunciationStrict(
        String(targetText),
        normalizedSpoken,
        category || 'word'
      );

      // Return strict phonetic result immediately in under 1ms for BOTH correct and wrong answers!
      // This eliminates the 30-second delay for wrong answers and avoids Gemini quota errors completely.
      return res.json({
        isCorrect: strictResult.isCorrect,
        score: strictResult.score,
        transcription: spokenTranscript || '(walang narinig)',
        normalizedSpoken: strictResult.normalizedSpoken || targetText,
        feedbackTagalog: strictResult.feedbackTagalog,
        correctionTips: strictResult.correctionTips,
      });
    } catch (err) {
      console.error('Reading API Error:', err);
      res.status(500).json({ error: 'Internal server error evaluating reading' });
    }
  });

  // --- API ROUTE 2: Evaluate Writing ---
  app.post('/api/ai/evaluate-writing', async (req, res) => {
    try {
      const { imageBase64, targetText, guideType, strokeData } = req.body;

      if (!imageBase64 || !targetText) {
        return res.status(400).json({ error: 'Missing imageBase64 or targetText' });
      }

      // Fast check: if stroke data indicates empty or negligible stroke (< 50 pixels)
      const pixelCount = strokeData?.pixelCount ?? 200;
      const strokeCount = strokeData?.strokeCount ?? 1;

      if (pixelCount < 50 || strokeCount === 0) {
        return res.json({
          isCorrect: false,
          score: 1,
          feedbackTagalog: `Wala ka pang naisusulat sa canvas. Gamitin ang mouse upang isulat ang "${targetText}".`,
          correctionTips: [
            'Gamitin ang mouse upang sundan ang hugis ng letra sa pagitan ng mga linya bago pindutin ang Isubmit.',
            'Siguraduhing malinaw ang bawat guhit.',
          ],
          detailedAnalysis: {
            alignmentScore: 1,
            sizingScore: 1,
            legibilityScore: 1,
          },
        });
      }

      // Extract raw base64 data
      const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

      // Attempt fast Gemini vision evaluation
      if (ai) {
        try {
          const imagePart = {
            inlineData: {
              mimeType: 'image/png',
              data: base64Data,
            },
          };

          const promptPart = {
            text: `
You are a warm, supportive Grade 1 Elementary Teacher in the Philippines evaluating a 6-year-old child's handwritten letter/word on notebook guidelines.
Target letter or word to write: "${targetText}".

Examine the child's handwritten ink strokes in the image:
1. DETECT IF BLANK:
   - If the canvas is blank or contains only horizontal lines without student drawing: isCorrect MUST BE FALSE, score: 1.
2. RECOGNIZE THE WRITING (ALLOW FOR GRADE 1 SKILLS):
   - Children use a computer mouse or touch screen. Strokes will naturally be wobbly, thick, imperfect, or slightly off the line.
   - If the child drew strokes that reasonably form or resemble "${targetText}" (upper or lower case): isCorrect MUST BE TRUE, score: 5!
   - Only mark isCorrect: false (score: 2) if they drew an entirely different letter (e.g. wrote 'B' or 'O' when asked for '${targetText}') or random unreadable scribbles.
3. WARM TAGALOG FEEDBACK:
   - If correct: Warmly praise them in Tagalog (e.g., "Napakagaling! Matagumpay mong naisulat ang '${targetText}'!").
   - If incorrect: Kindly tell them what letter was expected and encourage them to try again.

Respond strictly in JSON format:
{
  "isCorrect": boolean,
  "score": number,
  "recognizedText": string,
  "feedbackTagalog": "warm Tagalog feedback",
  "correctionTips": ["friendly tip in Tagalog"],
  "detailedAnalysis": {
    "alignmentScore": number,
    "sizingScore": number,
    "legibilityScore": number
  }
}
`,
          };

          const parsed = await callGeminiJson({ parts: [imagePart, promptPart] });
          if (parsed && typeof parsed.isCorrect === 'boolean') {
            const tgt = targetText.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            const rec = typeof parsed.recognizedText === 'string'
              ? parsed.recognizedText.trim().toLowerCase().replace(/[^a-z0-9]/g, '')
              : '';

            // If the model recognized an entirely different letter/word, flag as incorrect
            if (rec && tgt && rec.length > 0 && !rec.includes(tgt) && !tgt.includes(rec) && rec !== 'hindimalinaw' && rec !== 'walangsulat') {
              // Only override if the recognized text is a completely different letter
              if (rec.length <= 3 && !tgt.startsWith(rec.charAt(0))) {
                parsed.isCorrect = false;
                parsed.score = 2;
                parsed.feedbackTagalog = `Maaari pang pagandahin ang sulat. Ang nakita ay "${parsed.recognizedText}", ngunit ang kailangan ay "${targetText}". Subukan muli!`;
              }
            }

            if (parsed.isCorrect) {
              parsed.score = 5;
              if (!parsed.feedbackTagalog) {
                parsed.feedbackTagalog = `Napakagaling! Matagumpay mong naisulat ang "${targetText}". ⭐ +10 Bituin!`;
              }
            } else {
              parsed.score = parsed.score ? Math.min(parsed.score, 2) : 2;
              if (!parsed.feedbackTagalog) {
                parsed.feedbackTagalog = `Maaari pang pagandahin ang sulat para sa "${targetText}". Sundan ang gabay sa loob ng mga linya.`;
              }
            }

            return res.json(parsed);
          }
        } catch (genErr) {
          console.warn('Gemini vision writing error:', genErr);
        }
      }

      // Safe Fallback when vision model cannot verify: DO NOT assume correct!
      return res.json({
        isCorrect: false,
        score: 2,
        feedbackTagalog: `Hindi mabasa nang malinaw ang iyong isinulat na "${targetText}". Pakisulat muli nang mas malinaw sa loob ng mga linya.`,
        correctionTips: [
          'Gamitin ang mouse upang sundan nang buo ang hugis ng letra.',
          'Panatilihing nasa pagitan ng asul at pulang linya ang mga letra.',
        ],
        detailedAnalysis: {
          alignmentScore: 2,
          sizingScore: 2,
          legibilityScore: 2,
        },
      });
    } catch (err) {
      console.error('Writing API Error:', err);
      res.status(500).json({ error: 'Internal server error evaluating writing' });
    }
  });

  // --- API ROUTE 3: Evaluate Math ---
  app.post('/api/ai/evaluate-math', async (req, res) => {
    try {
      const { imageBase64, num1, num2, operation, expectedAnswer, strokeData } = req.body;

      if (!imageBase64 || expectedAnswer === undefined) {
        return res.status(400).json({ error: 'Missing imageBase64 or expectedAnswer' });
      }

      const pixelCount = strokeData?.pixelCount ?? 150;
      const strokeCount = strokeData?.strokeCount ?? 1;

      // Check if student left canvas blank
      if (pixelCount < 50 || strokeCount === 0) {
        return res.json({
          isCorrect: false,
          score: 1,
          recognizedText: 'walang sulat',
          feedbackTagalog: `Wala ka pang naisusulat na numero sa canvas. Gamitin ang mouse upang isulat ang iyong sagot para sa ${num1} ${operation} ${num2}.`,
          correctionTips: [
            'Gamitin ang mouse upang isulat ang iyong sagot sa loob ng kahon.',
            'Kapag nakasulat na, pindutin ang Isubmit ang Sagot.',
          ],
        });
      }

      const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

      if (ai) {
        try {
          const imagePart = {
            inlineData: {
              mimeType: 'image/png',
              data: base64Data,
            },
          };

          const promptPart = {
            text: `
You are an encouraging Elementary Math Teacher in the Philippines evaluating a student's mouse-written or finger-drawn answer.
The math problem given to the student is: ${num1} ${operation} ${num2} = ?
The correct expected answer is: ${expectedAnswer}.

The image contains handwritten strokes drawn by an elementary school student using a computer mouse or touchscreen on a solid white canvas.
STUDENT MOUSE-DRAWING RECOGNITION RULES:
1. Mouse drawing can be shaky, uneven, wobbly, or have disjointed strokes. Look at the whole glyph to identify the intended digit or number.
2. Read the handwritten number from left to right. It can be a single digit (e.g. 5, 8, 0) or multiple digits (e.g. 12, 25, 100, 250).
3. Be forgiving of curved tails or mouse jitter. If the strokes resemble ${expectedAnswer}:
   - recognizedText: "${expectedAnswer}"
   - isCorrect: true
   - score: 5
   - feedbackTagalog: "Tumpak at napakagaling! Ang sagot sa ${num1} ${operation} ${num2} ay ${expectedAnswer}!"
   - correctionTips: ["Magaling! Ipagpatuloy ang ganyang husay sa matematika."]
4. If the student clearly wrote a DIFFERENT number (e.g., student wrote 7 or 20 instead of ${expectedAnswer}):
   - recognizedText: "<the number actually written>"
   - isCorrect: false
   - score: 2
   - feedbackTagalog: "Mali ang sagot. Ang isinulat mong numero ay <the number actually written>, ngunit ang tamang sagot sa ${num1} ${operation} ${num2} ay ${expectedAnswer}."
   - correctionTips: ["Subukang suriin muli ang iyong pagkalkula upang makuha ang ${expectedAnswer}."]
5. If the canvas is an unrecognizable scribble or empty:
   - recognizedText: "Hindi mabasa"
   - isCorrect: false
   - score: 1
   - feedbackTagalog: "Hindi mabasa nang malinaw ang numero sa canvas. Ang tamang sagot sa ${num1} ${operation} ${num2} ay ${expectedAnswer}. Pakisulat muli nang mas malinaw ang numero gamit ang mouse."
   - correctionTips: ["Isulat muli ang tamang numero sa loob ng kahon gamit ang mouse."]

Return STRICTLY a JSON object:
{
  "isCorrect": boolean,
  "score": number,
  "recognizedText": string,
  "feedbackTagalog": string,
  "correctionTips": string[]
}
`,
          };

          const parsed = await callGeminiJson({ parts: [imagePart, promptPart] });

          if (parsed && typeof parsed.isCorrect === 'boolean') {
            if (typeof parsed.recognizedText === 'string') {
              const cleanedDigits = parsed.recognizedText.replace(/[^0-9]/g, '');
              if (cleanedDigits !== '') {
                parsed.recognizedText = cleanedDigits;
                if (Number(cleanedDigits) === Number(expectedAnswer)) {
                  parsed.isCorrect = true;
                  parsed.score = 5;
                  parsed.feedbackTagalog = `Tumpak at napakagaling! Ang sagot sa ${num1} ${operation} ${num2} ay ${expectedAnswer}!`;
                } else {
                  parsed.isCorrect = false;
                  parsed.score = 2;
                  parsed.feedbackTagalog = `Mali ang sagot. Ang isinulat mong numero ay ${cleanedDigits}, ngunit ang tamang sagot sa ${num1} ${operation} ${num2} ay ${expectedAnswer}.`;
                }
              }
            }
            return res.json(parsed);
          }
        } catch (genErr) {
          console.warn('Gemini math vision error:', genErr);
        }
      }

      // Safe Fallback: NEVER mark unverified or wrong answer as correct!
      return res.json({
        isCorrect: false,
        score: 2,
        recognizedText: 'hindi matukoy',
        feedbackTagalog: `Hindi matukoy ng AI ang isinulat mong numero para sa ${num1} ${operation} ${num2}. Ang tamang sagot ay ${expectedAnswer}. Pakisulat muli nang mas malinaw gamit ang mouse.`,
        correctionTips: ['Isulat nang mas malinaw ang tamang numero sa loob ng kahon.'],
      });
    } catch (err) {
      console.error('Math API Error:', err);
      res.status(500).json({ error: 'Internal server error evaluating math' });
    }
  });

  // --- DIVERSE CURRICULUM TOPIC DOMAINS (DepEd ARAL Program: Grades 4 to 6 Reading & Math ONLY) ---
  const DIVERSE_CURRICULUM_DOMAINS: {
    subject: string;
    topicCategory: string;
    themePrompt: string;
    minGrade: number;
    maxGrade: number;
  }[] = [
    // FILIPINO READING (DEPED ARAL PROGRAM)
    {
      subject: 'filipino',
      topicCategory: 'Talasalitaan at Kasingkahulugan/Kasalungat',
      themePrompt: 'Pagtukoy sa kasingkahulugan o kasalungat ng mga salitang akademiko mula sa DepEd ARAL workbook (hal. masigasig, dalubhasa, katatagan, nagpupunyagi, kasarinlan, soberanya).',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'filipino',
      topicCategory: 'Sawikain at Matatalinghagang Pahayag',
      themePrompt: 'Kahulugan ng mga sawikain at idyoma mula sa ARAL workbook tulad ng "bukas-palad", "kapit-bisig", "matalas ang isip", "bukal sa loob", "balat-sibuyas", "nagbibilang ng poste".',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'filipino',
      topicCategory: 'Pang-unawa sa Binasa (Kuwento at Sanaysay)',
      themePrompt: 'Maikling 2-3 pangungusap na talata tungkol sa pambansang bayani, kalikasan, o pamayanan, na may tanong sa pangunahing ideya o aral ng binasa.',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'filipino',
      topicCategory: 'Sanhi at Bunga (Cause & Effect)',
      themePrompt: 'Pagsusuri sa ugnayan ng sanhi at bunga sa mga pangyayari at sitwasyon sa lipunan at kalikasan (hal. pagbaha dahil sa pagpuputol ng puno).',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'filipino',
      topicCategory: 'Katotohanan o Opinyon',
      themePrompt: 'Pagtukoy kung ang pahayag ay isang napatunayang katotohanan (fact) o isang personal na opinyon/paniniwala.',
      minGrade: 4,
      maxGrade: 6,
    },

    // ENGLISH READING (DEPED ARAL PROGRAM)
    {
      subject: 'english',
      topicCategory: 'Vocabulary & Context Clues',
      themePrompt: 'Determining the meaning of Key Stage 2 vocabulary words in context (e.g., perseverance, sanctuary, biodiversity, renewable, sustainable, equilibrium).',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'english',
      topicCategory: 'Reading Comprehension Passages',
      themePrompt: 'Short 2-3 sentence informational or narrative passage with a comprehension question on main idea, inference, or author purpose.',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'english',
      topicCategory: 'Idioms & Figurative Language',
      themePrompt: 'Common idioms, similes, and metaphors from the ARAL workbook (e.g., "piece of cake", "break the ice", "burn the midnight oil", "cost an arm and a leg").',
      minGrade: 4,
      maxGrade: 6,
    },

    // MATHEMATICS (DEPED ARAL PROGRAM - ELEMENTARY GRADES 4 TO 6)
    {
      subject: 'math',
      topicCategory: 'Elementary Operations & Daily Life Word Problems',
      themePrompt: 'Friendly Grade 4-6 elementary real-world word problems: daily market shopping in pesos (e.g. ₱150 + ₱75), simple multiplication (e.g. 15 mangoes in 4 boxes), and division (e.g. 48 cookies divided among 6 friends). NO complex formulas.',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'math',
      topicCategory: 'Elementary Fractions & Money Decimals',
      themePrompt: 'Simple elementary fractions with easy numbers (e.g. 1/4 + 2/4 = 3/4, or 1/2 of 20 = 10) and everyday peso decimal additions (e.g. ₱20.50 + ₱10.25). Absolutely NO difficult algebra.',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'math',
      topicCategory: 'Perimeter & Simple Area',
      themePrompt: 'Elementary rectangle perimeter and area using small whole numbers (e.g. garden with length 6m and width 4m: perimeter = 20m, area = 24 sq m).',
      minGrade: 4,
      maxGrade: 6,
    },
    {
      subject: 'math',
      topicCategory: 'Basic Order of Operations (No Exponents)',
      themePrompt: 'Elementary PEMDAS using strictly basic whole numbers with parentheses, addition, subtraction, multiplication, and division. NEVER use exponents, powers, or negative numbers (e.g. (10 + 5) × 2 = 30, or 25 - 4 × 5 = 5).',
      minGrade: 5,
      maxGrade: 6,
    },
    {
      subject: 'math',
      topicCategory: 'Elementary Percentages & Ratios',
      themePrompt: 'Elementary mental percentages and ratios using round numbers (e.g. 50% of ₱80 = ₱40, 10% of 100 = 10, or simple 1:2 ratio). NO negative numbers or complex algebra.',
      minGrade: 5,
      maxGrade: 6,
    },
  ];

  const SUBJECT_METADATA_MAP: Record<
    string,
    { label: string; tagalog: string; icon: string; color: string }
  > = {
    filipino: { label: 'Filipino Reading', tagalog: 'Basa at Talasalitaan - ARAL', icon: '🇵🇭', color: '#ef4444' },
    english: { label: 'English Reading', tagalog: 'English Reading - ARAL', icon: '📖', color: '#6366f1' },
    math: { label: 'Sipnayan (Math)', tagalog: 'Matematika - ARAL', icon: '📐', color: '#3b82f6' },
  };

  // --- API ROUTE 4: Generate Diverse, Non-Repeating DepEd ARAL Reading & Math Quiz Questions ---
  app.post('/api/ai/deped-quiz', async (req, res) => {
    try {
      const {
        gradeLevel = 'all',
        subject = 'all',
        customTopic = '',
        language = 'all',
        excludeQuestions = [],
        excludeTopics = [],
        lastSubject = null,
        count = 1,
      } = req.body;

      const requestedCount = Math.min(Math.max(1, Number(count) || 1), 3);
      const allCoreSubjects = ['filipino', 'english', 'math'];
      const trimmedCustomTopic = typeof customTopic === 'string' ? customTopic.trim() : '';

      // Step 1: Select distinct subjects for each requested question to prevent similar subject matter
      const selectedPlan: {
        subject: string;
        targetGrade: number;
        domain: (typeof DIVERSE_CURRICULUM_DOMAINS)[0];
        customTopic?: string;
      }[] = [];

      // Subjects used in this batch
      const batchUsedSubjects = new Set<string>();
      if (lastSubject && subject === 'all') {
        batchUsedSubjects.add(String(lastSubject).toLowerCase());
      }

      // Topics excluded
      const normalizedExcludedTopics = (Array.isArray(excludeTopics) ? excludeTopics : [])
        .map((t: string) => String(t).toLowerCase());

      // Questions excluded (to strictly forbid repeating identical or similar question stems)
      const normalizedExcludedQuestions = (Array.isArray(excludeQuestions) ? excludeQuestions : [])
        .map((q: string) => String(q).trim().toLowerCase())
        .filter((q: string) => q.length > 5);

      for (let i = 0; i < requestedCount; i++) {
        let qSubject = subject;
        if (subject === 'all') {
          // Find core subjects not yet used in this batch
          const candidateSubjects = allCoreSubjects.filter((s) => !batchUsedSubjects.has(s));
          if (candidateSubjects.length > 0) {
            qSubject = candidateSubjects[Math.floor(Math.random() * candidateSubjects.length)];
          } else {
            // If exhausted all, pick random
            qSubject = allCoreSubjects[Math.floor(Math.random() * allCoreSubjects.length)];
          }
          batchUsedSubjects.add(qSubject);
        }

        const qGrade =
          gradeLevel === 'all'
            ? Math.floor(Math.random() * 3) + 4
            : Math.min(6, Math.max(4, Number(gradeLevel) || 4));

        let pickedDomain: (typeof DIVERSE_CURRICULUM_DOMAINS)[0];

        // If user typed a custom topic, focus the domain strictly on the user's custom topic
        if (trimmedCustomTopic) {
          pickedDomain = {
            subject: qSubject === 'all' ? 'filipino' : qSubject,
            topicCategory: trimmedCustomTopic,
            themePrompt: `Specific DepEd ARAL Program Grade ${qGrade} learning competencies, vocabulary, comprehension questions, or math problems regarding "${trimmedCustomTopic}".`,
            minGrade: 4,
            maxGrade: 6,
          };
        } else {
          // Find domains matching this subject and grade level
          let matchingDomains = DIVERSE_CURRICULUM_DOMAINS.filter(
            (d) =>
              d.subject === qSubject &&
              qGrade >= d.minGrade &&
              qGrade <= d.maxGrade &&
              !normalizedExcludedTopics.some((et: string) =>
                d.topicCategory.toLowerCase().includes(et) || et.includes(d.topicCategory.toLowerCase())
              )
          );

          // Fallback to any domain in this subject if strict filter was too tight
          if (matchingDomains.length === 0) {
            matchingDomains = DIVERSE_CURRICULUM_DOMAINS.filter((d) => d.subject === qSubject);
          }

          // Absolute fallback to any domain in database
          if (matchingDomains.length === 0) {
            matchingDomains = DIVERSE_CURRICULUM_DOMAINS;
          }

          pickedDomain = matchingDomains[Math.floor(Math.random() * matchingDomains.length)];
        }

        selectedPlan.push({
          subject: qSubject,
          targetGrade: qGrade,
          domain: pickedDomain,
          customTopic: trimmedCustomTopic || undefined,
        });
      }

      const planDescriptions = selectedPlan
        .map(
          (p, idx) => `
QUESTION #${idx + 1} SPECIFICATIONS:
- Target Grade: Grade ${p.targetGrade} (Baitang ${p.targetGrade})
- Subject: ${p.subject.toUpperCase()} (${SUBJECT_METADATA_MAP[p.subject]?.label || p.subject})
- Mandatory Topic Category: "${p.domain.topicCategory}"
- Curriculum Theme & Context: ${p.domain.themePrompt}
${p.customTopic ? `*** CRITICAL USER CUSTOM TOPIC MANDATE: The user explicitly typed "${p.customTopic}". The question MUST test knowledge, scenarios, or interesting dilemmas specifically about "${p.customTopic}"! ***` : ''}
- Language: ${
  language === 'filipino'
    ? 'Strictly Natural, correct, standard Tagalog/Filipino language for the entire question, all 4 options, and explanation'
    : language === 'english'
    ? 'Strictly Clear, fluent English language for the entire question, all 4 options, and explanation'
    : ['filipino', 'ap', 'esp', 'epp'].includes(p.subject)
    ? 'Natural, correct Tagalog/Filipino'
    : 'Clear English (or Tagalog if covering Philippine folk culture)'
}
`
        )
        .join('\n');

      const systemPrompt = `You are Groq AI, an expert master teacher and curriculum writer for the Department of Education (DepEd) Philippines and Blox Fruits Game.
Your task is to generate ${requestedCount} completely distinct, creative, engaging multiple-choice question(s).

=== STRICT USER DIRECTIVES TO PREVENT PARAPHRASING AND REPETITION ===
1. ABSOLUTELY NO PARAPHRASING:
   - You MUST NOT reword, recycle, or paraphrase any question formulas or recent questions.
   - BANNED repetitive patterns:
     * DO NOT write "Alin sa mga sumusunod ang halimbawa ng..."
     * DO NOT write "What is the opposite/synonym of..."
     * DO NOT write simple arithmetic equations like "What is X + Y?"
     * DO NOT write "Alin ang pangngalan/pandiwa/pang-uri..."
   - Instead, construct an authentic, immersive question based on a real-world scenario, intriguing scientific phenomenon, historical mystery, practical daily decision, cultural dilemma, or logic puzzle!

2. TOTALLY DIFFERENT SUBJECT MATTER FOR EVERY QUESTION:
   - Every question MUST explore a completely different topic and cognitive challenge.
   - Do NOT generate questions on any of these recently asked questions or topics:
${normalizedExcludedQuestions.length > 0 ? normalizedExcludedQuestions.slice(-20).map((q: string, idx: number) => `   * Banned: "${q}"`).join('\n') : '   * (None yet - first question)'}
   - Excluded topics: ${normalizedExcludedTopics.length > 0 ? normalizedExcludedTopics.slice(-15).join(', ') : '(None)'}

3. ACCURACY & OPTIONS QUALITY:
   - Provide exactly 4 options. All 4 options must be plausible and well-written.
   - Exactly ONE option must be clearly and factually correct.
   - The "correctIndex" must be randomized (0, 1, 2, or 3).
   - The "explanation" must be encouraging, educational, and explain WHY the correct answer is right.

4. STRICT ELEMENTARY GRADE 4 TO 6 MATH DIFFICULTY MANDATE:
   - For ANY Math question: Keep problem difficulty STRICTLY appropriate for elementary pupils in Grades 4 to 6.
   - Ground problems in friendly, real-life elementary situations (e.g., market shopping in Philippine pesos, buying bread, sharing snacks among friends, simple rectangular garden perimeter/area, basic fractions like 1/2 or 3/4).
   - Problems must be solvable mentally or with quick scrap paper within 30 seconds.
   - ABSOLUTELY FORBIDDEN: High school algebra, variables (x, y), polynomials, exponents/powers (x^2), square roots, negative integers, or complex formulas. Keep numbers friendly and relatable!

RETURN STRICTLY A JSON OBJECT MATCHING THIS SCHEMA:
{
  "questions": [
    {
      "id": "groq-q-${Date.now()}-...",
      "gradeLevel": number,
      "subject": "filipino" | "english" | "math" | "science" | "ap" | "esp" | "epp" | "tle" | "mapeh",
      "subjectLabel": string,
      "subjectTagalog": string,
      "subjectIcon": string,
      "subjectColor": string,
      "topicCategory": string,
      "question": string,
      "options": string[],
      "correctIndex": number,
      "explanation": string,
      "bonusStars": number
    }
  ]
}`;

      const userPrompt = `Generate ${requestedCount} completely unique, non-repeating questions according to these specifications:\n${planDescriptions}`;

      // 1. Try Groq AI first for ultra-fast, creative, non-repeating generation
      if (groqApiKey) {
        try {
          const maxTokens = requestedCount === 1 ? 1400 : requestedCount === 2 ? 2200 : 2800;
          const groqResult = await callGroqJson([
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ], 8000, maxTokens);

          if (groqResult && Array.isArray(groqResult.questions) && groqResult.questions.length > 0) {
            const enrichedQuestions = groqResult.questions.map((q: any, idx: number) => {
              const assigned = selectedPlan[idx] || selectedPlan[0];
              const cleanSubject = String(q.subject || assigned.subject || 'science').toLowerCase().trim();
              const meta =
                SUBJECT_METADATA_MAP[cleanSubject] ||
                SUBJECT_METADATA_MAP[assigned.subject] ||
                SUBJECT_METADATA_MAP['science'];

              return {
                id: q.id || `groq-ai-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                gradeLevel: Number(q.gradeLevel) || assigned.targetGrade,
                subject: cleanSubject,
                subjectLabel: q.subjectLabel || meta.label,
                subjectTagalog: q.subjectTagalog || meta.tagalog,
                subjectIcon: q.subjectIcon || meta.icon,
                subjectColor: q.subjectColor || meta.color,
                topicCategory: q.topicCategory || assigned.domain.topicCategory,
                question: String(q.question).trim(),
                options: Array.isArray(q.options) && q.options.length === 4
                  ? q.options.map((o: any) => String(o).trim())
                  : ['Option A', 'Option B', 'Option C', 'Option D'],
                correctIndex: Math.min(3, Math.max(0, Number(q.correctIndex) || 0)),
                explanation: String(q.explanation || 'Tamang sagot batay sa DepEd Curriculum.').trim(),
                bonusStars: Number(q.bonusStars) || 50,
                aiSource: 'groq',
              };
            });

            return res.json({ success: true, questions: enrichedQuestions, source: 'groq' });
          }
        } catch (groqErr) {
          console.warn('[Groq AI] DepEd Quiz generation failed, falling back to Gemini:', groqErr);
        }
      }

      // 2. Fallback to Gemini if Groq is unavailable
      if (ai) {
        const geminiPrompt = `${systemPrompt}\n\n${userPrompt}`;
        for (const modelName of GEMINI_MODELS) {
          try {
            const resp = await ai.models.generateContent({
              model: modelName,
              contents: geminiPrompt,
              config: {
                responseMimeType: 'application/json',
                temperature: 1.05,
              },
            });

            if (resp && resp.text) {
              const parsed = JSON.parse(resp.text.trim());
              if (parsed && Array.isArray(parsed.questions) && parsed.questions.length > 0) {
                const enrichedQuestions = parsed.questions.map((q: any, idx: number) => {
                  const assigned = selectedPlan[idx] || selectedPlan[0];
                  const meta =
                    SUBJECT_METADATA_MAP[q.subject] ||
                    SUBJECT_METADATA_MAP[assigned.subject] ||
                    SUBJECT_METADATA_MAP['science'];

                  return {
                    id: q.id || `gemini-ai-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                    gradeLevel: Number(q.gradeLevel) || assigned.targetGrade,
                    subject: q.subject || assigned.subject,
                    subjectLabel: q.subjectLabel || meta.label,
                    subjectTagalog: q.subjectTagalog || meta.tagalog,
                    subjectIcon: q.subjectIcon || meta.icon,
                    subjectColor: q.subjectColor || meta.color,
                    topicCategory: q.topicCategory || assigned.domain.topicCategory,
                    question: String(q.question).trim(),
                    options: Array.isArray(q.options) && q.options.length === 4
                      ? q.options.map((o: any) => String(o).trim())
                      : ['Option A', 'Option B', 'Option C', 'Option D'],
                    correctIndex: Math.min(3, Math.max(0, Number(q.correctIndex) || 0)),
                    explanation: String(q.explanation || 'Tamang sagot batay sa DepEd Curriculum.').trim(),
                    bonusStars: Number(q.bonusStars) || 50,
                    aiSource: 'gemini',
                  };
                });

                return res.json({ success: true, questions: enrichedQuestions, source: 'gemini' });
              }
            }
          } catch (mErr: any) {
            console.warn(`[Gemini DepEd Quiz] ${modelName} failed:`, mErr?.message || mErr);
          }
        }
      }

      // Safe fallback when Gemini and Groq are offline
      return res.json({ success: false, questions: [], source: 'fallback' });
    } catch (err: any) {
      console.error('DepEd Quiz API Error:', err);
      res.status(500).json({ error: 'Failed to generate DepEd questions' });
    }
  });

  // --- API ROUTE 5: Alaga Pet Combat AI Challenge Generator (Reading & Math, Grade 1 to 6) ---
  app.post('/api/ai/combat-challenge', async (req, res) => {
    try {
      const {
        mode = 'reading', // 'reading' | 'math'
        gradeLevel = 1,   // 1 to 6
        excludeWords = [],
        excludeQuestions = [],
        count = 1,
      } = req.body;

      const grade = Math.min(6, Math.max(1, Number(gradeLevel) || 1));
      const requestedCount = Math.min(3, Math.max(1, Number(count) || 1));
      const normalizedExcludedWords = Array.isArray(excludeWords)
        ? excludeWords.map((w: any) => String(w).trim().toUpperCase())
        : [];
      const normalizedExcludedQuestions = Array.isArray(excludeQuestions)
        ? excludeQuestions.map((q: any) => String(q).trim().toLowerCase())
        : [];

      if (ai) {
        let systemPrompt = '';
        if (mode === 'english') {
          systemPrompt = `
You are an Elementary English Reading & Literacy Specialist.
Generate ${requestedCount} distinct, unique English reading word challenge(s) for Grade ${grade} elementary students.

CRITICAL NON-REPETITION MANDATE:
- ABSOLUTELY DO NOT use ANY of these previously asked words or recent words: ${normalizedExcludedWords.slice(-60).join(', ') || '(none yet)'}.
- NEVER repeat a word or reading sentence that was already presented.
- All words must be completely fresh, unique, and age-appropriate for Grade ${grade}:
  * Grade 1: Foundational English sight words & phonics CVC words (e.g. FAMILY, FRIEND, SUNSHINE, MORNING, WATER, GARDEN, LITTLE, SMILE, SCHOOL, BREAD, PENCIL, HAPPY).
  * Grade 2: 2-syllable familiar English vocabulary and nature words (e.g. KITCHEN, FLOWER, BASKET, WINDOW, BREAKFAST, BLANKET, MARKET, RAINBOW, SISTER, BROTHER).
  * Grade 3: 2-3 syllable daily life vocabulary and descriptive words (e.g. BEAUTIFUL, TOGETHER, HEALTHY, NEIGHBOR, CAREFUL, DELICIOUS, CLASSROOM, WEATHER, EXERCISE, PATIENT).
  * Grade 4: Multi-syllable vocabulary relating to community, nature, science, and cooperation (e.g. DISCOVER, COMMUNITY, ENVIRONMENT, ADVENTURE, CELEBRATION, COOPERATION, IMPORTANT, HARVEST).
  * Grade 5: Abstract & academic vocabulary, values, environment, and communication (e.g. RESPONSIBILITY, KNOWLEDGE, GENEROSITY, APPRECIATION, OPPORTUNITY, ECOSYSTEM, COMMUNICATION, NUTRITION).
  * Grade 6: Advanced vocabulary, civic concepts, leadership, and critical thinking (e.g. PERSEVERANCE, CIVILIZATION, PARTICIPATION, SUSTAINABLE, BIODIVERSITY, EXTRAORDINARY, DEMOCRACY, PERSPECTIVE).

For EACH challenge, return:
- "targetWord": Uppercase word to read (e.g. "TOGETHER")
- "syllables": Array of syllables (e.g. ["TO", "GETH", "ER"])
- "phoneticGuide": English pronunciation phonics guide (e.g. "tuh-GETH-er")
- "clue": Short, friendly clue in English (e.g. "With each other in a group or family")
- "readingPassage": A short natural sentence containing the word in daily life (e.g. "We clean our classroom together every morning.")
- "options": Exactly 4 unique choices (the targetWord and 3 plausible distractor words of similar length)
- "correctAnswer": The targetWord

RETURN STRICTLY A JSON OBJECT matching:
{
  "challenges": [
    {
      "mode": "english",
      "gradeLevel": ${grade},
      "targetWord": "...",
      "syllables": ["..."],
      "phoneticGuide": "...",
      "clue": "...",
      "readingPassage": "...",
      "options": ["...", "...", "...", "..."],
      "correctAnswer": "..."
    }
  ]
}
`;
        } else if (mode === 'reading') {
          systemPrompt = `
You are a DepEd Philippines Elementary Reading & Literacy Specialist.
Generate ${requestedCount} distinct, unique Filipino reading word challenge(s) for Grade ${grade} students in an RPG Pet Combat Game.

CRITICAL NON-REPETITION MANDATE:
- ABSOLUTELY DO NOT use ANY of these previously asked words or recent words: ${normalizedExcludedWords.slice(-60).join(', ') || '(none yet)'}.
- NEVER repeat a word or reading sentence that was already presented.
- All words must be completely fresh, unique, and age-appropriate for Grade ${grade}:
  * Grade 1: 2-3 syllable foundational Marungko/Filipino words (e.g. MATA, BATA, DAHON, ASO, PUSA, GATAS, TASA, BATO).
  * Grade 2: 2-3 syllable familiar Filipino words (e.g. KABAYO, BULAKLAK, MASAYA, KUBYERTO, SAPATOS, BANDILA, ULAN).
  * Grade 3: 3-4 syllable Filipino vocabulary and descriptive words (e.g. PANGARAP, KAPALIGIRAN, KASIPAGAN, MAGALANG, BAHAGHARI, TULAY).
  * Grade 4: Multi-syllable Filipino words relating to community, nature, and culture (e.g. KALIKASAN, KASAYSAYAN, PAGTUTULUNGAN, KAYAMANAN, PAMAYANAN, TAHIMIK).
  * Grade 5: Abstract & academic vocabulary, values, environment (e.g. PANGANGALAGA, RESPONSIBILIDAD, PAGPAPAHALAGA, KALUSUGAN, PAGKAKAIBIGAN, LIWANAG).
  * Grade 6: Advanced vocabulary, civic concepts, science & society (e.g. KATAPATAN, PAGKAKAISA, TEKNOLOHIYA, KARANGALAN, KALAYAAN, KATARUNGAN).

For EACH challenge, return:
- "targetWord": Uppercase word to read (e.g. "KALIKASAN")
- "syllables": Array of syllables (e.g. ["KA", "LI", "KA", "SAN"])
- "phoneticGuide": Baybay guide (e.g. "KA + LI + KA + SAN")
- "clue": Short, friendly clue in Tagalog (e.g. "Ang ating kapaligiran at mga halaman")
- "readingPassage": A short natural sentence containing the word (e.g. "Ingatan natin ang ating kalikasan.")
- "options": Exactly 4 unique choices (the targetWord and 3 plausible distractor words of similar length)
- "correctAnswer": The targetWord

RETURN STRICTLY A JSON OBJECT matching:
{
  "challenges": [
    {
      "mode": "reading",
      "gradeLevel": ${grade},
      "targetWord": "...",
      "syllables": ["..."],
      "phoneticGuide": "...",
      "clue": "...",
      "readingPassage": "...",
      "options": ["...", "...", "...", "..."],
      "correctAnswer": "..."
    }
  ]
}
`;
        } else {
          // mode === 'math' -> MUST BE IN ENGLISH AND GROUNDED IN REAL DAILY LIFE SITUATIONS
          systemPrompt = `
You are an Elementary Mathematics Teacher.
Generate ${requestedCount} unique, engaging math question(s) strictly tailored for Grade ${grade} elementary students.

CRITICAL LANGUAGE & REAL-LIFE MANDATES:
1. STRICTLY ENGLISH: All questions, explanations, options, and hints MUST BE IN ENGLISH.
2. REAL DAILY LIFE SITUATIONS ONLY: Every question MUST describe relatable, real-world human situations (grocery shopping, cooking, saving in a piggy bank, sharing snacks with siblings/friends, school supplies, time, gardening, baking, bus fares).
3. ABSOLUTELY NO GAME SITUATIONS OR MECHANICS: NEVER mention game HP, attacks, damage, monsters, dragons, battle stats, or video game items. Frame every problem around real everyday life!
4. CRITICAL NON-REPETITION MANDATE:
   - ABSOLUTELY DO NOT generate ANY questions identical or similar to these excluded items: ${normalizedExcludedQuestions.slice(-60).join('; ') || '(none yet)'}.
   - NEVER repeat a math question that was previously asked.

Curriculum by Grade Level:
- Grade 1: Daily life addition & subtraction within 20:
  * e.g. "Leo bought 7 red apples and 6 green apples at the fruit stand. How many apples did he buy in all?"
  * e.g. "Mother had 15 fresh eggs in a basket. She used 6 eggs to bake a cake. How many eggs are left?"
- Grade 2: 2-digit addition and subtraction within 100, basic skip counting & coin/peso savings:
  * e.g. "At the bakery, a box of pandesal costs ₱35 and a carton of milk costs ₱45. What is the total cost?"
  * e.g. "A school bus has 48 seats. If 26 students are already seated, how many seats are still empty?"
  * e.g. "Sarah has 5 small jars with 6 cookies in each jar. How many cookies does she have in total?"
- Grade 3: Multiplication tables (up to 10), basic division, simple fractions & sharing:
  * e.g. "Father bought 4 packs of juice boxes. Each pack contains 6 boxes. How many juice boxes are there in all?"
  * e.g. "Teacher Grace has 36 colored pencils to share equally among 4 students. How many pencils does each student receive?"
  * e.g. "A pizza is cut into 8 equal slices. If Mark and his sister eat 5 slices together, what fraction of the pizza was eaten?"
- Grade 4: Multi-digit daily expenses, sharing harvest, perimeter & volume of everyday objects:
  * e.g. "A farmer harvested 145 kilograms of rice on Monday and 180 kilograms on Tuesday. How many kilograms were harvested in total?"
  * e.g. "A rectangular vegetable garden is 8 meters long and 6 meters wide. What is the perimeter of the garden in meters?"
  * e.g. "A large pitcher contains 950 milliliters of water. If Ella pours 350 milliliters into a glass, how many milliliters of water remain?"
- Grade 5: Decimals in shopping, percentages (discounts/taxes), and fraction operations in cooking/recipes:
  * e.g. "A school backpack originally priced at ₱400 is on a 25% discount sale. How much is the discount in pesos?"
  * e.g. "Anna bought 2.5 kilograms of mangoes and 1.75 kilograms of bananas at the market. What is the total weight in kilograms?"
  * e.g. "A recipe calls for 3/4 cup of sugar, but Kevin only has 1/2 cup. How much more sugar does he need?"
- Grade 6: Real-world ratios, proportions, daily budget averages, and percentage problems:
  * e.g. "The ratio of boys to girls in a school choir is 2 to 3. If there are 10 boys, how many girls are in the choir?"
  * e.g. "Lucas saved ₱120 on Monday, ₱150 on Tuesday, and ₱180 on Wednesday. What is his average daily savings?"
  * e.g. "A water tank holds 250 liters when completely full. If the tank is currently 60% full, how many liters of water are inside?"

For EACH question, return:
- "mathQuestion": The complete word problem or equation strictly in English (e.g. "Mother bought 8 mangoes and 7 oranges. How many fruits did she buy in total?")
- "mathEmoji": A friendly daily-life emoji (e.g. "🍎", "🍞", "🥛", "✏️", "🚌", "🪴", "🍪", "🧺")
- "options": Exactly 4 unique answer choices with units where appropriate as strings (e.g. ["15 fruits", "14 fruits", "16 fruits", "13 fruits"])
- "correctAnswer": The exact correct choice string (e.g. "15 fruits")
- "correctIndex": Index (0, 1, 2, or 3) of the correct choice
- "explanation": Clear, friendly step-by-step solution in English
- "mathHint": Practical real-life tip or hint in English

RETURN STRICTLY A JSON OBJECT matching:
{
  "challenges": [
    {
      "mode": "math",
      "gradeLevel": ${grade},
      "mathQuestion": "...",
      "mathEmoji": "...",
      "options": ["...", "...", "...", "..."],
      "correctAnswer": "...",
      "correctIndex": 0,
      "explanation": "...",
      "mathHint": "..."
    }
  ]
}
`;
        }

        // 1. Try Groq AI first for ultra-fast generation (< 400ms)
        if (groqApiKey) {
          try {
            const maxTokens = requestedCount === 1 ? 1200 : 1800;
            const groqRes = await callGroqJson([
              { role: 'system', content: systemPrompt },
              { role: 'user', content: `Generate ${requestedCount} unique non-repeating ${mode} challenge(s) for Grade ${grade}.` },
            ], 6000, maxTokens);
            if (groqRes && Array.isArray(groqRes.challenges) && groqRes.challenges.length > 0) {
              return res.json({ success: true, challenges: groqRes.challenges, source: 'groq' });
            }
          } catch (gErr: any) {
            console.warn('[Groq Combat Challenge] failed:', gErr?.message || gErr);
          }
        }

        // 2. Fallback to Gemini
        for (const modelName of GEMINI_MODELS) {
          try {
            const resp = await ai.models.generateContent({
              model: modelName,
              contents: systemPrompt,
              config: {
                responseMimeType: 'application/json',
              },
            });

            if (resp && resp.text) {
              const parsed = JSON.parse(resp.text.trim());
              if (parsed && Array.isArray(parsed.challenges) && parsed.challenges.length > 0) {
                return res.json({ success: true, challenges: parsed.challenges, source: 'gemini' });
              }
            }
          } catch (mErr: any) {
            console.warn(`[Gemini Combat Challenge] ${modelName} failed:`, mErr?.message || mErr);
          }
        }
      }

      return res.json({ success: false, challenges: [], source: 'fallback' });
    } catch (err: any) {
      console.error('Combat Challenge API Error:', err);
      res.status(500).json({ error: 'Failed to generate combat challenge' });
    }
  });

  // --- API ROUTE 6: Live Reading Item Generator (Groq AI for Grades 4, 5, 6 - Filipino & English) ---
  app.post('/api/ai/live-reading', async (req, res) => {
    try {
      const rawGrade = req.body.gradeLevel ?? req.body.grade ?? 4;
      const language = req.body.language === 'english' ? 'english' : 'filipino';
      const mode = (req.body.mode === 'sentence' || req.body.category === 'sentence') ? 'sentence' : 'one_word';
      const excludeList = req.body.excludeList || req.body.excludeWords || [];

      const grade = Math.min(6, Math.max(4, Number(rawGrade) || 4));
      const excluded = (Array.isArray(excludeList) ? excludeList : [])
        .map((w: any) => String(w).trim().toLowerCase())
        .filter(Boolean);

      const systemPrompt = `You are a master DepEd ARAL Program Reading and Literacy Curriculum Specialist.
Your task is to generate 1 completely original, rich, age-appropriate reading item for Grade ${grade} elementary students.
Language: ${language === 'english' ? 'Clear Standard English' : 'Natural Filipino / Tagalog'}.
Format Mode: ${mode === 'one_word' ? '1 Single High-Vocabulary Word' : '1 Natural Complete Sentence (12-25 words)'}.

STRICT CURRICULUM RULES:
1. Target Audience: Key Stage 2 Grade ${grade} students in the Philippines.
2. Mode rules:
   - If "one_word": Provide 1 uppercase vocabulary word suitable for Grade ${grade}. Provide 3 COMPLETELY DIFFERENT plausible distractor words of similar length and grade level in the SAME language.
   - If "sentence": Provide 1 meaningful, inspiring, grammatically flawless sentence about daily life, values, community, science, or Philippine culture. Provide 3 COMPLETELY DIFFERENT plausible distractor sentences of similar length in the SAME language.
3. ANTI-REPETITION MANDATE:
   - You MUST NOT use ANY of these recently generated words or sentences:
${excluded.slice(-40).map((ex) => `     * Banned: "${ex}"`).join('\n') || '     * (None yet)'}
   - Output must be completely unique and creative!

OUTPUT JSON SCHEMA:
{
  "item": {
    "id": "groq-reading-${Date.now()}",
    "gradeLevel": ${grade},
    "language": "${language}",
    "category": "${mode}",
    "categoryLabel": "${mode === 'one_word' ? '1 Word Reading' : 'Sentence Reading'}",
    "text": "${mode === 'one_word' ? 'UPPERCASE WORD' : 'Complete sentence'}",
    "phoneticGuide": "phonetic / syllabic pronunciation guide",
    "tagalogGuide": "brief Tagalog meaning or context",
    "sampleSentence": "${mode === 'one_word' ? 'Example sentence using the word' : ''}",
    "distractors": ["Distractor 1", "Distractor 2", "Distractor 3"],
    "explanation": "Friendly encouraging explanation"
  }
}`;

      // Try Groq AI first for live instant generation
      if (groqApiKey) {
        try {
          const groqResult = await callGroqJson([
            { role: 'system', content: systemPrompt },
            {
              role: 'user',
              content: `Generate 1 fresh, non-repeating ${mode} reading challenge for Grade ${grade} in ${language}.`,
            },
          ], 7000, 1200);

          if (groqResult && groqResult.item && groqResult.item.text) {
            const itm = groqResult.item;
            // Guarantee 3 distractors
            if (!Array.isArray(itm.distractors) || itm.distractors.length < 3) {
              itm.distractors = [
                mode === 'one_word' ? (language === 'english' ? 'RESILIENT' : 'PAGKILALA') : (language === 'english' ? 'We work diligently to achieve our goals.' : 'Matiyaga tayong nag-aaral araw-araw.'),
                mode === 'one_word' ? (language === 'english' ? 'HARMONY' : 'KASAGANAAN') : (language === 'english' ? 'Sharing knowledge brings harmony to communities.' : 'Ang pagtutulungan ay nagbubunga ng tagumpay.'),
                mode === 'one_word' ? (language === 'english' ? 'DISCOVERY' : 'KATATAGAN') : (language === 'english' ? 'Protecting our forests is a common responsibility.' : 'Pangalagaan natin ang ating kalikasan at kapaligiran.'),
              ];
            }
            return res.json({ success: true, item: itm, source: 'groq' });
          }
        } catch (gErr: any) {
          console.warn('[Groq Live Reading] failed:', gErr?.message || gErr);
        }
      }

      // Fallback to Gemini if Groq is offline
      if (ai) {
        try {
          const geminiResp = await callGeminiJson({
            parts: [{ text: systemPrompt }, { text: `Generate 1 fresh reading item for Grade ${grade} in ${language}.` }],
          });
          if (geminiResp && geminiResp.item && geminiResp.item.text) {
            return res.json({ success: true, item: geminiResp.item, source: 'gemini' });
          }
        } catch (mErr: any) {
          console.warn('[Gemini Live Reading] failed:', mErr?.message || mErr);
        }
      }

      return res.json({ success: false, item: null, source: 'fallback' });
    } catch (err: any) {
      console.error('Live Reading API Error:', err);
      res.status(500).json({ error: 'Failed to generate live reading item' });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // =========================================================================
  // REAL-TIME MULTIPLAYER WEBSOCKET SERVER (Port 3000)
  // Channel 1: Alaga PvP Combat Arena (Room codes, 1-on-1 pet battle, 3 sets of alaga)
  // Channel 2: Blox Fruit 3D MMORPG World (3D players, PvP duels, damage, censored chat)
  // =========================================================================

  interface WsClientInfo {
    ws: WebSocket;
    alagaRoomCode?: string;
    alagaPlayerId?: string;
    bloxPlayerId?: string;
  }

  const wsClients = new Map<WebSocket, WsClientInfo>();

  // Blox Fruit 3D World state
  interface BloxWorldPlayer {
    id: string;
    name: string;
    gender: 'boy' | 'girl';
    level: number;
    fruitId: string;
    swordId: string;
    accessoryId: string;
    haki: boolean;
    x: number;
    y: number;
    z: number;
    rotationY: number;
    hp: number;
    maxHp: number;
    bounty: number;
    isMoving?: boolean;
    ws: WebSocket;
  }
  const bloxPlayers = new Map<string, BloxWorldPlayer>();

  // Alaga PvP Rooms state
  interface AlagaCombatant {
    petId: string;
    name: string;
    element: string;
    stage: string;
    level: number;
    maxHp: number;
    currentHp: number;
    isFainted: boolean;
    basicSkill: string;
    specialSkill: string;
  }

  interface AlagaRoomPlayerState {
    id: string;
    name: string;
    avatar: string;
    team: AlagaCombatant[];
    activePetIndex: number;
    isReady: boolean;
    score: number;
    ws: WebSocket;
  }

  interface AlagaRoomSession {
    code: string;
    players: Record<string, AlagaRoomPlayerState>;
    battleState: 'waiting' | 'ready' | 'battling' | 'finished';
    currentTurnPlayerId?: string;
    logs: string[];
    winnerPlayerId?: string;
  }

  const alagaRooms = new Map<string, AlagaRoomSession>();

  function sanitizeAlagaRoom(room: AlagaRoomSession) {
    const sanitizedPlayers: Record<string, any> = {};
    for (const [pId, p] of Object.entries(room.players)) {
      sanitizedPlayers[pId] = {
        id: p.id,
        name: p.name,
        avatar: p.avatar,
        team: p.team,
        activePetIndex: p.activePetIndex,
        isReady: p.isReady,
        score: p.score,
      };
    }
    return {
      code: room.code,
      players: sanitizedPlayers,
      battleState: room.battleState,
      currentTurnPlayerId: room.currentTurnPlayerId,
      logs: room.logs,
      winnerPlayerId: room.winnerPlayerId,
    };
  }

  function broadcastToAlagaRoom(code: string, event: string, data: any) {
    const room = alagaRooms.get(code);
    if (!room) return;
    const msg = JSON.stringify({ event, data });
    for (const p of Object.values(room.players)) {
      if (p.ws.readyState === WebSocket.OPEN) {
        try {
          p.ws.send(msg);
        } catch (e) {
          console.warn('[Alaga WS Send Error]:', e);
        }
      }
    }
  }

  function broadcastBlox(event: string, data: any, excludeWs?: WebSocket) {
    const msg = JSON.stringify({ event, data });
    for (const p of bloxPlayers.values()) {
      if (p.ws !== excludeWs && p.ws.readyState === WebSocket.OPEN) {
        try {
          p.ws.send(msg);
        } catch (e) {
          console.warn('[Blox WS Send Error]:', e);
        }
      }
    }
  }

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });

  wss.on('connection', (ws: WebSocket) => {
    wsClients.set(ws, { ws });

    ws.on('message', (messageRaw: any) => {
      try {
        const parsed = JSON.parse(messageRaw.toString());
        const { event, data } = parsed;
        const clientInfo = wsClients.get(ws);
        if (!clientInfo) return;

        // -------------------------------------------------------------
        // ALAGA PVP COMBAT ARENA EVENTS (Room Codes, 1v1, 3 Pets Team)
        // -------------------------------------------------------------
        if (event === 'alaga_join_room') {
          const rawCode = String(data?.code || '').trim().toUpperCase();
          if (!rawCode) return;

          const player = data.player;
          if (!player || !player.id) return;

          let room = alagaRooms.get(rawCode);
          if (!room) {
            room = {
              code: rawCode,
              players: {},
              battleState: 'waiting',
              logs: [`Binuo ang Arena Room: ${rawCode}`],
            };
            alagaRooms.set(rawCode, room);
          }

          // Check if room is full
          const playerIds = Object.keys(room.players);
          if (playerIds.length >= 2 && !room.players[player.id]) {
            ws.send(
              JSON.stringify({
                event: 'alaga_error',
                data: { message: `Puno na ang Room ${rawCode} (2/2 manlalaro).` },
              })
            );
            return;
          }

          // Ensure player has a team of 3 pets
          const rawTeam = Array.isArray(player.team) ? player.team : [];
          const cleanTeam: AlagaCombatant[] = rawTeam.slice(0, 3).map((pet: any, idx: number) => ({
            petId: pet.petId || `pet-${idx + 1}`,
            name: pet.name || `Alaga ${idx + 1}`,
            element: pet.element || 'fire',
            stage: pet.stage || 'Baby',
            level: Number(pet.level) || 1,
            maxHp: Number(pet.maxHp) || 100 + (Number(pet.level) || 1) * 20,
            currentHp: Number(pet.maxHp) || 100 + (Number(pet.level) || 1) * 20,
            isFainted: false,
            basicSkill: pet.basicSkill || 'Kagat',
            specialSkill: pet.specialSkill || 'Elemental Strike',
          }));

          // Fill up to 3 pets if student has fewer
          while (cleanTeam.length < 3) {
            const idx = cleanTeam.length;
            cleanTeam.push({
              petId: `backup-pet-${idx + 1}`,
              name: idx === 1 ? 'Bantay' : 'Muningsing',
              element: idx === 1 ? 'fire' : 'water',
              stage: 'Baby',
              level: 1,
              maxHp: 120,
              currentHp: 120,
              isFainted: false,
              basicSkill: 'Bilis ng Alaga',
              specialSkill: 'Tulong ng Kasama',
            });
          }

          room.players[player.id] = {
            id: player.id,
            name: player.name || 'Manlalaro',
            avatar: player.avatar || '🐾',
            team: cleanTeam,
            activePetIndex: 0,
            isReady: false,
            score: 0,
            ws,
          };

          clientInfo.alagaRoomCode = rawCode;
          clientInfo.alagaPlayerId = player.id;

          room.logs.push(`Pumasok si ${player.name} sa Arena.`);
          if (Object.keys(room.players).length === 2) {
            room.battleState = 'ready';
            room.logs.push('Kumpleto na ang dalawang manlalaro! Pindutin ang Handa na!');
          }

          broadcastToAlagaRoom(rawCode, 'alaga_room_updated', sanitizeAlagaRoom(room));
        } else if (event === 'alaga_player_ready') {
          const rawCode = String(data?.code || '').trim().toUpperCase();
          const playerId = data?.playerId;
          const room = alagaRooms.get(rawCode);
          if (!room || !room.players[playerId]) return;

          room.players[playerId].isReady = true;
          const allPlayers = Object.values(room.players);
          const allReady = allPlayers.length === 2 && allPlayers.every((p) => p.isReady);

          if (allReady) {
            room.battleState = 'battling';
            room.currentTurnPlayerId = allPlayers[0].id;
            room.logs.push('Nagsimula na ang Labanan ng mga Alaga! 1 on 1 sa Arena!');
          }

          broadcastToAlagaRoom(rawCode, 'alaga_room_updated', sanitizeAlagaRoom(room));
        } else if (event === 'alaga_player_attack') {
          const rawCode = String(data?.code || '').trim().toUpperCase();
          const room = alagaRooms.get(rawCode);
          if (!room || room.battleState !== 'battling') return;

          const {
            attackerPlayerId,
            targetPlayerId,
            attackType,
            skillName,
            damage,
            isCritical,
            textPrompt,
          } = data;

          const attacker = room.players[attackerPlayerId];
          const victim = room.players[targetPlayerId];
          if (!attacker || !victim) return;

          const attackerPet = attacker.team[attacker.activePetIndex];
          const victimPet = victim.team[victim.activePetIndex];
          if (!attackerPet || !victimPet) return;

          // Deduct HP
          const dealtDamage = Math.max(10, Number(damage) || 25);
          victimPet.currentHp = Math.max(0, victimPet.currentHp - dealtDamage);

          const critText = isCritical ? ' 💥 KRITIKAL NA TAMA!' : '';
          room.logs.push(
            `⚔️ ${attackerPet.name} (${attacker.name}) ginamit ang "${skillName}"! Bawas -${dealtDamage} HP kay ${victimPet.name}!${critText}`
          );

          // Check if victim's active pet fainted
          if (victimPet.currentHp <= 0) {
            victimPet.isFainted = true;
            room.logs.push(`💀 Nawalan ng malay si ${victimPet.name} ni ${victim.name}!`);

            // Find next unfainted pet in victim's 3-pet roster
            const nextPetIdx = victim.team.findIndex((p, idx) => idx > victim.activePetIndex && !p.isFainted);
            if (nextPetIdx !== -1) {
              victim.activePetIndex = nextPetIdx;
              const nextPet = victim.team[nextPetIdx];
              room.logs.push(`✨ Pumasok si ${nextPet.name} sa Arena upang ipagpatuloy ang laban!`);
            } else {
              // All 3 pets of victim fainted! Attacker wins!
              room.battleState = 'finished';
              room.winnerPlayerId = attackerPlayerId;
              attacker.score += 1;
              room.logs.push(`🏆 PANALO SI ${attacker.name}! Lahat ng 3 alaga ng kalaban ay natalo! ⭐ +50 Bituin!`);
            }
          }

          // Switch turn
          room.currentTurnPlayerId = targetPlayerId;

          // Broadcast attack resolution
          broadcastToAlagaRoom(rawCode, 'alaga_attack_result', {
            attackerPlayerId,
            targetPlayerId,
            damage: dealtDamage,
            isCritical: Boolean(isCritical),
            skillName,
            attackType,
            textPrompt,
            room: sanitizeAlagaRoom(room),
          });
        } else if (event === 'alaga_player_chat') {
          const rawCode = String(data?.code || '').trim().toUpperCase();
          const cleanMsg = censorProfanity(String(data?.message || ''));
          broadcastToAlagaRoom(rawCode, 'alaga_chat_message', {
            senderId: data?.playerId,
            senderName: data?.playerName,
            message: cleanMsg,
            timestamp: Date.now(),
          });
        } else if (event === 'alaga_rematch') {
          const rawCode = String(data?.code || '').trim().toUpperCase();
          const room = alagaRooms.get(rawCode);
          if (!room) return;

          // Reset all pets' HP and faint status
          for (const p of Object.values(room.players)) {
            p.activePetIndex = 0;
            p.isReady = false;
            for (const pet of p.team) {
              pet.currentHp = pet.maxHp;
              pet.isFainted = false;
            }
          }

          room.battleState = 'ready';
          room.winnerPlayerId = undefined;
          room.logs.push('Handa na sa Rematch! Pindutin muli ang Handa na!');
          broadcastToAlagaRoom(rawCode, 'alaga_room_updated', sanitizeAlagaRoom(room));
        } else if (event === 'alaga_leave_room') {
          const rawCode = String(data?.code || '').trim().toUpperCase();
          const playerId = data?.playerId;
          const room = alagaRooms.get(rawCode);
          if (room && room.players[playerId]) {
            const pName = room.players[playerId].name;
            delete room.players[playerId];
            room.logs.push(`Lumabas si ${pName} sa Arena.`);
            room.battleState = 'waiting';
            broadcastToAlagaRoom(rawCode, 'alaga_room_updated', sanitizeAlagaRoom(room));
          }
        }

        // -------------------------------------------------------------
        // BLOX FRUITS 3D MMORPG WORLD (Players, PvP, Censored Chat)
        // -------------------------------------------------------------
        if (event === 'blox_join') {
          const p = data;
          if (!p || !p.id) return;

          const newPlayer: BloxWorldPlayer = {
            id: p.id,
            name: p.name || 'Pirate',
            gender: p.gender || 'boy',
            level: Number(p.level) || 1,
            fruitId: p.fruitId || 'bomb',
            swordId: p.swordId || 'katana',
            accessoryId: p.accessoryId || 'marine_cap',
            haki: Boolean(p.haki),
            x: Number(p.x) || 0,
            y: Number(p.y) || 10,
            z: Number(p.z) || 10,
            rotationY: Number(p.rotationY) || 0,
            hp: Number(p.hp) || 100,
            maxHp: Number(p.maxHp) || 100,
            bounty: Number(p.bounty) || 1000,
            isMoving: false,
            ws,
          };

          bloxPlayers.set(p.id, newPlayer);
          clientInfo.bloxPlayerId = p.id;

          // Send current world roster to this newly joined player
          const existingList = Array.from(bloxPlayers.values())
            .filter((bp) => bp.id !== p.id)
            .map((bp) => ({
              id: bp.id,
              name: bp.name,
              gender: bp.gender,
              level: bp.level,
              fruitId: bp.fruitId,
              swordId: bp.swordId,
              accessoryId: bp.accessoryId,
              haki: bp.haki,
              x: bp.x,
              y: bp.y,
              z: bp.z,
              rotationY: bp.rotationY,
              hp: bp.hp,
              maxHp: bp.maxHp,
              bounty: bp.bounty,
            }));

          ws.send(JSON.stringify({ event: 'blox_world_state', data: { players: existingList } }));

          // Announce to other players that someone entered the world
          broadcastBlox(
            'blox_player_joined',
            {
              id: newPlayer.id,
              name: newPlayer.name,
              gender: newPlayer.gender,
              level: newPlayer.level,
              fruitId: newPlayer.fruitId,
              swordId: newPlayer.swordId,
              accessoryId: newPlayer.accessoryId,
              haki: newPlayer.haki,
              x: newPlayer.x,
              y: newPlayer.y,
              z: newPlayer.z,
              rotationY: newPlayer.rotationY,
              hp: newPlayer.hp,
              maxHp: newPlayer.maxHp,
              bounty: newPlayer.bounty,
            },
            ws
          );
        } else if (event === 'blox_move') {
          const bp = bloxPlayers.get(data.id);
          if (bp) {
            bp.x = Number(data.x) || bp.x;
            bp.y = Number(data.y) || bp.y;
            bp.z = Number(data.z) || bp.z;
            bp.rotationY = Number(data.rotationY) || bp.rotationY;
            bp.isMoving = Boolean(data.isMoving);

            broadcastBlox(
              'blox_player_moved',
              {
                id: bp.id,
                x: bp.x,
                y: bp.y,
                z: bp.z,
                rotationY: bp.rotationY,
                isMoving: bp.isMoving,
              },
              ws
            );
          }
        } else if (event === 'blox_attack') {
          broadcastBlox('blox_player_attack', data, ws);
        } else if (event === 'blox_pvp_hit') {
          const { attackerId, attackerName, victimId, damage, skillName } = data;
          const victim = bloxPlayers.get(victimId);
          if (victim) {
            victim.hp = Math.max(0, victim.hp - (Number(damage) || 20));
            broadcastBlox('blox_pvp_damage', {
              attackerId,
              attackerName,
              victimId,
              damage,
              skillName,
              newHp: victim.hp,
            });

            if (victim.hp <= 0) {
              broadcastBlox('blox_player_defeated', {
                attackerId,
                attackerName,
                victimId,
                victimName: victim.name,
                bountyReward: Math.round(victim.bounty * 0.1),
              });
              // Respawn victim at starter island fountain
              setTimeout(() => {
                victim.hp = victim.maxHp;
                victim.x = 0;
                victim.y = 10;
                victim.z = 10;
                broadcastBlox('blox_player_respawned', {
                  id: victim.id,
                  hp: victim.hp,
                  x: 0,
                  y: 10,
                  z: 10,
                });
              }, 3000);
            }
          }
        } else if (event === 'blox_chat') {
          const { senderId, senderName, fruitName, text } = data;
          const cleanText = censorProfanity(String(text || ''));
          broadcastBlox('blox_chat_message', {
            id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            senderId,
            senderName,
            fruitName,
            text: cleanText,
            timestamp: Date.now(),
          });
        } else if (event === 'blox_duel_invite') {
          broadcastBlox('blox_duel_invite', data, ws);
        } else if (event === 'blox_duel_response') {
          broadcastBlox('blox_duel_response', data, ws);
        } else if (event === 'blox_leave') {
          if (data.id && bloxPlayers.has(data.id)) {
            bloxPlayers.delete(data.id);
            broadcastBlox('blox_player_left', { id: data.id }, ws);
          }
        }
      } catch (err) {
        console.warn('[WS Parse/Handle Error]:', err);
      }
    });

    ws.on('close', () => {
      const clientInfo = wsClients.get(ws);
      if (clientInfo) {
        if (clientInfo.alagaRoomCode && clientInfo.alagaPlayerId) {
          const room = alagaRooms.get(clientInfo.alagaRoomCode);
          if (room) {
            delete room.players[clientInfo.alagaPlayerId];
            room.battleState = 'waiting';
            room.logs.push('Umalis ang kalaro sa Labanan.');
            broadcastToAlagaRoom(clientInfo.alagaRoomCode, 'alaga_room_updated', sanitizeAlagaRoom(room));
          }
        }
        if (clientInfo.bloxPlayerId && bloxPlayers.has(clientInfo.bloxPlayerId)) {
          bloxPlayers.delete(clientInfo.bloxPlayerId);
          broadcastBlox('blox_player_left', { id: clientInfo.bloxPlayerId });
        }
        wsClients.delete(ws);
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

