export type QuizSubject = 'filipino' | 'english' | 'math';
export type GradeLevel = 4 | 5 | 6;

export interface ChestQuestion {
  id: string;
  gradeLevel: GradeLevel;
  subject: QuizSubject;
  subjectLabel: string;
  subjectTagalog: string;
  subjectIcon: string;
  subjectColor: string;
  topicCategory?: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  bonusStars: number;
  aiSource?: 'groq' | 'gemini' | 'local';
}

export const CHEST_QUIZ_QUESTIONS: ChestQuestion[] = [
  // =========================================================================
  // BAITANG 4: DEPED ARAL PROGRAM (READING & MATH)
  // =========================================================================
  {
    id: 'g4-fil-1',
    gradeLevel: 4,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Basa at Talasalitaan',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Talasalitaan',
    question: 'Ano ang kasingkahulugan ng salitang "masigasig" sa pangungusap: "Masigasig na nag-aral si Maya kaya siya nagwagi sa paligsahan"?',
    options: ['Matiyaga at masikap', 'Mabilis magalit', 'Tamad kumilos', 'Tahimik mag-isa'],
    correctIndex: 0,
    explanation: 'Ang salitang "masigasig" ay nangangahulugang matiyaga, masikap, at dedikado sa gawain.',
    bonusStars: 50,
  },
  {
    id: 'g4-fil-2',
    gradeLevel: 4,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Basa at Sawikain',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Sawikain',
    question: 'Ano ang kahulugan ng sawikaing "bukas ang palad" kapag sinabi sa isang pinuno ng barangay?',
    options: ['Laging handang tumulong at magbigay', 'Laging bukas ang mga bintana', 'Nais humingi ng limos', 'Maramot sa kapwa'],
    correctIndex: 0,
    explanation: 'Ang sawikaing "bukas ang palad" ay tumutukoy sa taong matulungin at mapagbigay sa mga nangangailangan.',
    bonusStars: 50,
  },
  {
    id: 'g4-fil-3',
    gradeLevel: 4,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Kuwento at Pang-unawa',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Pang-unawa sa Binasa',
    question: 'Basahin ang maikling talata: "Yumuyukod ang kawayan tuwing humihihip ang malakas na hangin kaya hindi ito nababali, di tulad ng matatayog na punong matitigas." Ano ang pangunahing aral ng talata?',
    options: [
      'Ang pagiging mapagkumbaba at marunong makibagay ay nagdudulot ng kaligtasan',
      'Mas mainam maging matigas at hambog sa lahat ng oras',
      'Kailangang putulin ang lahat ng kawayan',
      'Hindi umiihip ang hangin sa bukid',
    ],
    correctIndex: 0,
    explanation: 'Ang kawayan ay nagtuturo ng aral ng pagpapakumbaba at katatagan sa gitna ng unos.',
    bonusStars: 50,
  },
  {
    id: 'g4-eng-1',
    gradeLevel: 4,
    subject: 'english',
    subjectLabel: 'English Reading',
    subjectTagalog: 'Vocabulary & Context',
    subjectIcon: '📖',
    subjectColor: '#6366f1',
    topicCategory: 'Context Clues',
    question: 'Identify the meaning of "sanctuary" in the sentence: "The national park serves as a protected sanctuary for the endangered Philippine Eagle."',
    options: ['A safe haven of protection', 'A busy marketplace', 'A dark deep cave', 'A noisy highway'],
    correctIndex: 0,
    explanation: 'A sanctuary is a place of refuge, safety, or protection for wildlife.',
    bonusStars: 50,
  },
  {
    id: 'g4-eng-2',
    gradeLevel: 4,
    subject: 'english',
    subjectLabel: 'English Reading',
    subjectTagalog: 'Reading Comprehension',
    subjectIcon: '📖',
    subjectColor: '#6366f1',
    topicCategory: 'Author Purpose',
    question: 'Read: "Recycling plastic bottles reduces waste in landfills and conserves ocean life. Every learner can make a difference by sorting garbage." What is the author\'s main purpose?',
    options: [
      'To persuade learners to practice recycling and protect the environment',
      'To sell expensive plastic toys',
      'To explain how to buy bottled drinks',
      'To narrate an imaginary fairy tale',
    ],
    correctIndex: 0,
    explanation: 'The passage aims to persuade and encourage readers to take active environmental steps through recycling.',
    bonusStars: 50,
  },
  {
    id: 'g4-math-1',
    gradeLevel: 4,
    subject: 'math',
    subjectLabel: 'Mathematics',
    subjectTagalog: 'Sipnayan (ARAL Math)',
    subjectIcon: '📐',
    subjectColor: '#3b82f6',
    topicCategory: 'Multiplication & Area',
    question: 'A vegetable garden has a rectangular length of 24 meters and a width of 8 meters. What is the perimeter of the garden?',
    options: ['64 meters', '192 meters', '32 meters', '48 meters'],
    correctIndex: 0,
    explanation: 'Perimeter of rectangle = 2 × (Length + Width) = 2 × (24 + 8) = 2 × 32 = 64 meters.',
    bonusStars: 50,
  },
  {
    id: 'g4-math-2',
    gradeLevel: 4,
    subject: 'math',
    subjectLabel: 'Mathematics',
    subjectTagalog: 'Sipnayan (ARAL Math)',
    subjectIcon: '📐',
    subjectColor: '#3b82f6',
    topicCategory: 'Division with Word Problem',
    question: 'A relief team packed 720 kilograms of rice into sacks of 15 kilograms each. How many sacks were filled completely?',
    options: ['48 sacks', '50 sacks', '45 sacks', '42 sacks'],
    correctIndex: 0,
    explanation: '720 ÷ 15 = 48 sacks of rice.',
    bonusStars: 50,
  },

  // =========================================================================
  // BAITANG 5: DEPED ARAL PROGRAM (READING & MATH)
  // =========================================================================
  {
    id: 'g5-fil-1',
    gradeLevel: 5,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Basa at Sanhi-Bunga',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Sanhi at Bunga',
    question: 'Tukuyin ang SANHI sa pangungusap: "Dahil sa walang tigil na pagputol ng mga puno sa kabundukan, nagkaroon ng malaking pagbaha sa kapatagan."',
    options: [
      'Walang tigil na pagputol ng mga puno sa kabundukan',
      'Nagkaroon ng malaking pagbaha sa kapatagan',
      'Naging masaya ang mga residente',
      'Lumitaw ang bahaghari sa langit',
    ],
    correctIndex: 0,
    explanation: 'Ang sanhi ay ang dahilan ng pangyayari: ang pagputol ng mga puno.',
    bonusStars: 60,
  },
  {
    id: 'g5-fil-2',
    gradeLevel: 5,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Katotohanan o Opinyon',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Katotohanan at Opinyon',
    question: 'Alin sa mga sumusunod ang isang KATOTOHANAN (Fact) at hindi opinyon?',
    options: [
      'Ang pambansang watawat ng Pilipinas ay may tatlong bituin at isang araw na may walong sinag.',
      'Para sa akin, ang asignaturang Filipino ang pinakamadali sa lahat.',
      'Malamang ay uulan mamayang hapon dahil madilim ang langit.',
      'Naniniwala ako na mas masaya ang buhay sa lungsod kaysa probinsya.',
    ],
    correctIndex: 0,
    explanation: 'Ang disenyo ng watawat ng Pilipinas ay nakasaad sa batas at napatutunayang totoo.',
    bonusStars: 60,
  },
  {
    id: 'g5-eng-1',
    gradeLevel: 5,
    subject: 'english',
    subjectLabel: 'English Reading',
    subjectTagalog: 'Inferences & Vocabulary',
    subjectIcon: '📖',
    subjectColor: '#6366f1',
    topicCategory: 'Making Inferences',
    question: 'Read: "Dark storm clouds gathered rapidly, and thunder rumbled across the bay. Fishermen hurriedly dragged their bancas ashore and tied them tightly to sturdy palm trees." What can you infer?',
    options: [
      'A dangerous typhoon or storm is approaching',
      'The fishermen are going swimming for fun',
      'The sun is about to shine brightly',
      'It is early morning with clear skies',
    ],
    correctIndex: 0,
    explanation: 'The dark clouds, thunder, and securing boats indicate an approaching typhoon.',
    bonusStars: 60,
  },
  {
    id: 'g5-math-1',
    gradeLevel: 5,
    subject: 'math',
    subjectLabel: 'Mathematics',
    subjectTagalog: 'Sipnayan (ARAL Math)',
    subjectIcon: '📐',
    subjectColor: '#3b82f6',
    topicCategory: 'Fractions & Decimals',
    question: 'What is 3/4 + 1/2 in simplest form or mixed number?',
    options: ['1 1/4 (or 5/4)', '4/6', '2/3', '1 1/2'],
    correctIndex: 0,
    explanation: 'Find the LCD (4): 3/4 + 2/4 = 5/4 = 1 1/4.',
    bonusStars: 60,
  },
  {
    id: 'g5-math-2',
    gradeLevel: 5,
    subject: 'math',
    subjectLabel: 'Mathematics',
    subjectTagalog: 'Sipnayan (ARAL Math)',
    subjectIcon: '📐',
    subjectColor: '#3b82f6',
    topicCategory: 'Volume of Rectangular Prism',
    question: 'A fish aquarium measures 10 dm in length, 4 dm in width, and 5 dm in height. What is the total volume in cubic decimeters (dm³)?',
    options: ['200 dm³', '19 dm³', '100 dm³', '50 dm³'],
    correctIndex: 0,
    explanation: 'Volume = Length × Width × Height = 10 × 4 × 5 = 200 dm³.',
    bonusStars: 60,
  },

  // =========================================================================
  // BAITANG 6: DEPED ARAL PROGRAM (READING & MATH)
  // =========================================================================
  {
    id: 'g6-fil-1',
    gradeLevel: 6,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Mapanuring Pagbasa',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Editoryal at Opinyon',
    question: 'Ano ang layunin ng isang "Editoryal" o Pangulong-Tudling sa isang pahayagan?',
    options: [
      'Ipahayag ang opinyon at paninindigan ng pahayagan ukol sa napapanahong isyu',
      'Magtala ng mga bugtong at kwentong bayan',
      'Magbenta ng mga produkto at damit',
      'Magbigay lamang ng mga iskedyul ng sinehan',
    ],
    correctIndex: 0,
    explanation: 'Ang editoryal ay pormal na naglalahad ng opinyon, paninindigan, at pagsusuri ng patnugutan ng pahayagan sa mahalagang isyu.',
    bonusStars: 70,
  },
  {
    id: 'g6-fil-2',
    gradeLevel: 6,
    subject: 'filipino',
    subjectLabel: 'Filipino Reading',
    subjectTagalog: 'Akademikong Bokabularyo',
    subjectIcon: '🇵🇭',
    subjectColor: '#ef4444',
    topicCategory: 'Talasalitaan',
    question: 'Ano ang kahulugan ng salitang "soberanya" sa konteksto ng bansang Pilipinas?',
    options: [
      'Ganap na kapangyarihan at kalayaan ng estado na mamahala sa sarili',
      'Pagkaalipin sa ilalim ng ibang pamahalaan',
      'Panghihiram ng salapi sa ibang bansa',
      'Pansamantalang kapayapaan',
    ],
    correctIndex: 0,
    explanation: 'Ang soberanya ay ang pinakamataas na kapangyarihan ng estado na magpasya at mamahala nang walang panghihimasok ng dayuhan.',
    bonusStars: 70,
  },
  {
    id: 'g6-eng-1',
    gradeLevel: 6,
    subject: 'english',
    subjectLabel: 'English Reading',
    subjectTagalog: 'Critical Comprehension',
    subjectIcon: '📖',
    subjectColor: '#6366f1',
    topicCategory: 'Figurative Language',
    question: 'Which of the following sentences contains a METAPHOR?',
    options: [
      '"Education is the key that unlocks the golden door to freedom."',
      '"The wind whispered as gently as a mother\'s lullaby."',
      '"The athlete ran like lightning across the field."',
      '"The leaves were green and damp with dew."',
    ],
    correctIndex: 0,
    explanation: 'A metaphor directly asserts that one thing is another ("Education is the key") without using "like" or "as".',
    bonusStars: 70,
  },
  {
    id: 'g6-math-1',
    gradeLevel: 6,
    subject: 'math',
    subjectLabel: 'Mathematics',
    subjectTagalog: 'Sipnayan (ARAL Math)',
    subjectIcon: '📐',
    subjectColor: '#3b82f6',
    topicCategory: 'Percentage & Rate',
    question: 'In a school of 800 pupils, 45% are boys. How many boys are enrolled in the school?',
    options: ['360 boys', '400 boys', '320 boys', '450 boys'],
    correctIndex: 0,
    explanation: 'Percentage = Base × Rate = 800 × 0.45 = 360 boys.',
    bonusStars: 70,
  },
  {
    id: 'g6-math-2',
    gradeLevel: 6,
    subject: 'math',
    subjectLabel: 'Mathematics',
    subjectTagalog: 'Sipnayan (ARAL Math)',
    subjectIcon: '📐',
    subjectColor: '#3b82f6',
    topicCategory: 'Order of Operations (PEMDAS)',
    question: 'Solve using order of operations: 15 + 4 × (12 - 7) - 8 ÷ 2',
    options: ['31', '35', '27', '45'],
    correctIndex: 0,
    explanation: 'Inside parentheses: 12 - 7 = 5. Multiply: 4 × 5 = 20. Divide: 8 ÷ 2 = 4. Expression: 15 + 20 - 4 = 35 - 4 = 31.',
    bonusStars: 70,
  },
];

export const getRandomChestQuestion = (
  preferredGrade?: GradeLevel,
  preferredSubject?: QuizSubject
): ChestQuestion => {
  let pool = CHEST_QUIZ_QUESTIONS;

  if (preferredGrade) {
    const gradePool = pool.filter((q) => q.gradeLevel === preferredGrade);
    if (gradePool.length > 0) pool = gradePool;
  }

  if (preferredSubject) {
    const subjectPool = pool.filter((q) => q.subject === preferredSubject);
    if (subjectPool.length > 0) pool = subjectPool;
  }

  const randomIndex = Math.floor(Math.random() * pool.length);
  return pool[randomIndex];
};

export const getQuestionsByGrade = (grade: GradeLevel): ChestQuestion[] => {
  return CHEST_QUIZ_QUESTIONS.filter((q) => q.gradeLevel === grade);
};

export const getQuestionsByGradeAndSubject = (
  grade?: GradeLevel | 'all',
  subject?: QuizSubject | 'all'
): ChestQuestion[] => {
  return CHEST_QUIZ_QUESTIONS.filter((q) => {
    if (grade && grade !== 'all' && q.gradeLevel !== grade) return false;
    if (subject && subject !== 'all' && q.subject !== subject) return false;
    return true;
  });
};

export interface GradeCategoryInfo {
  grade: GradeLevel;
  label: string;
  tagalog: string;
  description: string;
  icon: string;
  badgeColor: string;
}

export const GRADE_CATEGORIES: GradeCategoryInfo[] = [
  { grade: 4, label: 'Baitang 4', tagalog: 'Baitang 4', description: 'DepEd ARAL: Talasalitaan, Sawikain, Pang-unawa, Multi-digit Math, GCF/LCM, Perimeter & Elapsed Time', icon: '🌲', badgeColor: '#8b5cf6' },
  { grade: 5, label: 'Baitang 5', tagalog: 'Baitang 5', description: 'DepEd ARAL: Masining na Pagbasa, Sanhi at Bunga, Katotohanan/Opinyon, Fractions, Decimals, Ratios & Volume', icon: '🦅', badgeColor: '#ec4899' },
  { grade: 6, label: 'Baitang 6', tagalog: 'Baitang 6', description: 'DepEd ARAL: Mapanuring Pagbasa, Editoryal, Percentage, Rate, Integers, Algebra, PEMDAS & Surface Area', icon: '👑', badgeColor: '#f59e0b' },
];

export const QUIZ_SUBJECTS: {
  subject: QuizSubject;
  label: string;
  tagalog: string;
  language: 'English' | 'Filipino';
  icon: string;
  color: string;
}[] = [
  { subject: 'filipino', label: 'Basa (Filipino)', tagalog: 'Wikang Filipino - ARAL', language: 'Filipino', icon: '🇵🇭', color: '#ef4444' },
  { subject: 'english', label: 'Reading (English)', tagalog: 'English Reading - ARAL', language: 'English', icon: '📖', color: '#6366f1' },
  { subject: 'math', label: 'Sipnayan (Math)', tagalog: 'Matematika - ARAL', language: 'English', icon: '📐', color: '#3b82f6' },
];
