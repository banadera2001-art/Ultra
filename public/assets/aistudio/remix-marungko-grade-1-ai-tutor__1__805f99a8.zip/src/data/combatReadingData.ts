export interface ReadingCombatWord {
  id: string;
  word: string;
  syllables: string[];
  phoneticGuide: string;
  clue: string;
  distractors: string[];
  category: 'talasalitaan' | 'sawikain' | 'aral_akademiko';
  gradeLevel: 4 | 5 | 6;
  passage?: string;
}

/**
 * Curated pool of 100+ DepEd ARAL Program Workbook words and expressions for Grades 4, 5, and 6.
 * Covers Key Stage 2 vocabulary, idioms (sawikain), science/math contexts, and Filipino literature.
 */
export const READING_COMBAT_POOL: ReadingCombatWord[] = [
  // ==========================================
  // BAITANG 4: ARAL PROGRAM WORKBOOK
  // ==========================================
  {
    id: 'rc-g4-masigasig',
    word: 'MASIGASIG',
    syllables: ['MA', 'SI', 'GA', 'SIG'],
    phoneticGuide: 'MA-SI-GA-SIG',
    clue: 'Matiyaga at pursigido sa pag-aaral at gawain',
    distractors: ['TAMAD', 'MAHINA', 'MAGALIT'],
    category: 'talasalitaan',
    gradeLevel: 4,
    passage: 'Masigasig na nag-aral ang mag-aaral para sa pagsusulit.',
  },
  {
    id: 'rc-g4-dalubhasa',
    word: 'DALUBHASA',
    syllables: ['DA', 'LUB', 'HA', 'SA'],
    phoneticGuide: 'DA-LUB-HA-SA',
    clue: 'Eksperto at may malawak na kasanayan sa isang larangan',
    distractors: ['BAGUHAN', 'WALANG-ALAM', 'PADALOS-DALOS'],
    category: 'talasalitaan',
    gradeLevel: 4,
    passage: 'Ang dalubhasang siyentipiko ay sumuri sa mga halaman.',
  },
  {
    id: 'rc-g4-katatagan',
    word: 'KATATAGAN',
    syllables: ['KA', 'TA', 'TA', 'GAN'],
    phoneticGuide: 'KA-TA-TA-GAN',
    clue: 'Lakas ng loob na bumangon sa gitna ng pagsubok',
    distractors: ['KAHINAAN', 'TAKOT', 'KAGULUHAN'],
    category: 'talasalitaan',
    gradeLevel: 4,
    passage: 'Ipinamalas ng mga mamamayan ang katatagan pagkatapos ng unos.',
  },
  {
    id: 'rc-g4-bukas-palad',
    word: 'BUKAS-PALAD',
    syllables: ['BU', 'KAS', 'PA', 'LAD'],
    phoneticGuide: 'BU-KAS PA-LAD',
    clue: 'Laging handang magbigay ng tulong sa kapwa',
    distractors: ['MARAMOT', 'KURIPOT', 'TAKOT'],
    category: 'sawikain',
    gradeLevel: 4,
    passage: 'Bukas-palad na namahagi ng tulong si Aling Rosa sa mga nasalanta.',
  },
  {
    id: 'rc-g4-kapit-bisig',
    word: 'KAPIT-BISIG',
    syllables: ['KA', 'PIT', 'BI', 'SIG'],
    phoneticGuide: 'KA-PIT BI-SIG',
    clue: 'Sama-samang pagtutulungan ng komunidad',
    distractors: ['NAG-AAWAY', 'NAGHIHIWALAY', 'NAGUGULUHAN'],
    category: 'sawikain',
    gradeLevel: 4,
    passage: 'Kapit-bisig na nilinis ng mga bata ang palaruan.',
  },
  {
    id: 'rc-g4-bukal-sa-loob',
    word: 'BUKAL SA LOOB',
    syllables: ['BU', 'KAL', 'SA', 'LO', 'OB'],
    phoneticGuide: 'BU-KAL SA LO-OB',
    clue: 'Taus-pusong pagkakaloob nang walang hinihintay na kapalit',
    distractors: ['PILIT', 'KASAKIMAN', 'KAPALALUAN'],
    category: 'sawikain',
    gradeLevel: 4,
    passage: 'Bukal sa loob ang pag-aalaga ni Juan sa kanyang lolo.',
  },
  {
    id: 'rc-g4-matalas-isip',
    word: 'MATALAS ANG ISIP',
    syllables: ['MA', 'TA', 'LAS', 'I', 'SIP'],
    phoneticGuide: 'MA-TA-LAS ANG I-SIP',
    clue: 'Matalino at mabilis makaunawa sa mga aralin',
    distractors: ['MABAGAL', 'MAKAKALIMUTIN', 'LITO'],
    category: 'sawikain',
    gradeLevel: 4,
    passage: 'Dahil matalas ang isip, madali niyang naresolba ang math puzzle.',
  },
  {
    id: 'rc-g4-pamayanan',
    word: 'PAMAYANAN',
    syllables: ['PA', 'MA', 'YA', 'NAN'],
    phoneticGuide: 'PA-MA-YA-NAN',
    clue: 'Lipunan o pangkat ng mga pamilyang naninirahan sa iisang pook',
    distractors: ['KABUNDUKAN', 'DAYUHAN', 'KASARINLAN'],
    category: 'talasalitaan',
    gradeLevel: 4,
    passage: 'Nagtutulungan ang buong pamayanan para sa kalinisan.',
  },
  {
    id: 'rc-g4-nagpupunyagi',
    word: 'NAGPUPUNYAGI',
    syllables: ['NAG', 'PU', 'PUN', 'YA', 'GI'],
    phoneticGuide: 'NAG-PU-PUN-YA-GI',
    clue: 'Nagsusumikap na maabot ang tagumpay sa kabila ng hirap',
    distractors: ['SUMUSUKO', 'NAGPAPAHINGA', 'NAGREREKLAMO'],
    category: 'talasalitaan',
    gradeLevel: 4,
    passage: 'Nagpupunyagi ang magsasaka upang maging masagana ang ani.',
  },
  {
    id: 'rc-g4-perseverance',
    word: 'PERSEVERANCE',
    syllables: ['PER', 'SE', 'VER', 'ANCE'],
    phoneticGuide: 'PUR-SUH-VEER-UNS',
    clue: 'English word: Continuing steadfastly despite difficulties',
    distractors: ['SURRENDER', 'LAZINESS', 'WEAKNESS'],
    category: 'aral_akademiko',
    gradeLevel: 4,
    passage: 'Perseverance is key to mastering multiplication and reading.',
  },

  // ==========================================
  // BAITANG 5: ARAL PROGRAM WORKBOOK
  // ==========================================
  {
    id: 'rc-g5-pakikibaka',
    word: 'PAKIKIBAKA',
    syllables: ['PA', 'KI', 'KI', 'BA', 'KA'],
    phoneticGuide: 'PA-KI-KI-BA-KA',
    clue: 'Pagtindig at sama-samang paglaban para sa karapatan at katarungan',
    distractors: ['PAGPAPAHINGA', 'PAGTAKAS', 'PAGSUKO'],
    category: 'talasalitaan',
    gradeLevel: 5,
    passage: 'Ang pakikibaka ng mga bayani ang nagdulot ng kalayaan.',
  },
  {
    id: 'rc-g5-kasarinlan',
    word: 'KASARINLAN',
    syllables: ['KA', 'SA', 'RIN', 'LAN'],
    phoneticGuide: 'KA-SA-RIN-LAN',
    clue: 'Kalayaan at soberanya ng bansa mula sa dayuhang kapangyarihan',
    distractors: ['PAGKAALIPIN', 'KAPAHAMAKAN', 'KADILIMAN'],
    category: 'talasalitaan',
    gradeLevel: 5,
    passage: 'Ipinagdiwang ng sambayanan ang Araw ng Kasarinlan.',
  },
  {
    id: 'rc-g5-yamang-dagat',
    word: 'YAMANG-DAGAT',
    syllables: ['YA', 'MANG', 'DA', 'GAT'],
    phoneticGuide: 'YA-MANG DA-GAT',
    clue: 'Mga likas na biyaya sa karagatan tulad ng isda at korales',
    distractors: ['BASURA', 'USOK', 'LUPANG TIGANG'],
    category: 'talasalitaan',
    gradeLevel: 5,
    passage: 'Dapat nating ingatan ang ating yamang-dagat mula sa polusyon.',
  },
  {
    id: 'rc-g5-masinop',
    word: 'MASINOP',
    syllables: ['MA', 'SI', 'NOP'],
    phoneticGuide: 'MA-SI-NOP',
    clue: 'Maingat, matipid, at maayos mag-imbak at gumamit ng gamit at pera',
    distractors: ['WALDAS', 'BURARA', 'MAGULO'],
    category: 'talasalitaan',
    gradeLevel: 5,
    passage: 'Masinop mag-ipon ng baon si Maria sa kanyang alkansya.',
  },
  {
    id: 'rc-g5-pananagutan',
    word: 'PANANAGUTAN',
    syllables: ['PA', 'NA', 'NA', 'GU', 'TAN'],
    phoneticGuide: 'PA-NA-NA-GU-TAN',
    clue: 'Tungkulin at obligasyong dapat tuparin nang may integridad',
    distractors: ['KABALINTUNAAN', 'PAGPABAYA', 'KAPAHAMAKAN'],
    category: 'talasalitaan',
    gradeLevel: 5,
    passage: 'Pananagutan ng bawat mag-aaral ang pangangalaga sa kalikasan.',
  },
  {
    id: 'rc-g5-biodiversity',
    word: 'BIODIVERSITY',
    syllables: ['BIO', 'DI', 'VER', 'SI', 'TY'],
    phoneticGuide: 'BY-OH-DY-VUR-SI-TEE',
    clue: 'English word: Variety of plant and animal life in a habitat',
    distractors: ['POLLUTION', 'EXTINCTION', 'DESTRUCTION'],
    category: 'aral_akademiko',
    gradeLevel: 5,
    passage: 'The coral reefs of Palawan showcase extraordinary biodiversity.',
  },
  {
    id: 'rc-g5-ecosystem',
    word: 'ECOSYSTEM',
    syllables: ['E', 'CO', 'SYS', 'TEM'],
    phoneticGuide: 'EE-KOH-SIS-TUM',
    clue: 'English word: Biological community of interacting organisms',
    distractors: ['MACHINE', 'FACTORY', 'WASTE'],
    category: 'aral_akademiko',
    gradeLevel: 5,
    passage: 'Forests are a vital ecosystem providing oxygen and clean water.',
  },
  {
    id: 'rc-g5-pagpupugay',
    word: 'PAGPUPUGAY',
    syllables: ['PAG', 'PU', 'PU', 'GAY'],
    phoneticGuide: 'PAG-PU-PU-GAY',
    clue: 'Pagbibigay ng mataas na parangal at paggalang sa mga bayani',
    distractors: ['PAG-UYAM', 'KAHIYAHIYA', 'PAGBALEWALA'],
    category: 'talasalitaan',
    gradeLevel: 5,
    passage: 'Nag-alay ng bulaklak at pagpupugay ang mga mag-aaral sa bantayog.',
  },

  // ==========================================
  // BAITANG 6: ARAL PROGRAM WORKBOOK
  // ==========================================
  {
    id: 'rc-g6-likas-kaya',
    word: 'LIKAS-KAYANG PAG-UNLAD',
    syllables: ['LI', 'KAS', 'KA', 'YA'],
    phoneticGuide: 'LI-KAS KA-YA',
    clue: 'Pagsulong na hindi sumisira sa yamang kailangan ng susunod na henerasyon',
    distractors: ['PAGWASAK', 'PANG-AABUSO', 'KAPINSALAAN'],
    category: 'aral_akademiko',
    gradeLevel: 6,
    passage: 'Ang likas-kayang pag-unlad ay nagpapanatili ng balanse sa kalikasan.',
  },
  {
    id: 'rc-g6-soberanya',
    word: 'SOBERANYA',
    syllables: ['SO', 'BE', 'RAN', 'YA'],
    phoneticGuide: 'SO-BE-RAN-YA',
    clue: 'Ganap na kapangyarihan ng isang estado na mamahala nang malaya',
    distractors: ['KASAKUPAN', 'KOLONYA', 'PAGKAALIPIN'],
    category: 'aral_akademiko',
    gradeLevel: 6,
    passage: 'Ipinagtatanggol ng sandatahang lakas ang soberanya ng teritoryo.',
  },
  {
    id: 'rc-g6-katarungan',
    word: 'KATARUNGANG PANLIPUNAN',
    syllables: ['KA', 'TA', 'RU', 'NGAN'],
    phoneticGuide: 'KA-TA-RU-NGAN',
    clue: 'Pantay-pantay na pagtrato at proteksyon sa batas para sa lahat',
    distractors: ['PANDARAYA', 'DISKRIMINASYON', 'KATIWALIAN'],
    category: 'aral_akademiko',
    gradeLevel: 6,
    passage: 'Katarungang panlipunan ang pundasyon ng mapayapang pamahalaan.',
  },
  {
    id: 'rc-g6-sustainability',
    word: 'SUSTAINABILITY',
    syllables: ['SUS', 'TAIN', 'A', 'BIL', 'I', 'TY'],
    phoneticGuide: 'SUH-STAY-NUH-BIL-IH-TEE',
    clue: 'English word: Meeting present needs without depleting resources for the future',
    distractors: ['EXHAUSTION', 'DEFICIT', 'CONSUMPTION'],
    category: 'aral_akademiko',
    gradeLevel: 6,
    passage: 'Renewable solar energy supports global environmental sustainability.',
  },
  {
    id: 'rc-g6-digital-literacy',
    word: 'DIGITAL LITERACY',
    syllables: ['DI', 'GI', 'TAL', 'LIT', 'ER', 'A', 'CY'],
    phoneticGuide: 'DI-GI-TAL LI-TE-RA-SEE',
    clue: 'English word: Critical ability to find, evaluate, and compose clear information online',
    distractors: ['IGNORANCE', 'FAKE NEWS', 'GULLIBILITY'],
    category: 'aral_akademiko',
    gradeLevel: 6,
    passage: 'Digital literacy helps Grade 6 learners verify factual sources.',
  },
  {
    id: 'rc-g6-pagkakakilanlan',
    word: 'PAGKAKAKILANLAN',
    syllables: ['PAG', 'KA', 'KA', 'KI', 'LAN', 'LAN'],
    phoneticGuide: 'PAG-KA-KA-KI-LAN-LAN',
    clue: 'Pambansang pagkakakilanlan at kultural na dangal ng mamamayang Pilipino',
    distractors: ['PAGKALITO', 'PAGKALIMOT', 'PANGHUWAD'],
    category: 'talasalitaan',
    gradeLevel: 6,
    passage: 'Ang ating katutubong sining ang bumubuo sa ating pambansang pagkakakilanlan.',
  },
];

/**
 * Filter and fetch unique reading combat words for specific Grade 4, 5, or 6
 */
export function getUniqueReadingCombatWord(
  askedSet: Set<string>,
  targetGrade: 4 | 5 | 6 = 4
): ReadingCombatWord {
  // Pool matching the target grade
  const gradeMatches = READING_COMBAT_POOL.filter(
    (w) => w.gradeLevel === targetGrade && !askedSet.has(w.id)
  );

  if (gradeMatches.length > 0) {
    const picked = gradeMatches[Math.floor(Math.random() * gradeMatches.length)];
    askedSet.add(picked.id);
    return picked;
  }

  // Fallback to any unasked word in the pool
  const allUnasked = READING_COMBAT_POOL.filter((w) => !askedSet.has(w.id));
  if (allUnasked.length > 0) {
    const picked = allUnasked[Math.floor(Math.random() * allUnasked.length)];
    askedSet.add(picked.id);
    return picked;
  }

  // If pool exhausted, reset asked set and return random word
  askedSet.clear();
  return READING_COMBAT_POOL[Math.floor(Math.random() * READING_COMBAT_POOL.length)];
}

/**
 * Generate 4 distinct dynamic multiple-choice options with 3 plausible distractors
 */
export function generateDynamicReadingOptions(
  targetWord: string,
  targetCategory?: string
): string[] {
  const target = READING_COMBAT_POOL.find(
    (w) => w.word.toUpperCase() === targetWord.toUpperCase()
  );

  const pickedDistractors: string[] = [];
  const pickedSet = new Set<string>([targetWord.toUpperCase()]);

  // Use curated distractors if available
  if (target && target.distractors) {
    for (const d of target.distractors) {
      const up = d.trim().toUpperCase();
      if (!pickedSet.has(up)) {
        pickedDistractors.push(up);
        pickedSet.add(up);
      }
      if (pickedDistractors.length >= 3) break;
    }
  }

  // Fill remaining from pool
  const shuffledPool = [...READING_COMBAT_POOL].sort(() => Math.random() - 0.5);
  for (const item of shuffledPool) {
    if (pickedDistractors.length >= 3) break;
    const wordUpper = item.word.trim().toUpperCase();
    if (!pickedSet.has(wordUpper)) {
      pickedDistractors.push(wordUpper);
      pickedSet.add(wordUpper);
    }
  }

  const finalOptions = [targetWord.toUpperCase(), ...pickedDistractors.slice(0, 3)];
  return finalOptions.sort(() => Math.random() - 0.5);
}
