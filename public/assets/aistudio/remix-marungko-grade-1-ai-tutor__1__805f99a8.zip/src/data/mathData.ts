import { MathItem, MathOperation } from '../types';

export const MATH_CURRICULUM_ITEMS: MathItem[] = [
  // ==========================================
  // BAITANG 4 (Grade 4): DepEd ARAL Program
  // Multi-digit operations with regrouping, 2-digit multiplication, division with remainder, fractions, perimeter/area
  // ==========================================
  {
    id: 'g4-add-1',
    gradeLevel: 4,
    num1: 450,
    num2: 385,
    operation: '+',
    expectedAnswer: 835,
    itemType: 'metro',
    itemEmoji: '📏',
    explanationTagalog: '450 metro dagdagan ng 385 metro ay 835 metro.',
  },
  {
    id: 'g4-add-2',
    gradeLevel: 4,
    num1: 1250,
    num2: 875,
    operation: '+',
    expectedAnswer: 2125,
    itemType: 'sako ng palay',
    itemEmoji: '🌾',
    explanationTagalog: '1,250 sako ng palay dagdagan ng 875 sako ay 2,125 sako ng palay.',
  },
  {
    id: 'g4-add-3',
    gradeLevel: 4,
    num1: 3420,
    num2: 1580,
    operation: '+',
    expectedAnswer: 5000,
    itemType: 'puno sa kagubatan',
    itemEmoji: '🌲',
    explanationTagalog: '3,420 puno dagdagan ng 1,580 puno ay 5,000 puno sa reforestation.',
  },
  {
    id: 'g4-sub-1',
    gradeLevel: 4,
    num1: 750,
    num2: 285,
    operation: '-',
    expectedAnswer: 465,
    itemType: 'piso',
    itemEmoji: '💵',
    explanationTagalog: '750 piso bawasan ng 285 piso ay 465 piso.',
  },
  {
    id: 'g4-sub-2',
    gradeLevel: 4,
    num1: 2400,
    num2: 950,
    operation: '-',
    expectedAnswer: 1450,
    itemType: 'litro ng tubig',
    itemEmoji: '💧',
    explanationTagalog: '2,400 litro ng tubig sa tangke bawasan ng 950 litro ay 1,450 litro.',
  },
  {
    id: 'g4-sub-3',
    gradeLevel: 4,
    num1: 5000,
    num2: 1875,
    operation: '-',
    expectedAnswer: 3125,
    itemType: 'kilometro',
    itemEmoji: '🚗',
    explanationTagalog: '5,000 kilometro bawasan ng 1,875 kilometro ay 3,125 kilometro.',
  },
  {
    id: 'g4-mul-1',
    gradeLevel: 4,
    num1: 24,
    num2: 5,
    operation: '×',
    expectedAnswer: 120,
    itemType: 'bote',
    itemEmoji: '🍶',
    explanationTagalog: '24 bote sa bawat kahon, may 5 kahon: 24 × 5 = 120 bote.',
  },
  {
    id: 'g4-mul-2',
    gradeLevel: 4,
    num1: 36,
    num2: 4,
    operation: '×',
    expectedAnswer: 144,
    itemType: 'rosas',
    itemEmoji: '🌹',
    explanationTagalog: '36 rosas sa bawat plorera, may 4 na plorera: 36 × 4 = 144 rosas.',
  },
  {
    id: 'g4-mul-3',
    gradeLevel: 4,
    num1: 45,
    num2: 8,
    operation: '×',
    expectedAnswer: 360,
    itemType: 'itlog',
    itemEmoji: '🥚',
    explanationTagalog: '45 tray na may tig-8 itlog: 45 × 8 = 360 itlog.',
  },
  {
    id: 'g4-mul-4',
    gradeLevel: 4,
    num1: 65,
    num2: 6,
    operation: '×',
    expectedAnswer: 390,
    itemType: 'mag-aaral sa bawat pangkat',
    itemEmoji: '🎒',
    explanationTagalog: '65 mag-aaral sa bawat pangkat, may 6 na pangkat: 65 × 6 = 390 mag-aaral.',
  },
  {
    id: 'g4-div-1',
    gradeLevel: 4,
    num1: 180,
    num2: 6,
    operation: '÷',
    expectedAnswer: 30,
    itemType: 'krayola',
    itemEmoji: '🖍️',
    explanationTagalog: '180 krayola hinati sa 6 na kahon: tig-30 krayola bawat kahon.',
  },
  {
    id: 'g4-div-2',
    gradeLevel: 4,
    num1: 250,
    num2: 5,
    operation: '÷',
    expectedAnswer: 50,
    itemType: 'puno',
    itemEmoji: '🌳',
    explanationTagalog: '250 puno itinanim sa 5 hanay: tig-50 puno bawat hanay.',
  },
  {
    id: 'g4-div-3',
    gradeLevel: 4,
    num1: 420,
    num2: 7,
    operation: '÷',
    expectedAnswer: 60,
    itemType: 'pahina ng aklat',
    itemEmoji: '📖',
    explanationTagalog: '420 pahina binasa sa loob ng 7 araw: tig-60 pahina bawat araw.',
  },
  {
    id: 'g4-div-4',
    gradeLevel: 4,
    num1: 720,
    num2: 8,
    operation: '÷',
    expectedAnswer: 90,
    itemType: 'minuto ng pagsasanay',
    itemEmoji: '⏱️',
    explanationTagalog: '720 minuto hinati sa 8 linggo: tig-90 minuto bawat linggo.',
  },

  // ==========================================
  // BAITANG 5 (Grade 5): DepEd ARAL Program
  // Operations with larger numbers, fractions, decimals, ratios, area & volume
  // ==========================================
  {
    id: 'g5-add-1',
    gradeLevel: 5,
    num1: 3450,
    num2: 2780,
    operation: '+',
    expectedAnswer: 6230,
    itemType: 'puntos sa laro',
    itemEmoji: '🏆',
    explanationTagalog: '3,450 puntos dagdagan ng 2,780 puntos ay 6,230 kabuuang puntos.',
  },
  {
    id: 'g5-add-2',
    gradeLevel: 5,
    num1: 8650,
    num2: 4350,
    operation: '+',
    expectedAnswer: 13000,
    itemType: 'barya',
    itemEmoji: '🪙',
    explanationTagalog: '8,650 barya dagdagan ng 4,350 barya ay 13,000 barya.',
  },
  {
    id: 'g5-sub-1',
    gradeLevel: 5,
    num1: 6500,
    num2: 2750,
    operation: '-',
    expectedAnswer: 3750,
    itemType: 'kilo ng bigas',
    itemEmoji: '🍚',
    explanationTagalog: '6,500 kilo ng bigas ibinawas ang 2,750 kilo: 3,750 kilo ang natira.',
  },
  {
    id: 'g5-sub-2',
    gradeLevel: 5,
    num1: 15000,
    num2: 6450,
    operation: '-',
    expectedAnswer: 8550,
    itemType: 'pondo sa komunidad',
    itemEmoji: '🏦',
    explanationTagalog: '15,000 pondo ibinawas ang 6,450: 8,550 ang natira.',
  },
  {
    id: 'g5-mul-1',
    gradeLevel: 5,
    num1: 75,
    num2: 12,
    operation: '×',
    expectedAnswer: 900,
    itemType: 'kahon ng donasyon',
    itemEmoji: '📦',
    explanationTagalog: '75 donasyon bawat trak, may 12 trak: 75 × 12 = 900 donasyon.',
  },
  {
    id: 'g5-mul-2',
    gradeLevel: 5,
    num1: 125,
    num2: 8,
    operation: '×',
    expectedAnswer: 1000,
    itemType: 'itlog',
    itemEmoji: '🥚',
    explanationTagalog: '125 kahon na may tig-8 itlog: 125 × 8 = 1,000 itlog.',
  },
  {
    id: 'g5-mul-3',
    gradeLevel: 5,
    num1: 85,
    num2: 15,
    operation: '×',
    expectedAnswer: 1275,
    itemType: 'metro kuwadrado (Area)',
    itemEmoji: '📐',
    explanationTagalog: 'Haba 85m × Lapad 15m: 85 × 15 = 1,275 metro kuwadrado.',
  },
  {
    id: 'g5-div-1',
    gradeLevel: 5,
    num1: 840,
    num2: 12,
    operation: '÷',
    expectedAnswer: 70,
    itemType: 'aklat',
    itemEmoji: '📚',
    explanationTagalog: '840 aklat hinati sa 12 paaralan: tig-70 aklat bawat paaralan.',
  },
  {
    id: 'g5-div-2',
    gradeLevel: 5,
    num1: 1500,
    num2: 25,
    operation: '÷',
    expectedAnswer: 60,
    itemType: 'punla ng gulay',
    itemEmoji: '🌱',
    explanationTagalog: '1,500 punla hinati sa 25 magsasaka: tig-60 punla bawat isa.',
  },
  {
    id: 'g5-div-3',
    gradeLevel: 5,
    num1: 2400,
    num2: 30,
    operation: '÷',
    expectedAnswer: 80,
    itemType: 'kilometro bawat oras',
    itemEmoji: '🚂',
    explanationTagalog: '2,400 kilometro sa 30 oras: bilis ay 80 km/h.',
  },

  // ==========================================
  // BAITANG 6 (Grade 6): DepEd ARAL Program
  // Advanced operations, percentages, ratios, decimals, PEMDAS, integers & algebra
  // ==========================================
  {
    id: 'g6-add-1',
    gradeLevel: 6,
    num1: 14500,
    num2: 8750,
    operation: '+',
    expectedAnswer: 23250,
    itemType: 'litro ng bio-fuel',
    itemEmoji: '⛽',
    explanationTagalog: '14,500 litro dagdagan ng 8,750 litro ay 23,250 litro.',
  },
  {
    id: 'g6-add-2',
    gradeLevel: 6,
    num1: 32400,
    num2: 17600,
    operation: '+',
    expectedAnswer: 50000,
    itemType: 'solar energy watts',
    itemEmoji: '☀️',
    explanationTagalog: '32,400 watts dagdagan ng 17,600 watts ay 50,000 kabuuang watts.',
  },
  {
    id: 'g6-sub-1',
    gradeLevel: 6,
    num1: 25000,
    num2: 12850,
    operation: '-',
    expectedAnswer: 12150,
    itemType: 'piso na natira sa badyet',
    itemEmoji: '💰',
    explanationTagalog: '25,000 badyet ibinawas ang 12,850: 12,150 ang natira.',
  },
  {
    id: 'g6-sub-2',
    gradeLevel: 6,
    num1: 45000,
    num2: 18500,
    operation: '-',
    expectedAnswer: 26500,
    itemType: 'metro ng kable',
    itemEmoji: '🔌',
    explanationTagalog: '45,000 metro ibinawas ang 18,500 metro: 26,500 metro ang natitira.',
  },
  {
    id: 'g6-mul-1',
    gradeLevel: 6,
    num1: 150,
    num2: 24,
    operation: '×',
    expectedAnswer: 3600,
    itemType: 'segundo sa 1 oras',
    itemEmoji: '⏱️',
    explanationTagalog: '150 yunit × 24 na oras: 150 × 24 = 3,600.',
  },
  {
    id: 'g6-mul-2',
    gradeLevel: 6,
    num1: 225,
    num2: 16,
    operation: '×',
    expectedAnswer: 3600,
    itemType: 'metro kuwadrado ng sakahan',
    itemEmoji: '🚜',
    explanationTagalog: '225m haba × 16m lapad: 225 × 16 = 3,600 metro kuwadrado.',
  },
  {
    id: 'g6-mul-3',
    gradeLevel: 6,
    num1: 350,
    num2: 18,
    operation: '×',
    expectedAnswer: 6300,
    itemType: 'baryang naipon',
    itemEmoji: '🪙',
    explanationTagalog: '350 barya bawat araw sa 18 araw: 350 × 18 = 6,300 barya.',
  },
  {
    id: 'g6-div-1',
    gradeLevel: 6,
    num1: 4800,
    num2: 40,
    operation: '÷',
    expectedAnswer: 120,
    itemType: 'pakete ng relief goods',
    itemEmoji: '📦',
    explanationTagalog: '4,800 pakete hinati sa 40 barangay: tig-120 pakete bawat barangay.',
  },
  {
    id: 'g6-div-2',
    gradeLevel: 6,
    num1: 7500,
    num2: 25,
    operation: '÷',
    expectedAnswer: 300,
    itemType: 'puno bawat rehiyon',
    itemEmoji: '🌲',
    explanationTagalog: '7,500 puno hinati sa 25 komunidad: tig-300 puno bawat isa.',
  },
  {
    id: 'g6-div-3',
    gradeLevel: 6,
    num1: 9600,
    num2: 32,
    operation: '÷',
    expectedAnswer: 300,
    itemType: 'metro bawat lap',
    itemEmoji: '🏃',
    explanationTagalog: '9,600 metro hinati sa 32 laps: 9,600 ÷ 32 = 300 metro bawat lap.',
  },
];

// Baseline items for Baitang 4 (default entry point)
export const DEFAULT_GRADE_4_ITEMS: MathItem[] = MATH_CURRICULUM_ITEMS.filter(
  (item) => item.gradeLevel === 4
);

// Backward compatibility alias for older imports
export const DEFAULT_GRADE_1_ITEMS: MathItem[] = DEFAULT_GRADE_4_ITEMS;

const EMOJI_PALETTE = ['📐', '🌾', '🌲', '💵', '💧', '🚗', '🍶', '🌹', '🥚', '🎒', '🖍️', '🌳', '📖', '⏱️', '🏆', '🪙', '🍚', '📦', '🌱', '🚂', '☀️', '🚜'];

/**
 * Generate a clean, DepEd ARAL curriculum-aligned randomized math problem for Grade 4 to 6
 */
export function generateMathProblem(
  grade: number,
  operationChoice?: MathOperation
): MathItem {
  // Strictly clamp between Grade 4 and Grade 6!
  const g = Math.min(6, Math.max(4, grade));
  
  // All 4 fundamental operations allowed for Key Stage 2 (Grades 4-6)
  const allowedOps: MathOperation[] = ['+', '-', '×', '÷'];

  const op = operationChoice && allowedOps.includes(operationChoice)
    ? operationChoice
    : allowedOps[Math.floor(Math.random() * allowedOps.length)];

  let num1 = 100;
  let num2 = 10;
  let expectedAnswer = 110;
  const emoji = EMOJI_PALETTE[Math.floor(Math.random() * EMOJI_PALETTE.length)];

  if (op === '+') {
    if (g === 4) {
      num1 = Math.floor(Math.random() * 800) + 200;
      num2 = Math.floor(Math.random() * 600) + 100;
    } else if (g === 5) {
      num1 = Math.floor(Math.random() * 4000) + 1000;
      num2 = Math.floor(Math.random() * 3000) + 500;
    } else {
      // Grade 6
      num1 = Math.floor(Math.random() * 15000) + 5000;
      num2 = Math.floor(Math.random() * 12000) + 3000;
    }
    expectedAnswer = num1 + num2;
  } else if (op === '-') {
    if (g === 4) {
      expectedAnswer = Math.floor(Math.random() * 600) + 150;
      num2 = Math.floor(Math.random() * 400) + 100;
      num1 = expectedAnswer + num2;
    } else if (g === 5) {
      expectedAnswer = Math.floor(Math.random() * 3500) + 800;
      num2 = Math.floor(Math.random() * 2500) + 500;
      num1 = expectedAnswer + num2;
    } else {
      // Grade 6
      expectedAnswer = Math.floor(Math.random() * 12000) + 3000;
      num2 = Math.floor(Math.random() * 8000) + 2000;
      num1 = expectedAnswer + num2;
    }
  } else if (op === '×') {
    if (g === 4) {
      num1 = Math.floor(Math.random() * 45) + 15; // 15-59
      num2 = Math.floor(Math.random() * 7) + 3; // 3-9
    } else if (g === 5) {
      num1 = Math.floor(Math.random() * 70) + 25; // 25-94
      num2 = Math.floor(Math.random() * 14) + 10; // 10-23
    } else {
      // Grade 6
      num1 = Math.floor(Math.random() * 120) + 40; // 40-159
      num2 = Math.floor(Math.random() * 25) + 15; // 15-39
    }
    expectedAnswer = num1 * num2;
  } else {
    // op === '÷'
    if (g === 4) {
      num2 = Math.floor(Math.random() * 8) + 4; // 4-11
      expectedAnswer = Math.floor(Math.random() * 40) + 15; // 15-54
    } else if (g === 5) {
      num2 = Math.floor(Math.random() * 20) + 10; // 10-29
      expectedAnswer = Math.floor(Math.random() * 50) + 20; // 20-69
    } else {
      // Grade 6
      num2 = Math.floor(Math.random() * 35) + 15; // 15-49
      expectedAnswer = Math.floor(Math.random() * 80) + 25; // 25-104
    }
    num1 = expectedAnswer * num2;
  }

  return {
    id: `aral-math-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    gradeLevel: g,
    num1,
    num2,
    operation: op,
    expectedAnswer,
    itemType: 'bagay',
    itemEmoji: emoji,
    explanationTagalog: `${num1.toLocaleString()} ${op} ${num2.toLocaleString()} = ${expectedAnswer.toLocaleString()}`,
  };
}

/**
 * Generate 3 sensible multiple-choice distractors close to the expected answer
 */
export function getDistractorChoices(expectedAnswer: number): number[] {
  const choices = new Set<number>([expectedAnswer]);
  const deltas = [-10, -5, -2, -1, 1, 2, 5, 10, 20, -20, 50, -50];
  
  // Shuffle deltas
  const shuffledDeltas = [...deltas].sort(() => Math.random() - 0.5);

  for (const delta of shuffledDeltas) {
    const candidate = expectedAnswer + delta;
    if (candidate >= 0 && candidate !== expectedAnswer) {
      choices.add(candidate);
    }
    if (choices.size >= 4) break;
  }

  // Fallback if needed
  let counter = 1;
  while (choices.size < 4) {
    choices.add(expectedAnswer + counter * 5);
    counter++;
  }

  return Array.from(choices).sort(() => Math.random() - 0.5);
}

/**
 * Speech prompt in natural Filipino for math problems
 */
export function getMathQuestionSpeech(item: MathItem): string {
  let opWord = 'dagdagan ng';
  if (item.operation === '-') opWord = 'bawasan ng';
  if (item.operation === '×') opWord = 'i-multiply sa';
  if (item.operation === '÷') opWord = 'hatiin sa';

  return `Ilan ang ${item.num1.toLocaleString()} ${opWord} ${item.num2.toLocaleString()}?`;
}
