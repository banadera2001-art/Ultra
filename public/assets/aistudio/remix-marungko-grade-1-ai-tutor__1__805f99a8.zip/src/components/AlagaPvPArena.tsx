import React, { useState, useEffect, useRef } from 'react';
import { StudentProfile, OwnedPet, PetDefinition } from '../types';
import { PET_CATALOG, getPetById } from '../data/petsData';
import { DragonCityPet } from './DragonCityPet';
import {
  multiplayerService,
  AlagaPetCombatant,
  AlagaRoomState,
} from '../services/multiplayerService';
import {
  Swords,
  Shield,
  Zap,
  Sparkles,
  Trophy,
  ArrowLeft,
  RotateCcw,
  Star,
  Flame,
  CheckCircle2,
  XCircle,
  Heart,
  Volume2,
  Copy,
  Users,
  Radio,
  Send,
  MessageSquare,
  Crown,
  HelpCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  playAttackSound,
  playSpecialSkillSound,
  playCriticalHitSound,
  playBattleVictorySound,
  playStarSound,
  playSuccessFanfare,
} from '../services/soundEffects';
import { speakTagalog } from '../services/speechService';

interface AlagaPvPArenaProps {
  activeStudent: StudentProfile;
  voiceEnabled: boolean;
  onAwardStars?: (count: number, reason?: string) => void;
  onAddPetExp?: (
    petId: string,
    exp: number
  ) => { leveledUp: boolean; newLevel?: number; newStage?: string };
  onClose?: () => void;
}

interface FloatingVfx {
  id: number;
  text: string;
  color: string;
  target: 'myPet' | 'opponentPet';
}

export const AlagaPvPArena: React.FC<AlagaPvPArenaProps> = ({
  activeStudent,
  voiceEnabled,
  onAwardStars,
  onAddPetExp,
  onClose,
}) => {
  // Connection and Room States
  const [isWsOnline, setIsWsOnline] = useState<boolean>(multiplayerService.getOnlineStatus());
  const [roomCodeInput, setRoomCodeInput] = useState<string>('ROOM-1');
  const [activeRoomState, setActiveRoomState] = useState<AlagaRoomState | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // 3 Pets Roster Selection
  const ownedPets: OwnedPet[] = activeStudent.ownedPets || [];
  const default3Pets = (): string[] => {
    const list: string[] = [];
    if (activeStudent.activePetId) list.push(activeStudent.activePetId);
    ownedPets.forEach((p) => {
      if (!list.includes(p.petId)) list.push(p.petId);
    });
    // Fill up to 3 from catalog if needed
    PET_CATALOG.forEach((p) => {
      if (list.length < 3 && !list.includes(p.id)) list.push(p.id);
    });
    return list.slice(0, 3);
  };

  const [selectedTeamPetIds, setSelectedTeamPetIds] = useState<string[]>(default3Pets());

  // Animations & Floating texts
  const [myAnim, setMyAnim] = useState<'idle' | 'attack' | 'hit' | 'defend' | 'victory'>('idle');
  const [oppAnim, setOppAnim] = useState<'idle' | 'attack' | 'hit' | 'defend' | 'victory'>('idle');
  const [floatingTexts, setFloatingTexts] = useState<FloatingVfx[]>([]);
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<
    { senderId: string; senderName: string; message: string; timestamp: number }[]
  >([]);

  // Mini quiz power-up question (Quick math/reading boost for 1.5x damage)
  const [showPowerUpQuiz, setShowPowerUpQuiz] = useState<boolean>(false);
  const [pendingAttackType, setPendingAttackType] = useState<'basic' | 'special' | 'ultimate'>('basic');
  const [quizQuestion, setQuizQuestion] = useState<{
    q: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }>({
    q: '3 + 4 = ?',
    options: ['6', '7', '8', '9'],
    correctIndex: 1,
    explanation: '3 + 4 = 7!',
  });

  // Track WebSocket connection and room events
  useEffect(() => {
    const unsubStatus = multiplayerService.on('connection_status', (data) => {
      setIsWsOnline(Boolean(data?.online));
    });

    const unsubRoom = multiplayerService.on('alaga_room_updated', (data: AlagaRoomState) => {
      setActiveRoomState(data);
      setErrorMessage(null);
    });

    const unsubAttack = multiplayerService.on('alaga_attack_result', (data: any) => {
      const isMyAttack = data.attackerPlayerId === activeStudent.id;
      const targetSide = isMyAttack ? 'opponentPet' : 'myPet';

      if (isMyAttack) {
        setMyAnim('attack');
        setTimeout(() => setMyAnim('idle'), 700);
        setTimeout(() => {
          setOppAnim('hit');
          setTimeout(() => setOppAnim('idle'), 600);
        }, 300);
      } else {
        setOppAnim('attack');
        setTimeout(() => setOppAnim('idle'), 700);
        setTimeout(() => {
          setMyAnim('hit');
          setTimeout(() => setMyAnim('idle'), 600);
        }, 300);
      }

      if (data.isCritical) {
        playCriticalHitSound();
      } else {
        playAttackSound();
      }

      // Add floating damage text
      const newVfx: FloatingVfx = {
        id: Date.now() + Math.random(),
        text: `-${data.damage} HP${data.isCritical ? ' 💥 KRITIKAL!' : ''}`,
        color: data.isCritical ? 'text-amber-300' : 'text-red-400',
        target: targetSide,
      };
      setFloatingTexts((prev) => [...prev, newVfx]);
      setTimeout(() => {
        setFloatingTexts((prev) => prev.filter((t) => t.id !== newVfx.id));
      }, 1600);

      // Update room state
      if (data.room) {
        setActiveRoomState(data.room);
      }
    });

    const unsubChat = multiplayerService.on('alaga_chat_message', (data: any) => {
      setChatMessages((prev) => [...prev.slice(-20), data]);
    });

    const unsubError = multiplayerService.on('alaga_error', (data: any) => {
      setErrorMessage(data?.message || 'Nagkaroon ng problema sa Arena.');
    });

    return () => {
      unsubStatus();
      unsubRoom();
      unsubAttack();
      unsubChat();
      unsubError();
    };
  }, [activeStudent.id]);

  // Construct the 3 Alaga Combatants payload
  const buildTeamPayload = (): AlagaPetCombatant[] => {
    return selectedTeamPetIds.map((petId, idx) => {
      const owned = ownedPets.find((p) => p.petId === petId);
      const def = getPetById(petId);
      const lvl = owned ? owned.level : 1;
      const stg = owned ? owned.stage : 'Baby';
      const maxHp = 100 + lvl * 25;
      const petName = owned?.nickname || def?.nameTagalog || `Alaga #${idx + 1}`;

      return {
        petId,
        name: petName,
        element: def?.element || 'fire',
        stage: stg,
        level: lvl,
        maxHp,
        currentHp: maxHp,
        isFainted: false,
        basicSkill: `Talon ni ${petName}`,
        specialSkill: def?.specialSkillTagalog || `Kapangyarihan ni ${petName}`,
      };
    });
  };

  // Join or Create Room with Room Code
  const handleJoinOrCreate = (codeToJoin?: string) => {
    const targetCode = (codeToJoin || roomCodeInput).trim().toUpperCase();
    if (!targetCode) {
      setErrorMessage('Mag-type ng Room Code bago sumali.');
      return;
    }

    const team = buildTeamPayload();
    multiplayerService.joinAlagaRoom(targetCode, {
      id: activeStudent.id,
      name: activeStudent.name,
      avatar: activeStudent.avatar || '🐾',
      team,
    });
  };

  // Mark player as ready
  const handleReady = () => {
    if (!activeRoomState) return;
    multiplayerService.readyAlagaPlayer(activeRoomState.code, activeStudent.id);
  };

  // Generate Random Room Code
  const handleGenerateCode = () => {
    const letters = ['ARENA', 'PET', 'LABAN', 'ALAGA', 'KID'];
    const prefix = letters[Math.floor(Math.random() * letters.length)];
    const num = Math.floor(Math.random() * 900) + 100;
    const code = `${prefix}-${num}`;
    setRoomCodeInput(code);
    handleJoinOrCreate(code);
  };

  // Quick Match: Join ROOM-1
  const handleQuickMatch = () => {
    setRoomCodeInput('ROOM-1');
    handleJoinOrCreate('ROOM-1');
  };

  // Copy Code to Clipboard
  const handleCopyCode = () => {
    if (!activeRoomState) return;
    navigator.clipboard?.writeText(activeRoomState.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Quick Chat sender
  const handleSendChat = (presetText?: string) => {
    const text = (presetText || chatInput).trim();
    if (!text || !activeRoomState) return;
    multiplayerService.sendAlagaChat(
      activeRoomState.code,
      activeStudent.id,
      activeStudent.name,
      text
    );
    setChatInput('');
  };

  // Trigger attack
  const handleAttackClick = (type: 'basic' | 'special' | 'ultimate') => {
    if (!activeRoomState || activeRoomState.battleState !== 'battling') return;

    // Check if it's my turn
    const isMyTurn = activeRoomState.currentTurnPlayerId === activeStudent.id;
    if (!isMyTurn) {
      if (voiceEnabled) speakTagalog('Hinihintay pa ang tira ng iyong kalaro.');
      return;
    }

    // Generate quick educational math power-up question for fun and critical hit
    const n1 = Math.floor(Math.random() * 12) + 1;
    const n2 = Math.floor(Math.random() * 12) + 1;
    const isAdd = Math.random() > 0.4;
    const ans = isAdd ? n1 + n2 : Math.max(n1, n2) - Math.min(n1, n2);
    const qStr = isAdd ? `${n1} + ${n2} = ?` : `${Math.max(n1, n2)} - ${Math.min(n1, n2)} = ?`;

    const distractors = [ans + 1, ans - 1, ans + 2]
      .filter((d) => d >= 0)
      .map(String);
    const opts = [String(ans), ...distractors.slice(0, 3)].sort(() => Math.random() - 0.5);

    setQuizQuestion({
      q: qStr,
      options: opts,
      correctIndex: opts.indexOf(String(ans)),
      explanation: `${qStr} Ang sagot ay ${ans}!`,
    });
    setPendingAttackType(type);
    setShowPowerUpQuiz(true);
  };

  // Execute attack with quiz resolution
  const handleAnswerQuiz = (selectedIdx: number) => {
    setShowPowerUpQuiz(false);
    if (!activeRoomState) return;

    const isCorrect = selectedIdx === quizQuestion.correctIndex;
    const myPlayer = activeRoomState.players[activeStudent.id];
    const opponentId = Object.keys(activeRoomState.players).find((id) => id !== activeStudent.id);
    if (!myPlayer || !opponentId) return;

    const myActivePet = myPlayer.team[myPlayer.activePetIndex];
    let baseDmg = 25;
    let skillName = myActivePet.basicSkill;

    if (pendingAttackType === 'special') {
      baseDmg = 40;
      skillName = myActivePet.specialSkill;
    } else if (pendingAttackType === 'ultimate') {
      baseDmg = 55;
      skillName = `💥 Ultimong Kapangyarihan ni ${myActivePet.name}!`;
    }

    if (isCorrect) {
      baseDmg = Math.round(baseDmg * 1.5); // 150% Critical Hit!
    }

    multiplayerService.sendAlagaAttack(activeRoomState.code, {
      attackerPlayerId: activeStudent.id,
      targetPlayerId: opponentId,
      attackType: pendingAttackType,
      skillName,
      damage: baseDmg,
      isCritical: isCorrect,
      textPrompt: isCorrect ? `⭐ Tumpak ang sagot sa ${quizQuestion.q}! Critical Hit!` : undefined,
    });
  };

  // Direct skip attack without quiz (if player wants quick attack)
  const handleSkipQuizAndAttack = () => {
    setShowPowerUpQuiz(false);
    if (!activeRoomState) return;
    const myPlayer = activeRoomState.players[activeStudent.id];
    const opponentId = Object.keys(activeRoomState.players).find((id) => id !== activeStudent.id);
    if (!myPlayer || !opponentId) return;

    const myActivePet = myPlayer.team[myPlayer.activePetIndex];
    const baseDmg = pendingAttackType === 'special' ? 35 : pendingAttackType === 'ultimate' ? 45 : 25;

    multiplayerService.sendAlagaAttack(activeRoomState.code, {
      attackerPlayerId: activeStudent.id,
      targetPlayerId: opponentId,
      attackType: pendingAttackType,
      skillName: myActivePet.basicSkill,
      damage: baseDmg,
      isCritical: false,
    });
  };

  // Rematch
  const handleRematch = () => {
    if (!activeRoomState) return;
    multiplayerService.sendAlagaRematch(activeRoomState.code);
  };

  // Leave room
  const handleLeaveRoom = () => {
    if (activeRoomState) {
      multiplayerService.leaveAlagaRoom(activeRoomState.code, activeStudent.id);
      setActiveRoomState(null);
    }
  };

  // Extract my player and opponent player from room state
  const myPlayer = activeRoomState?.players[activeStudent.id];
  const opponentId = activeRoomState
    ? Object.keys(activeRoomState.players).find((id) => id !== activeStudent.id)
    : undefined;
  const opponentPlayer = opponentId ? activeRoomState?.players[opponentId] : undefined;

  const myActivePet = myPlayer ? myPlayer.team[myPlayer.activePetIndex] : null;
  const oppActivePet = opponentPlayer ? opponentPlayer.team[opponentPlayer.activePetIndex] : null;

  const isMyTurn =
    activeRoomState?.battleState === 'battling' &&
    activeRoomState.currentTurnPlayerId === activeStudent.id;

  const isMatchFinished = activeRoomState?.battleState === 'finished';
  const isWinner = isMatchFinished && activeRoomState?.winnerPlayerId === activeStudent.id;

  // Award stars on victory
  useEffect(() => {
    if (isWinner) {
      playBattleVictorySound();
      playSuccessFanfare();
      confetti({
        particleCount: 150,
        spread: 90,
        origin: { y: 0.5 },
      });
      if (onAwardStars) onAwardStars(50, 'PvP Arena Victory');
      if (myActivePet && onAddPetExp) onAddPetExp(myActivePet.petId, 80);
    }
  }, [isWinner]);

  return (
    <div className="flex-1 min-h-0 h-full w-full flex flex-col overflow-hidden bg-gradient-to-b from-[#FFFBEB] via-[#FEF3C7] to-[#FDE68A] select-none">
      {/* ========================================================= */}
      {/* TOP HEADER: Title, Live Online Badge, Back Button         */}
      {/* ========================================================= */}
      <div className="bg-white/95 border-b-2 border-orange-200 px-3 py-2 shadow-xs shrink-0 flex items-center justify-between gap-2 max-w-7xl mx-auto w-full backdrop-blur-xs">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {onClose && (
            <button
              onClick={() => {
                handleLeaveRoom();
                onClose();
              }}
              className="p-1.5 rounded-xl bg-orange-100 hover:bg-orange-200 text-orange-900 border border-orange-300 transition-all cursor-pointer shadow-xs active:scale-95"
              title="Bumalik sa Alaga Nursery"
            >
              <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          )}

          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-lg shadow-xs border border-white text-white shrink-0">
            ⚔️
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h2 className="text-xs sm:text-base font-black text-[#4B2C20] truncate">
                Alaga PvP Combat Arena (1v1)
              </h2>
              <span className="bg-red-500 text-white text-[9px] sm:text-[10px] px-2 py-0.2 rounded-full font-black uppercase tracking-wider shrink-0 animate-pulse">
                3 Sets ng Alaga
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-[#8B4513] font-bold truncate hidden sm:block">
              Mag-type ng Code upang makipaglaban nang real-time sa kaklase o kaibigan!
            </p>
          </div>
        </div>

        {/* Live Server Indicator & Active Room Badge */}
        <div className="flex items-center gap-2 shrink-0">
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] sm:text-xs font-black border ${
              isWsOnline
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-rose-50 text-rose-800 border-rose-300'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isWsOnline ? 'bg-emerald-500 animate-ping' : 'bg-rose-500'
              }`}
            />
            <span>{isWsOnline ? '🟢 Live Online' : '🔴 Reconnecting...'}</span>
          </div>

          {activeRoomState && (
            <div className="flex items-center gap-1 bg-amber-100 border border-amber-300 px-2 py-1 rounded-xl text-xs font-black text-amber-900">
              <span>Room: {activeRoomState.code}</span>
              <button
                onClick={handleCopyCode}
                className="hover:text-amber-700 p-0.5"
                title="Kopyahin ang Room Code"
              >
                {copiedCode ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================= */}
      {/* STAGE 1: ROOM CODE JOINING & 3-PET ROSTER SELECTION        */}
      {/* ========================================================= */}
      {!activeRoomState && (
        <div className="flex-1 min-h-0 overflow-y-auto p-3 sm:p-6 max-w-4xl mx-auto w-full flex flex-col justify-between gap-4">
          <div className="bg-white rounded-3xl border-3 border-orange-300 p-4 sm:p-6 shadow-lg space-y-4">
            <div className="text-center space-y-1">
              <span className="text-3xl">🏟️</span>
              <h3 className="text-lg sm:text-2xl font-black text-[#4B2C20]">
                Pumasok sa PvP Combat Arena
              </h3>
              <p className="text-xs sm:text-sm text-[#8B4513] font-bold">
                I-type ang parehong Room Code ng iyong kalaro upang magharap ang inyong 3 sets ng Alaga!
              </p>
            </div>

            {/* Room Code Entry Box */}
            <div className="bg-orange-50 border-2 border-orange-200 p-3 sm:p-4 rounded-2xl space-y-3">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
                <div className="relative w-full sm:w-64">
                  <input
                    type="text"
                    value={roomCodeInput}
                    onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase())}
                    placeholder="Ilagay ang Room Code..."
                    maxLength={10}
                    className="w-full text-center text-lg sm:text-xl font-mono font-black uppercase bg-white border-2 border-orange-400 rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-orange-500 shadow-inner text-[#4B2C20]"
                  />
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => handleJoinOrCreate()}
                    className="flex-1 sm:flex-none px-5 py-2.5 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-black text-sm rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Swords className="w-4 h-4" />
                    <span>Sumali sa Laban</span>
                  </button>

                  <button
                    onClick={handleGenerateCode}
                    className="px-3 py-2.5 bg-amber-200 hover:bg-amber-300 text-amber-950 font-black text-xs rounded-xl border border-amber-300 transition-all cursor-pointer shadow-xs"
                    title="Gumawa ng bagong random code"
                  >
                    🎲 Bagong Code
                  </button>

                  <button
                    onClick={handleQuickMatch}
                    className="px-3 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-black text-xs rounded-xl shadow-xs transition-all cursor-pointer"
                    title="Mabilisang Laban sa ROOM-1"
                  >
                    ⚡ ROOM-1
                  </button>
                </div>
              </div>

              {errorMessage && (
                <div className="p-2 rounded-xl bg-rose-100 border border-rose-300 text-rose-800 text-xs font-black text-center">
                  ⚠️ {errorMessage}
                </div>
              )}
            </div>

            {/* 3 Sets of Alaga Selection */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs sm:text-sm font-black text-[#4B2C20] flex items-center gap-1">
                  <span>🐾</span>
                  <span>Pumili ng 3 Alaga para sa iyong Koponan:</span>
                </span>
                <span className="text-[10px] sm:text-xs text-orange-700 font-bold bg-orange-100 px-2 py-0.5 rounded-full">
                  1-on-1 Salitan kapag Nawalan ng Malay
                </span>
              </div>

              {/* 3 Selected Pet Slots */}
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                {[0, 1, 2].map((slotIdx) => {
                  const petId = selectedTeamPetIds[slotIdx];
                  const petDef = getPetById(petId);
                  const owned = ownedPets.find((p) => p.petId === petId);
                  const petName = owned?.nickname || petDef?.nameTagalog || `Alaga #${slotIdx + 1}`;
                  const slotLabels = ['1. Unang Lalaban ⚔️', '2. Reserba #1 🛡️', '3. Reserba #2 🌟'];

                  return (
                    <div
                      key={slotIdx}
                      className="bg-gradient-to-b from-amber-50 to-orange-50 border-2 border-orange-300 rounded-2xl p-2 sm:p-3 flex flex-col items-center justify-between shadow-xs relative"
                    >
                      <span className="text-[9px] sm:text-[10px] font-black text-orange-800 uppercase tracking-wide bg-orange-200/80 px-2 py-0.5 rounded-full mb-1">
                        {slotLabels[slotIdx]}
                      </span>

                      {petDef && (
                        <div className="scale-75 sm:scale-90 my-[-10px]">
                          <DragonCityPet
                            petId={petDef.id}
                            emoji={petDef.emoji}
                            name={petDef.name}
                            nameTagalog={petName}
                            element={petDef.element}
                            stage={owned?.stage || 'Baby'}
                            size="md"
                            interactive={false}
                            animationState="idle"
                            showAura={true}
                            showShadow={true}
                          />
                        </div>
                      )}

                      <div className="text-center w-full mt-1">
                        <span className="font-black text-xs sm:text-sm text-[#4B2C20] block truncate">
                          {petName}
                        </span>
                        <span className="text-[9px] text-[#8B4513] font-bold block">
                          Lv.{owned?.level || 1} • {petDef?.element.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Pet Catalog Picker Row */}
              <div className="space-y-1 mt-2">
                <span className="text-[11px] font-bold text-orange-900 block">
                  Pindutin ang alaga sa ibaba upang ilagay sa iyong koponan:
                </span>
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                  {PET_CATALOG.slice(0, 15).map((pet) => {
                    const isSelected = selectedTeamPetIds.includes(pet.id);
                    const slotNum = selectedTeamPetIds.indexOf(pet.id) + 1;
                    return (
                      <button
                        key={pet.id}
                        onClick={() => {
                          if (isSelected) return;
                          setSelectedTeamPetIds((prev) => [prev[1], prev[2], pet.id]);
                        }}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-black shrink-0 border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-orange-500 text-white border-orange-600 shadow-xs'
                            : 'bg-white hover:bg-orange-50 text-orange-950 border-orange-200'
                        }`}
                      >
                        <span>{pet.emoji}</span>
                        <span className="truncate max-w-[80px]">{pet.nameTagalog}</span>
                        {isSelected && (
                          <span className="w-4 h-4 rounded-full bg-white text-orange-600 text-[10px] font-black flex items-center justify-center">
                            #{slotNum}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* STAGE 2: LOBBY WAITING ROOM (2 Players Joined)            */}
      {/* ========================================================= */}
      {activeRoomState && activeRoomState.battleState === 'ready' && (
        <div className="flex-1 min-h-0 overflow-y-auto p-3 sm:p-6 max-w-4xl mx-auto w-full flex flex-col justify-between gap-4">
          <div className="bg-white rounded-3xl border-3 border-orange-300 p-4 sm:p-6 shadow-lg space-y-4">
            <div className="text-center space-y-1">
              <span className="text-xs font-black uppercase text-orange-700 bg-orange-100 px-3 py-1 rounded-full border border-orange-200">
                Arena Room Code: {activeRoomState.code}
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#4B2C20]">
                Nandito na ang Dalawang Manlalaro!
              </h3>
              <p className="text-xs text-[#8B4513] font-bold">
                Pindutin ang "Handa na sa Laban" upang simulan ang laban ng inyong mga alaga!
              </p>
            </div>

            {/* 2 Players Side by Side Showcase */}
            <div className="grid grid-cols-2 gap-3 sm:gap-6">
              {/* You (Player 1) */}
              <div
                className={`p-3 sm:p-4 rounded-2xl border-2 flex flex-col items-center justify-between text-center gap-2 ${
                  myPlayer?.isReady
                    ? 'bg-emerald-50 border-emerald-400'
                    : 'bg-orange-50 border-orange-300'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-xl">{myPlayer?.avatar || '👦'}</span>
                  <span className="font-black text-sm sm:text-base text-[#4B2C20]">
                    {myPlayer?.name} (Ikaw)
                  </span>
                </div>

                <div className="flex items-center justify-center gap-1">
                  {myPlayer?.team.map((pet, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 bg-white border border-orange-200 rounded-lg text-xs font-black text-orange-900 truncate"
                    >
                      {pet.name}
                    </span>
                  ))}
                </div>

                <span
                  className={`text-xs font-black px-3 py-1 rounded-full ${
                    myPlayer?.isReady
                      ? 'bg-emerald-500 text-white shadow-xs'
                      : 'bg-amber-200 text-amber-900'
                  }`}
                >
                  {myPlayer?.isReady ? '✅ Handa Na!' : '⏳ Naghahanda pa...'}
                </span>
              </div>

              {/* Opponent (Player 2) */}
              <div
                className={`p-3 sm:p-4 rounded-2xl border-2 flex flex-col items-center justify-between text-center gap-2 ${
                  opponentPlayer?.isReady
                    ? 'bg-emerald-50 border-emerald-400'
                    : 'bg-orange-50 border-orange-300'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-xl">{opponentPlayer?.avatar || '👧'}</span>
                  <span className="font-black text-sm sm:text-base text-[#4B2C20]">
                    {opponentPlayer?.name || 'Kalaro'}
                  </span>
                </div>

                <div className="flex items-center justify-center gap-1">
                  {opponentPlayer?.team.map((pet, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 bg-white border border-orange-200 rounded-lg text-xs font-black text-orange-900 truncate"
                    >
                      {pet.name}
                    </span>
                  ))}
                </div>

                <span
                  className={`text-xs font-black px-3 py-1 rounded-full ${
                    opponentPlayer?.isReady
                      ? 'bg-emerald-500 text-white shadow-xs'
                      : 'bg-amber-200 text-amber-900'
                  }`}
                >
                  {opponentPlayer?.isReady ? '✅ Handa Na!' : '⏳ Naghahanda pa...'}
                </span>
              </div>
            </div>

            {/* Ready Action Button */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={handleReady}
                disabled={myPlayer?.isReady}
                className={`px-8 py-3 rounded-2xl font-black text-base transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-2 ${
                  myPlayer?.isReady
                    ? 'bg-emerald-600 text-white opacity-80 cursor-default'
                    : 'bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 text-white shadow-orange-300'
                }`}
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>{myPlayer?.isReady ? 'Naghihintay sa Kalaro...' : 'Handa na sa Laban!'}</span>
              </button>

              <button
                onClick={handleLeaveRoom}
                className="px-4 py-3 rounded-2xl font-black text-xs text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 transition-all cursor-pointer"
              >
                Lumabas
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* STAGE 3: ACTIVE 1-ON-1 ARENA BATTLE (3 Sets of Alaga)     */}
      {/* ========================================================= */}
      {activeRoomState && activeRoomState.battleState === 'battling' && myPlayer && opponentPlayer && (
        <div className="flex-1 min-h-0 flex flex-col justify-between p-2 sm:p-4 max-w-5xl mx-auto w-full gap-2">
          {/* Top Battlefield HUD: 3 Pets Roster Status Bar */}
          <div className="bg-white/90 backdrop-blur-xs rounded-2xl border-2 border-orange-300 p-2 sm:p-3 shadow-md flex items-center justify-between gap-2">
            {/* My 3 Pets Status */}
            <div className="flex items-center gap-2 min-w-0">
              <div className="text-left min-w-0">
                <span className="text-[10px] sm:text-xs font-black text-orange-900 block truncate">
                  {myPlayer.name} (Ikaw)
                </span>
                <div className="flex items-center gap-1 mt-0.5">
                  {myPlayer.team.map((pet, idx) => (
                    <div
                      key={idx}
                      title={`${pet.name} (${pet.currentHp}/${pet.maxHp} HP)`}
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center font-black text-xs border ${
                        pet.isFainted
                          ? 'bg-slate-200 border-slate-400 text-slate-400 opacity-60'
                          : idx === myPlayer.activePetIndex
                          ? 'bg-emerald-500 text-white border-emerald-300 ring-2 ring-emerald-400 scale-105'
                          : 'bg-amber-100 text-amber-900 border-amber-300'
                      }`}
                    >
                      {pet.isFainted ? '💀' : `P${idx + 1}`}
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Pet HP Bar */}
              {myActivePet && (
                <div className="w-24 sm:w-36 hidden sm:block">
                  <div className="flex justify-between text-[9px] font-black text-[#4B2C20]">
                    <span className="truncate">{myActivePet.name}</span>
                    <span>{myActivePet.currentHp}/{myActivePet.maxHp}</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden border border-slate-300 mt-0.5">
                    <div
                      className="h-full bg-emerald-500 transition-all duration-300"
                      style={{
                        width: `${Math.max(0, Math.min(100, (myActivePet.currentHp / myActivePet.maxHp) * 100))}%`,
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Turn Status Badge */}
            <div className="flex flex-col items-center shrink-0">
              <span
                className={`px-3 py-1 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider shadow-xs ${
                  isMyTurn
                    ? 'bg-emerald-500 text-white animate-pulse'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {isMyTurn ? '👉 Tira Mo Na!' : '⏳ Tira ng Kalaro...'}
              </span>
            </div>

            {/* Opponent 3 Pets Status */}
            <div className="flex items-center gap-2 min-w-0 justify-end">
              {oppActivePet && (
                <div className="w-24 sm:w-36 hidden sm:block text-right">
                  <div className="flex justify-between text-[9px] font-black text-[#4B2C20]">
                    <span>{oppActivePet.currentHp}/{oppActivePet.maxHp}</span>
                    <span className="truncate">{oppActivePet.name}</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden border border-slate-300 mt-0.5">
                    <div
                      className="h-full bg-rose-500 transition-all duration-300"
                      style={{
                        width: `${Math.max(0, Math.min(100, (oppActivePet.currentHp / oppActivePet.maxHp) * 100))}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              <div className="text-right min-w-0">
                <span className="text-[10px] sm:text-xs font-black text-orange-900 block truncate">
                  {opponentPlayer.name}
                </span>
                <div className="flex items-center justify-end gap-1 mt-0.5">
                  {opponentPlayer.team.map((pet, idx) => (
                    <div
                      key={idx}
                      title={`${pet.name} (${pet.currentHp}/${pet.maxHp} HP)`}
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center font-black text-xs border ${
                        pet.isFainted
                          ? 'bg-slate-200 border-slate-400 text-slate-400 opacity-60'
                          : idx === opponentPlayer.activePetIndex
                          ? 'bg-rose-500 text-white border-rose-300 ring-2 ring-rose-400 scale-105'
                          : 'bg-amber-100 text-amber-900 border-amber-300'
                      }`}
                    >
                      {pet.isFainted ? '💀' : `P${idx + 1}`}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Arena Battlefield Ground: 1v1 on Field */}
          <div className="flex-1 min-h-[220px] landscape:min-h-[160px] bg-gradient-to-b from-sky-200 via-amber-100 to-emerald-200 rounded-3xl border-3 border-orange-300 relative overflow-hidden flex items-center justify-between px-6 sm:px-16 shadow-inner">
            {/* Battlefield Floating VFX */}
            {floatingTexts.map((vfx) => (
              <div
                key={vfx.id}
                className={`absolute top-12 z-30 font-black text-base sm:text-xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] animate-bounce ${
                  vfx.target === 'myPet' ? 'left-12 sm:left-24' : 'right-12 sm:right-24'
                } ${vfx.color}`}
              >
                {vfx.text}
              </div>
            ))}

            {/* My Active Pet (Left Side) */}
            {myActivePet && (
              <div className="flex flex-col items-center relative">
                {/* Floating HP Bar */}
                <div className="bg-white/90 border border-emerald-400 rounded-full px-2 py-0.5 text-[10px] font-black text-emerald-900 shadow-xs mb-1 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-red-500 fill-red-500" />
                  <span>{myActivePet.name} ({myActivePet.currentHp} HP)</span>
                </div>

                <div className="transform scale-90 sm:scale-110">
                  <DragonCityPet
                    petId={myActivePet.petId}
                    emoji="🐾"
                    name={myActivePet.name}
                    nameTagalog={myActivePet.name}
                    element={myActivePet.element}
                    stage={myActivePet.stage}
                    size="lg"
                    interactive={false}
                    animationState={myAnim}
                    showAura={true}
                    showShadow={true}
                  />
                </div>
              </div>
            )}

            {/* Arena Center VS Emblem */}
            <div className="flex flex-col items-center">
              <span className="text-2xl sm:text-4xl font-black text-orange-600 drop-shadow-md">
                ⚔️ VS ⚔️
              </span>
            </div>

            {/* Opponent Active Pet (Right Side - Flipped) */}
            {oppActivePet && (
              <div className="flex flex-col items-center relative">
                {/* Floating HP Bar */}
                <div className="bg-white/90 border border-rose-400 rounded-full px-2 py-0.5 text-[10px] font-black text-rose-900 shadow-xs mb-1 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-red-500 fill-red-500" />
                  <span>{oppActivePet.name} ({oppActivePet.currentHp} HP)</span>
                </div>

                <div className="transform scale-90 sm:scale-110 -scale-x-100">
                  <DragonCityPet
                    petId={oppActivePet.petId}
                    emoji="🐾"
                    name={oppActivePet.name}
                    nameTagalog={oppActivePet.name}
                    element={oppActivePet.element}
                    stage={oppActivePet.stage}
                    size="lg"
                    interactive={false}
                    animationState={oppAnim}
                    showAura={true}
                    showShadow={true}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action Attack Controls Bar */}
          <div className="bg-white rounded-2xl border-2 border-orange-300 p-2 sm:p-3 shadow-md flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 flex-wrap flex-1">
              <button
                onClick={() => handleAttackClick('basic')}
                disabled={!isMyTurn}
                className="flex-1 sm:flex-none px-3.5 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-xs sm:text-sm rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
              >
                <span>⚔️</span>
                <span>Pangunahing Atake (25 DMG)</span>
              </button>

              <button
                onClick={() => handleAttackClick('special')}
                disabled={!isMyTurn}
                className="flex-1 sm:flex-none px-3.5 py-2 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-black text-xs sm:text-sm rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
              >
                <span>🔥</span>
                <span>Espesyal na Atake (40 DMG)</span>
              </button>

              <button
                onClick={() => handleAttackClick('ultimate')}
                disabled={!isMyTurn}
                className="flex-1 sm:flex-none px-3.5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-xs sm:text-sm rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
              >
                <span>⚡</span>
                <span>Ultimong Lakas (55 DMG)</span>
              </button>
            </div>

            {/* Quick Reactions Bar */}
            <div className="flex items-center gap-1 shrink-0">
              {['🔥 Laban!', '⚡ Galing!', '😂 Haha!', '🎉 GG!'].map((rx, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendChat(rx)}
                  className="px-2 py-1 rounded-lg bg-orange-100 hover:bg-orange-200 text-orange-950 text-[10px] sm:text-xs font-black transition-all cursor-pointer"
                >
                  {rx}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* POWER-UP MINI QUIZ MODAL (CRITICAL HIT AT THE SPEED OF SOUND) */}
      {/* ========================================================= */}
      {showPowerUpQuiz && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-white rounded-3xl border-3 border-amber-400 p-4 sm:p-6 max-w-md w-full shadow-2xl space-y-3">
            <div className="text-center space-y-1">
              <span className="text-3xl">⭐</span>
              <h3 className="text-lg font-black text-[#4B2C20]">
                Sagutin para sa 150% Kritikal na Atake!
              </h3>
              <p className="text-xs text-[#8B4513] font-bold">
                Mabilisang Sipnayan upang palakasin ang atake ng iyong alaga!
              </p>
            </div>

            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 text-center">
              <span className="text-2xl sm:text-3xl font-black text-[#4B2C20] font-mono">
                {quizQuestion.q}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {quizQuestion.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswerQuiz(idx)}
                  className="py-3 px-2 rounded-xl bg-orange-100 hover:bg-orange-200 border-2 border-orange-300 font-black text-lg text-orange-950 transition-all active:scale-95 cursor-pointer"
                >
                  {opt}
                </button>
              ))}
            </div>

            <button
              onClick={handleSkipQuizAndAttack}
              className="w-full py-1 text-center text-xs font-bold text-orange-700 hover:underline cursor-pointer"
            >
              I-skip at itira nang normal
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* STAGE 4: MATCH ENDED MODAL (VICTORY OR DEFEAT)            */}
      {/* ========================================================= */}
      {isMatchFinished && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl border-4 border-orange-400 p-6 max-w-md w-full text-center space-y-4 shadow-2xl">
            <div className="text-5xl animate-bounce">
              {isWinner ? '🏆' : '💀'}
            </div>

            <div className="space-y-1">
              <h3 className="text-2xl sm:text-3xl font-black text-[#4B2C20]">
                {isWinner ? '🎉 IKAW ANG PANALO!' : 'Mabuting Laban!'}
              </h3>
              <p className="text-xs sm:text-sm text-[#8B4513] font-bold">
                {isWinner
                  ? 'Nalupig mo ang lahat ng 3 alaga ng kalaban! Napakagaling!'
                  : 'Nalupig ang lahat ng iyong alaga. Maaari kang mag-rematch!'}
              </p>
            </div>

            {isWinner && (
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-3 flex items-center justify-around">
                <div className="flex items-center gap-1.5">
                  <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <span className="font-black text-sm text-[#4B2C20]">+50 Bituin!</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Zap className="w-5 h-5 text-purple-600 fill-purple-600" />
                  <span className="font-black text-sm text-[#4B2C20]">+80 Alaga EXP!</span>
                </div>
              </div>
            )}

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={handleRematch}
                className="px-6 py-2.5 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 text-white font-black text-sm rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Mag-Rematch!</span>
              </button>

              <button
                onClick={handleLeaveRoom}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-sm rounded-xl border border-slate-300 transition-all cursor-pointer"
              >
                Lumabas sa Arena
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
