import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ARAL_GRADE_LEVELS } from '../data/aralReadingData';
import { ReadingItem, ReadingLanguage } from '../types';
import { TagalogSpeechRecognizer, speakTagalog, speakEnglish } from '../services/speechService';
import { evaluateReadingWithAI } from '../services/aiService';
import { playStarSound, playSuccessFanfare, playTryAgainSound } from '../services/soundEffects';
import { fetchLiveReadingItem } from '../services/groqReadingService';
import { AudioChoicesQuiz } from './AudioChoicesQuiz';
import confetti from 'canvas-confetti';
import {
  Mic,
  MicOff,
  Sparkles,
  RefreshCw,
  Award,
  ArrowRight,
  ArrowLeft,
  Volume2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface ReadingSlideProps {
  voiceEnabled: boolean;
  onAwardStars: (count: number) => void;
  onLogHistory: (type: 'reading' | 'writing' | 'math', target: string, score: number, feedback: string) => void;
}

export const ReadingSlide: React.FC<ReadingSlideProps> = ({
  voiceEnabled,
  onAwardStars,
  onLogHistory,
}) => {
  // Curriculum Selectors: Grade 4, 5, 6 ONLY
  const [selectedGrade, setSelectedGrade] = useState<4 | 5 | 6>(4);
  const [language, setLanguage] = useState<ReadingLanguage>('filipino');
  const [readingMode, setReadingMode] = useState<'one_word' | 'sentence'>('one_word');

  // Active Item State
  const [currentItem, setCurrentItem] = useState<ReadingItem | null>(null);
  const [isLoadingGroq, setIsLoadingGroq] = useState(false);

  // Audio 4-Choices Quiz State
  const [quizSelectedText, setQuizSelectedText] = useState<string | null>(null);
  const [quizFeedback, setQuizFeedback] = useState<'none' | 'correct' | 'wrong'>('none');

  // Speech Recognition (STT) Aloud Reading State
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [sttError, setSttError] = useState<string | null>(null);
  const [evalResult, setEvalResult] = useState<{ isCorrect: boolean; feedback: string } | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);

  const recognizerRef = useRef<TagalogSpeechRecognizer | null>(null);
  const autoAdvanceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize Speech Recognizer and cleanup timers on unmount
  useEffect(() => {
    recognizerRef.current = new TagalogSpeechRecognizer(language === 'english' ? 'en-US' : 'tl-PH');
    return () => {
      recognizerRef.current?.stop();
      if (autoAdvanceTimerRef.current) {
        clearTimeout(autoAdvanceTimerRef.current);
        autoAdvanceTimerRef.current = null;
      }
    };
  }, []);

  // Update STT language when language changes
  useEffect(() => {
    if (recognizerRef.current) {
      recognizerRef.current.setLanguage(language === 'english' ? 'en-US' : 'tl-PH');
    }
  }, [language]);

  // Load a fresh reading item (from Groq AI or curated pool)
  const loadItem = useCallback(
    async (grade = selectedGrade, lang = language, mode = readingMode) => {
      if (autoAdvanceTimerRef.current) {
        clearTimeout(autoAdvanceTimerRef.current);
        autoAdvanceTimerRef.current = null;
      }
      setIsLoadingGroq(true);
      setTranscript('');
      setEvalResult(null);
      setSttError(null);
      setQuizSelectedText(null);
      setQuizFeedback('none');

      try {
        const item = await fetchLiveReadingItem({
          gradeLevel: grade,
          language: lang,
          mode,
        });
        setCurrentItem(item);
      } finally {
        setIsLoadingGroq(false);
      }
    },
    [selectedGrade, language, readingMode]
  );

  // Reload when grade, language, or mode changes
  useEffect(() => {
    loadItem(selectedGrade, language, readingMode);
  }, [selectedGrade, language, readingMode, loadItem]);

  // Handle "Pindutin para basahin nang malakas"
  const handleStartReadAloud = () => {
    if (!currentItem) return;
    setSttError(null);
    setTranscript('');
    setEvalResult(null);

    if (!recognizerRef.current) {
      recognizerRef.current = new TagalogSpeechRecognizer(language === 'english' ? 'en-US' : 'tl-PH');
    }

    setIsListening(true);
    recognizerRef.current.start(
      (finalText) => {
        setIsListening(false);
        setTranscript(finalText);
        evaluateAloudReading(finalText);
      },
      (interimText) => {
        setTranscript(interimText);
      },
      (error) => {
        setIsListening(false);
        setSttError(error);
      }
    );
  };

  const handleStopReadAloud = () => {
    recognizerRef.current?.stop();
    setIsListening(false);
  };

  const evaluateAloudReading = async (spokenText: string) => {
    if (!currentItem) return;
    setIsEvaluating(true);

    try {
      const result = await evaluateReadingWithAI(
        currentItem.text,
        spokenText,
        currentItem.category,
        selectedGrade,
        language
      );

      setEvalResult({
        isCorrect: result.isCorrect,
        feedback: result.feedbackTagalog,
      });

      if (result.isCorrect) {
        playSuccessFanfare();
        confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
        onAwardStars(10);
        onLogHistory('reading', currentItem.text, 100, result.feedbackTagalog);

        if (voiceEnabled) {
          if (language === 'english') {
            speakEnglish(`Outstanding reading! You pronounced "${currentItem.text}" correctly.`);
          } else {
            speakTagalog(`Napakagaling! Tumpak ang iyong pagbasa sa ${currentItem.text}!`);
          }
        }

        // Automatically advance to the next item after correct reading
        if (autoAdvanceTimerRef.current) {
          clearTimeout(autoAdvanceTimerRef.current);
        }
        autoAdvanceTimerRef.current = setTimeout(() => {
          loadItem();
        }, 2200);
      } else {
        playTryAgainSound();
        onLogHistory('reading', currentItem.text, 50, result.feedbackTagalog);

        if (voiceEnabled) {
          if (language === 'english') {
            speakEnglish(`Good try! Let's listen to the pronunciation of "${currentItem.text}".`);
          } else {
            speakTagalog(`Muntik na! Pakinggan natin ang wastong bigkas ng ${currentItem.text}.`);
          }
        }

        // Automatically advance to the next item after reading attempt
        if (autoAdvanceTimerRef.current) {
          clearTimeout(autoAdvanceTimerRef.current);
        }
        autoAdvanceTimerRef.current = setTimeout(() => {
          loadItem();
        }, 2400);
      }
    } finally {
      setIsEvaluating(false);
    }
  };

  // Handle 4 Audio Choices Option Selection
  const handleSelectAudioOption = (selectedChoiceText: string, isCorrect: boolean) => {
    if (!currentItem || quizFeedback !== 'none') return;
    setQuizSelectedText(selectedChoiceText);

    if (isCorrect) {
      setQuizFeedback('correct');
      playStarSound();
      confetti({ particleCount: 45, spread: 60, origin: { y: 0.7 } });
      onAwardStars(10);
      onLogHistory('reading', `Audio Quiz: ${currentItem.text}`, 100, 'Tumpak ang napiling tunog!');
      if (voiceEnabled) {
        if (language === 'english') {
          speakEnglish('Correct sound! You identified the right pronunciation.');
        } else {
          speakTagalog('Tumpak! Nahanap mo ang wastong bigkas ng salita!');
        }
      }
    } else {
      setQuizFeedback('wrong');
      playTryAgainSound();
      onLogHistory('reading', `Audio Quiz: ${currentItem.text}`, 50, 'Maling tunog ang napili.');
      if (voiceEnabled) {
        if (language === 'english') {
          speakEnglish('That is a different pronunciation. Try listening again!');
        } else {
          speakTagalog('Ibang salita ang tunog na iyon. Subukang pakinggan muli!');
        }
      }
    }

    // After determining correct or wrong, automatically proceed to next reading item!
    if (autoAdvanceTimerRef.current) {
      clearTimeout(autoAdvanceTimerRef.current);
    }
    autoAdvanceTimerRef.current = setTimeout(() => {
      loadItem();
    }, 2000);
  };

  return (
    <div
      id="reading-slide-container"
      className="flex-1 flex flex-col justify-between p-1.5 sm:p-3 landscape:p-1 max-w-4xl mx-auto w-full overflow-hidden min-h-0 gap-1 sm:gap-2"
    >
      {/* ========================================================= */}
      {/* 1. TOP COMPACT TOOLBAR (Grade 4-6, Language, Mode, Groq) */}
      {/* ========================================================= */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-1.5 sm:p-2 landscape:p-1 border-2 border-[#FF8400] shadow-xs flex flex-wrap landscape:flex-nowrap items-center justify-between gap-1 shrink-0">
        {/* Left: Grade Level Selector (Grades 4, 5, 6 strictly) */}
        <div className="flex items-center gap-0.5 sm:gap-1 bg-amber-50 p-0.5 sm:p-1 rounded-xl border border-amber-200">
          <span className="text-[10px] font-black uppercase text-[#8B4513] px-1 hidden sm:inline">
            Baitang:
          </span>
          {([4, 5, 6] as const).map((g) => {
            const isSelected = selectedGrade === g;
            return (
              <button
                key={g}
                onClick={() => setSelectedGrade(g)}
                className={`w-6 h-6 sm:w-8 sm:h-7 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center justify-center ${
                  isSelected
                    ? 'bg-[#FF8400] text-white shadow-xs scale-105'
                    : 'text-[#4B2C20] hover:bg-amber-100'
                }`}
                title={`Baitang ${g}`}
              >
                G{g}
              </button>
            );
          })}
        </div>

        {/* Center: Language Toggle (Filipino vs English) */}
        <div className="flex items-center gap-0.5 sm:gap-1 bg-amber-50 p-0.5 sm:p-1 rounded-xl border border-amber-200">
          <button
            onClick={() => setLanguage('filipino')}
            className={`flex items-center gap-1 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
              language === 'filipino'
                ? 'bg-[#FF8400] text-white shadow-xs'
                : 'text-[#4B2C20] hover:bg-amber-100'
            }`}
          >
            <span>🇵🇭</span>
            <span>Filipino</span>
          </button>
          <button
            onClick={() => setLanguage('english')}
            className={`flex items-center gap-1 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
              language === 'english'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-[#4B2C20] hover:bg-blue-50'
            }`}
          >
            <span>🇬🇧</span>
            <span>English</span>
          </button>
        </div>

        {/* Center-Right: Mode Selector (1 Word Reading vs Sentence Reading) */}
        <div className="flex items-center gap-0.5 sm:gap-1 bg-amber-50 p-0.5 sm:p-1 rounded-xl border border-amber-200">
          <button
            onClick={() => setReadingMode('one_word')}
            className={`px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1 ${
              readingMode === 'one_word'
                ? 'bg-[#4B2C20] text-amber-300 shadow-xs'
                : 'text-[#4B2C20] hover:bg-amber-100'
            }`}
          >
            <span>🔤</span>
            <span>1 Word</span>
          </button>
          <button
            onClick={() => setReadingMode('sentence')}
            className={`px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1 ${
              readingMode === 'sentence'
                ? 'bg-[#4B2C20] text-amber-300 shadow-xs'
                : 'text-[#4B2C20] hover:bg-amber-100'
            }`}
          >
            <span>📖</span>
            <span>Sentence</span>
          </button>
        </div>

        {/* Right: Groq AI Live Next Button */}
        <button
          onClick={() => loadItem()}
          disabled={isLoadingGroq}
          className="px-2.5 sm:px-3 py-0.5 sm:py-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer flex items-center gap-1 shrink-0 ml-auto disabled:opacity-50"
          title="Bumuo ng bagong salita o pangungusap gamit ang Groq AI"
        >
          <Sparkles className={`w-3.5 h-3.5 text-slate-950 ${isLoadingGroq ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">⚡ Groq:</span>
          <span>{isLoadingGroq ? 'Bumabuo...' : 'Ibang Tanong'}</span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* 2. MAIN READING DISPLAY CARD (Compact One-Page Design)    */}
      {/* ========================================================= */}
      {currentItem && (
        <div className="bg-white rounded-xl sm:rounded-2xl border-2 sm:border-3 border-[#FF8400] p-2 sm:p-3 landscape:p-1.5 shadow-md flex flex-col justify-between gap-1 sm:gap-2 flex-1 min-h-0 overflow-hidden">
          {/* Target Card Header Badge */}
          <div className="flex items-center justify-between border-b border-amber-100 pb-0.5 sm:pb-1">
            <div className="flex items-center gap-1.5">
              <span
                className={`text-[9px] sm:text-[10px] font-black uppercase px-2 py-0.5 rounded-full text-white ${
                  language === 'english' ? 'bg-blue-600' : 'bg-[#FF8400]'
                }`}
              >
                {readingMode === 'one_word' ? '1 Word Reading' : 'Sentence Reading'}
              </span>
              <span className="text-[9px] sm:text-[10px] font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                Baitang {selectedGrade}
              </span>
            </div>
            <span className="text-[9px] sm:text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 hidden sm:inline">
              ⚡ Walang pag-uulit (Groq Live)
            </span>
          </div>

          {/* Big Reading Target Text Display Box */}
          <div className="bg-gradient-to-b from-[#FFFDF5] to-[#FFFBEB] py-1.5 sm:py-2.5 landscape:py-1 px-2.5 rounded-xl border border-amber-200 text-center flex flex-col items-center justify-center space-y-0.5 shadow-inner">
            <div
              className={`font-black text-[#4B2C20] select-none px-2 leading-tight ${
                readingMode === 'one_word'
                  ? 'text-2xl sm:text-4xl landscape:text-2xl tracking-wider font-mono'
                  : 'text-xs sm:text-base landscape:text-xs leading-snug font-sans max-w-2xl'
              }`}
            >
              {currentItem.text}
            </div>

            {/* Phonetic guide / Baybay */}
            {currentItem.phoneticGuide && (
              <span className="text-[10px] sm:text-[11px] font-extrabold text-[#FF8400] bg-white px-2 py-0.2 rounded-full border border-amber-200 shadow-2xs">
                Gabay sa Bigkas: {currentItem.phoneticGuide}
              </span>
            )}

            {/* Meaning or Sample Sentence if 1 Word */}
            {currentItem.sampleSentence ? (
              <p className="text-[10px] sm:text-[11px] text-[#4B2C20] italic max-w-xl truncate">
                "{currentItem.sampleSentence}"
              </p>
            ) : currentItem.tagalogGuide ? (
              <p className="text-[10px] sm:text-[11px] text-[#8B4513] max-w-xl truncate">
                💡 {currentItem.tagalogGuide}
              </p>
            ) : null}
          </div>

          {/* ========================================================= */}
          {/* 3. "PINDUTIN PARA BASAHIN NANG MALAKAS" (Aloud Reading)  */}
          {/* ========================================================= */}
          <div className="space-y-1">
            <button
              onClick={isListening ? handleStopReadAloud : handleStartReadAloud}
              disabled={isEvaluating}
              className={`w-full py-1.5 sm:py-2 landscape:py-1 px-3 rounded-xl font-black text-xs sm:text-sm landscape:text-xs flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer shadow-xs touch-manipulation ${
                isListening
                  ? 'bg-rose-500 border-rose-600 text-white animate-pulse shadow-rose-400/50'
                  : 'bg-gradient-to-r from-amber-500 via-orange-500 to-[#FF8400] border-amber-600 text-white hover:brightness-105 active:scale-98'
              }`}
            >
              {isListening ? (
                <>
                  <MicOff className="w-3.5 h-3.5 animate-spin text-white" />
                  <span>Nakikinig... Sabihin: "{currentItem.text.slice(0, 25)}"!</span>
                </>
              ) : (
                <>
                  <Mic className="w-3.5 h-3.5 text-white" />
                  <span>🎙️ Pindutin para basahin nang malakas</span>
                </>
              )}
            </button>

            {/* Transcript & Evaluation Feedback */}
            {transcript && (
              <div className="bg-slate-100 border border-slate-300 rounded-xl px-2.5 py-1 text-xs text-slate-700 font-bold flex items-center justify-between shadow-2xs">
                <span>🎙️ Narinig:</span>
                <span className="font-black text-blue-700 truncate max-w-[80%]">"{transcript}"</span>
              </div>
            )}

            {evalResult && (
              <div
                className={`p-1.5 rounded-xl border text-center text-xs font-black flex items-center justify-center gap-1.5 ${
                  evalResult.isCorrect
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                    : 'bg-amber-50 border-amber-300 text-amber-900'
                }`}
              >
                {evalResult.isCorrect ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Napakagaling! Wastong pagbasa! (+10 ⭐ Bituin)</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    <span>{evalResult.feedback}</span>
                  </>
                )}
              </div>
            )}

            {sttError && (
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-1 text-center text-[10px] font-bold text-rose-700">
                ⚠️ {sttError}
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* 4. THE 4 AUDIO CHOICES (NO WORDS DISPLAYED)                */}
          {/* ========================================================= */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-2 space-y-2">
            <AudioChoicesQuiz
              targetText={currentItem.text}
              distractors={currentItem.distractors || []}
              language={language}
              onSelectOption={handleSelectAudioOption}
              disabled={isEvaluating}
              theme="basa"
              selectedText={quizSelectedText}
              feedbackState={quizFeedback}
              confirmActionText="Piliin ang Tunog na Ito"
            />

            {(quizFeedback !== 'none' || evalResult !== null) && (
              <div className="flex items-center justify-between p-2 rounded-xl bg-gradient-to-r from-amber-100 to-orange-100 border border-amber-300 shadow-sm animate-fade-in">
                <span className="text-xs font-black text-amber-950 flex items-center gap-1.5">
                  <span>{quizFeedback === 'correct' || evalResult?.isCorrect ? '🎉 Tumpak! Lilipat sa susunod...' : '⏱️ Lilipat sa susunod...'}</span>
                </span>
                <button
                  type="button"
                  onClick={() => loadItem()}
                  className="px-3.5 py-1.5 bg-[#FF8400] hover:bg-[#e07500] text-white font-black text-xs rounded-xl shadow-xs cursor-pointer flex items-center gap-1 active:scale-95 transition-all"
                >
                  <span>Susunod ➔</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
