import React, { useState, useEffect, useMemo } from 'react';
import { Volume2, VolumeX, CheckCircle2, XCircle, Sparkles } from 'lucide-react';
import { speakTagalog, speakEnglish, stopSpeech } from '../services/speechService';

export interface AudioChoiceItem {
  id: string;
  text: string;
  isCorrect: boolean;
  label: string; // e.g. "Tunog A", "Tunog B"
}

interface AudioChoicesQuizProps {
  targetText: string;
  distractors: string[];
  language?: 'filipino' | 'english';
  onSelectOption: (selectedText: string, isCorrect: boolean) => void;
  disabled?: boolean;
  theme?: 'combat' | 'blox' | 'basa';
  promptTitle?: string;
  selectedText?: string | null;
  feedbackState?: 'none' | 'correct' | 'wrong';
  confirmActionText?: string;
}

export const AudioChoicesQuiz: React.FC<AudioChoicesQuizProps> = ({
  targetText,
  distractors,
  language = 'filipino',
  onSelectOption,
  disabled = false,
  theme = 'basa',
  promptTitle,
  selectedText = null,
  feedbackState = 'none',
  confirmActionText = 'Piliin ang Tunog na Ito',
}) => {
  const [playingIdx, setPlayingIdx] = useState<number | null>(null);
  const [activeChoice, setActiveChoice] = useState<string | null>(selectedText);

  // Sync selectedText prop
  useEffect(() => {
    setActiveChoice(selectedText);
  }, [selectedText]);

  // Stop speech when component unmounts or target changes
  useEffect(() => {
    return () => {
      stopSpeech();
    };
  }, [targetText]);

  // Construct 4 randomized choices (1 correct + 3 distractors) with stable random order per question
  const choices: AudioChoiceItem[] = useMemo(() => {
    const letters = ['A', 'B', 'C', 'D'];
    const labelPrefix = language === 'english' ? 'Sound' : 'Tunog';

    // Ensure we have at least 3 distractors
    const safeDistractors = [...distractors].filter(
      (d) => d && d.trim().toLowerCase() !== targetText.trim().toLowerCase()
    );
    while (safeDistractors.length < 3) {
      if (language === 'english') {
        safeDistractors.push(
          safeDistractors.length === 0 ? 'COMMUNITY' : safeDistractors.length === 1 ? 'DISCOVERY' : 'PERSEVERANCE'
        );
      } else {
        safeDistractors.push(
          safeDistractors.length === 0 ? 'KATATAGAN' : safeDistractors.length === 1 ? 'KASAGANAAN' : 'PAGKILALA'
        );
      }
    }

    const items: { text: string; isCorrect: boolean }[] = [
      { text: targetText.trim(), isCorrect: true },
      ...safeDistractors.slice(0, 3).map((d) => ({ text: d.trim(), isCorrect: false })),
    ];

    // Seeded/deterministic shuffle using targetText string
    let seed = 0;
    for (let i = 0; i < targetText.length; i++) {
      seed = (seed << 5) - seed + targetText.charCodeAt(i);
      seed |= 0;
    }
    const shuffled = [...items].sort((a, b) => {
      const hA = Math.sin(seed + a.text.length * 17) * 10000;
      const hB = Math.sin(seed + b.text.length * 19) * 10000;
      return (hA - Math.floor(hA)) - (hB - Math.floor(hB));
    });

    return shuffled.map((item, idx) => ({
      id: `choice-${idx}`,
      text: item.text,
      isCorrect: item.isCorrect,
      label: `${labelPrefix} ${letters[idx]}`,
    }));
  }, [targetText, distractors, language]);

  const handlePlayAudio = (text: string, idx: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    stopSpeech();
    setPlayingIdx(idx);

    const onEnd = () => {
      setPlayingIdx((curr) => (curr === idx ? null : curr));
    };

    if (language === 'english') {
      speakEnglish(text, onEnd, onEnd);
    } else {
      speakTagalog(text, onEnd, onEnd);
    }
  };

  const handleCardClick = (choice: AudioChoiceItem, idx: number) => {
    if (disabled || feedbackState !== 'none') return;
    setActiveChoice(choice.text);
    handlePlayAudio(choice.text, idx);
    onSelectOption(choice.text, choice.isCorrect);
  };

  const letterBadges = ['A', 'B', 'C', 'D'];

  // Theme-specific styling classes
  const getCardClasses = (choice: AudioChoiceItem, idx: number) => {
    const isPlaying = playingIdx === idx;
    const isSelected = activeChoice === choice.text;
    const isAnswered = feedbackState !== 'none';
    const isCorrect = choice.isCorrect;

    if (isAnswered) {
      if (isCorrect) {
        return 'bg-emerald-600 border-2 border-emerald-300 text-white shadow-md ring-2 ring-emerald-400 scale-[1.01]';
      }
      if (isSelected && !isCorrect) {
        return 'bg-rose-600 border-2 border-rose-300 text-white shadow-md ring-2 ring-rose-400';
      }
      return 'bg-slate-900/60 border border-slate-700/60 text-slate-400 opacity-40';
    }

    if (theme === 'blox') {
      const bloxColors = [
        'bg-red-950/90 hover:bg-red-900 border-red-500/80 shadow-[0_4px_0_0_#991b1b]',
        'bg-blue-950/90 hover:bg-blue-900 border-blue-500/80 shadow-[0_4px_0_0_#1e3a8a]',
        'bg-amber-950/90 hover:bg-amber-900 border-amber-500/80 shadow-[0_4px_0_0_#b45309]',
        'bg-emerald-950/90 hover:bg-emerald-900 border-emerald-500/80 shadow-[0_4px_0_0_#065f46]',
      ];
      const base = bloxColors[idx % bloxColors.length];
      if (isSelected) {
        return `${base} ring-2 ring-yellow-400 scale-[1.02]`;
      }
      return base;
    }

    if (theme === 'combat') {
      if (isSelected) {
        return 'bg-amber-100 border-2 border-amber-500 text-amber-950 shadow-md ring-2 ring-amber-400 scale-[1.02]';
      }
      return 'bg-white hover:bg-amber-50/90 border-2 border-amber-300 text-amber-950 shadow-xs';
    }

    // Default 'basa' theme
    if (isSelected) {
      return 'bg-amber-100 border-3 border-[#FF8400] text-amber-950 shadow-md ring-2 ring-[#FF8400]/50 scale-[1.02]';
    }
    return 'bg-white hover:bg-amber-50/80 border-2 border-amber-200 text-amber-950 shadow-xs hover:border-[#FF8400]/60';
  };

  return (
    <div className="w-full space-y-1.5 select-none">
      {/* Quiz Directive Header */}
      <div className="flex items-center justify-between gap-1 px-1">
        <span className="text-[11px] sm:text-xs font-black uppercase tracking-wider flex items-center gap-1.5 text-amber-900">
          <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center text-[10px] font-black shrink-0">
            🔊
          </span>
          <span>
            {promptTitle ||
              (language === 'english'
                ? 'Listen to the 4 pronunciations & choose the correct one:'
                : 'Pakinggan ang 4 na bigkas at piliin ang tamang tunog:')}
          </span>
        </span>
        <span className="text-[10px] font-bold text-amber-800 bg-amber-100/90 px-2 py-0.5 rounded-full border border-amber-300 shrink-0">
          4 Tunog (A, B, C, D) Walang Teksto
        </span>
      </div>

      {/* 4 AUDIO CHOICES (NO WORDS DISPLAYED - ALL 4 VISIBLE) */}
      <div className="grid grid-cols-2 landscape:grid-cols-4 sm:grid-cols-4 gap-1 sm:gap-2">
        {choices.map((choice, idx) => {
          const isPlaying = playingIdx === idx;
          const isSelected = activeChoice === choice.text;
          const isAnswered = feedbackState !== 'none';
          const isCorrect = choice.isCorrect;

          return (
            <div
              key={choice.id}
              onClick={() => handleCardClick(choice, idx)}
              className={`p-1.5 sm:p-2 landscape:p-1 rounded-xl transition-all cursor-pointer flex flex-col justify-between gap-0.5 sm:gap-1 touch-manipulation relative overflow-hidden min-h-[50px] landscape:min-h-[44px] sm:min-h-[64px] ${getCardClasses(
                choice,
                idx
              )}`}
            >
              {/* Top Row: Letter Stud + Sound Label + Active Equalizer Wave */}
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-1.5">
                  <span
                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-black text-xs shadow-xs shrink-0 ${
                      theme === 'blox'
                        ? 'bg-black/40 text-yellow-300 border border-white/20'
                        : isSelected
                        ? 'bg-[#FF8400] text-white shadow-xs'
                        : 'bg-amber-100 text-amber-900 border border-amber-300'
                    }`}
                  >
                    {letterBadges[idx]}
                  </span>
                  <span className="text-xs font-black tracking-wide truncate">
                    {choice.label}
                  </span>
                </div>

                {/* Animated Audio Equalizer Bars when playing */}
                {isPlaying ? (
                  <div className="flex items-end gap-0.5 h-3.5 px-1 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[8px] shrink-0">
                    <span className="w-1 bg-slate-950 rounded-full animate-bounce h-2.5" />
                    <span className="w-1 bg-slate-950 rounded-full animate-bounce h-1.5 delay-75" />
                    <span className="w-1 bg-slate-950 rounded-full animate-bounce h-3 delay-150" />
                  </div>
                ) : (
                  <Volume2 className="w-3.5 h-3.5 text-amber-600/70 shrink-0" />
                )}
              </div>

              {/* Action Buttons Row: Compact Pakinggan & Piliin */}
              <div className="flex items-center gap-1 w-full mt-0.5">
                <button
                  type="button"
                  onClick={(e) => handlePlayAudio(choice.text, idx, e)}
                  disabled={disabled}
                  className={`flex-1 py-1 px-1.5 rounded-lg text-[10px] sm:text-[11px] font-black flex items-center justify-center gap-1 border transition-all cursor-pointer active:scale-95 ${
                    isPlaying
                      ? 'bg-amber-400 text-slate-950 border-yellow-200 ring-1 ring-amber-300 animate-pulse font-black'
                      : theme === 'blox'
                      ? 'bg-slate-900/90 hover:bg-slate-800 text-white border-slate-700'
                      : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300'
                  }`}
                  title="Pakinggan ang bigkas nang buo"
                >
                  <Volume2 className={`w-3 h-3 ${isPlaying ? 'animate-ping' : ''}`} />
                  <span className="truncate">
                    {isPlaying
                      ? language === 'english'
                        ? 'Playing...'
                        : 'Boses...'
                      : language === 'english'
                      ? 'Listen'
                      : 'Pakinggan'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveChoice(choice.text);
                    handlePlayAudio(choice.text, idx);
                    onSelectOption(choice.text, choice.isCorrect);
                  }}
                  disabled={disabled || isAnswered}
                  className={`flex-1 py-1 px-1.5 rounded-lg text-[10px] sm:text-[11px] font-black flex items-center justify-center gap-1 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#FF8400] text-white shadow-xs font-black'
                      : theme === 'blox'
                      ? 'bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black'
                      : 'bg-amber-200 hover:bg-amber-300 text-amber-950'
                  }`}
                  title="Piliin ang tunog na ito"
                >
                  <span>🎯</span>
                  <span className="truncate">Piliin</span>
                </button>
              </div>

              {/* Correct / Incorrect Feedback Badge */}
              {isAnswered && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center">
                  {isCorrect ? (
                    <div className="flex items-center gap-1 bg-emerald-500 text-white px-2 py-1 rounded-lg font-black text-[11px] shadow-lg animate-bounce">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Tama!</span>
                    </div>
                  ) : isSelected ? (
                    <div className="flex items-center gap-1 bg-rose-600 text-white px-2 py-1 rounded-lg font-black text-[11px] shadow-lg">
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Mali</span>
                    </div>
                  ) : null}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
