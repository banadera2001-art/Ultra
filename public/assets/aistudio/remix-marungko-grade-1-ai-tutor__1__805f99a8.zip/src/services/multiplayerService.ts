/**
 * Real-time Multiplayer WebSocket Service
 * Handles both:
 * 1. Alaga PvP Combat Arena (Room codes, 1-on-1 pet battle with 3 sets of Alaga per player)
 * 2. Blox Fruit 3D MMORPG World (Player syncing, PvP duels, damage calculation, real-time censored chat)
 */

import { censorProfanity } from '../utils/profanityFilter';

export interface AlagaPetCombatant {
  petId: string;
  name: string;
  element: string;
  stage: string;
  level: number;
  maxHp: number;
  currentHp: number;
  isFainted: boolean;
  basicSkill: string;
  specialSkill: string;
}

export interface AlagaRoomPlayer {
  id: string;
  name: string;
  avatar: string;
  team: AlagaPetCombatant[];
  activePetIndex: number;
  isReady: boolean;
  score: number;
}

export interface AlagaRoomState {
  code: string;
  players: Record<string, AlagaRoomPlayer>;
  battleState: 'waiting' | 'ready' | 'battling' | 'finished';
  currentTurnPlayerId?: string;
  logs: string[];
  winnerPlayerId?: string;
}

export interface BloxOnlinePlayer {
  id: string;
  name: string;
  gender: 'boy' | 'girl';
  level: number;
  fruitId: string;
  swordId: string;
  accessoryId: string;
  haki: boolean;
  x: number;
  y: number;
  z: number;
  rotationY: number;
  hp: number;
  maxHp: number;
  bounty: number;
  isMoving?: boolean;
  isAttacking?: boolean;
  lastAttack?: {
    type: 'sword' | 'melee' | 'skill';
    skillId?: string;
    skillName?: string;
    time: number;
  };
}

export interface BloxChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  fruitName: string;
  text: string;
  timestamp: number;
}

type MessageHandler = (data: any) => void;

class MultiplayerService {
  private ws: WebSocket | null = null;
  private isConnecting = false;
  private reconnectTimer: any = null;
  private listeners: Map<string, Set<MessageHandler>> = new Map();
  private isOnline = false;

  constructor() {
    this.connect();
  }

  public connect() {
    if (typeof window === 'undefined') return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.isConnecting = true;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnecting = false;
        this.isOnline = true;
        this.emit('connection_status', { online: true });
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.event) {
            this.emit(payload.event, payload.data);
          }
        } catch (e) {
          console.warn('[WS Parse Error]:', e);
        }
      };

      this.ws.onclose = () => {
        this.isOnline = false;
        this.isConnecting = false;
        this.emit('connection_status', { online: false });
        this.scheduleReconnect();
      };

      this.ws.onerror = (err) => {
        console.warn('[WS Error]:', err);
        this.isOnline = false;
      };
    } catch (e) {
      console.warn('[WS Connect Exception]:', e);
      this.isConnecting = false;
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, 2500);
  }

  public on(event: string, handler: MessageHandler) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);
    return () => this.off(event, handler);
  }

  public off(event: string, handler: MessageHandler) {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.delete(handler);
    }
  }

  private emit(event: string, data: any) {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.forEach((h) => {
        try {
          h(data);
        } catch (e) {
          console.error(`[WS Handler Error on ${event}]:`, e);
        }
      });
    }
  }

  private send(event: string, data: any) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      this.connect();
      // Retry in 150ms if currently connecting
      setTimeout(() => {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ event, data }));
        }
      }, 150);
      return;
    }
    this.ws.send(JSON.stringify({ event, data }));
  }

  public getOnlineStatus(): boolean {
    return this.isOnline;
  }

  // ==========================================
  // ALAGA PVP COMBAT ARENA METHODS (ROOM CODE)
  // ==========================================

  /**
   * Join or create an Alaga PvP Arena room with a code
   */
  public joinAlagaRoom(
    code: string,
    player: {
      id: string;
      name: string;
      avatar: string;
      team: AlagaPetCombatant[];
    }
  ) {
    const cleanCode = code.trim().toUpperCase();
    this.send('alaga_join_room', {
      code: cleanCode,
      player,
    });
  }

  /**
   * Mark player as ready in the room
   */
  public readyAlagaPlayer(code: string, playerId: string) {
    this.send('alaga_player_ready', {
      code: code.trim().toUpperCase(),
      playerId,
    });
  }

  /**
   * Execute an attack action in the Alaga 1v1 Arena
   */
  public sendAlagaAttack(
    code: string,
    payload: {
      attackerPlayerId: string;
      targetPlayerId: string;
      attackType: 'basic' | 'special' | 'ultimate';
      skillName: string;
      damage: number;
      isCritical: boolean;
      textPrompt?: string;
    }
  ) {
    this.send('alaga_player_attack', {
      code: code.trim().toUpperCase(),
      ...payload,
    });
  }

  /**
   * Send a quick chat or reaction in Alaga PvP room
   */
  public sendAlagaChat(code: string, playerId: string, playerName: string, message: string) {
    const filteredText = censorProfanity(message);
    this.send('alaga_player_chat', {
      code: code.trim().toUpperCase(),
      playerId,
      playerName,
      message: filteredText,
    });
  }

  /**
   * Request a rematch in Alaga PvP room
   */
  public sendAlagaRematch(code: string) {
    this.send('alaga_rematch', {
      code: code.trim().toUpperCase(),
    });
  }

  /**
   * Leave the Alaga room
   */
  public leaveAlagaRoom(code: string, playerId: string) {
    this.send('alaga_leave_room', {
      code: code.trim().toUpperCase(),
      playerId,
    });
  }

  // ==========================================
  // BLOX FRUITS 3D MULTIPLAYER METHODS
  // ==========================================

  /**
   * Join the 3D Blox Fruit MMORPG world
   */
  public joinBloxWorld(player: BloxOnlinePlayer) {
    this.send('blox_join', player);
  }

  /**
   * Update 3D player position and rotation
   */
  public sendBloxMove(
    id: string,
    pos: { x: number; y: number; z: number },
    rotationY: number,
    isMoving: boolean
  ) {
    this.send('blox_move', {
      id,
      x: pos.x,
      y: pos.y,
      z: pos.z,
      rotationY,
      isMoving,
    });
  }

  /**
   * Trigger an attack or fruit skill visible to all online players
   */
  public sendBloxAttack(
    id: string,
    attack: {
      type: 'sword' | 'melee' | 'skill';
      skillId?: string;
      skillName?: string;
      position: { x: number; y: number; z: number };
      direction: { x: number; y: number; z: number };
    }
  ) {
    this.send('blox_attack', {
      id,
      ...attack,
    });
  }

  /**
   * Deal PvP damage to another player in the 3D world
   */
  public sendBloxPvPHit(
    attackerId: string,
    attackerName: string,
    victimId: string,
    damage: number,
    skillName: string
  ) {
    this.send('blox_pvp_hit', {
      attackerId,
      attackerName,
      victimId,
      damage,
      skillName,
    });
  }

  /**
   * Send a chat message with automatic Filipino & English profanity censorship
   */
  public sendBloxChat(senderId: string, senderName: string, fruitName: string, rawMessage: string) {
    const cleanMessage = censorProfanity(rawMessage);
    this.send('blox_chat', {
      senderId,
      senderName,
      fruitName,
      text: cleanMessage,
    });
  }

  /**
   * Send a friendly PvP Duel request to a target player
   */
  public sendBloxDuelInvite(senderId: string, senderName: string, targetId: string) {
    this.send('blox_duel_invite', {
      senderId,
      senderName,
      targetId,
    });
  }

  /**
   * Respond to a PvP Duel challenge
   */
  public respondBloxDuel(challengerId: string, targetId: string, accepted: boolean) {
    this.send('blox_duel_response', {
      challengerId,
      targetId,
      accepted,
    });
  }

  /**
   * Leave the Blox Fruit 3D world
   */
  public leaveBloxWorld(id: string) {
    this.send('blox_leave', { id });
  }
}

export const multiplayerService = new MultiplayerService();
