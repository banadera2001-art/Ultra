import { ReadingItem, ReadingLanguage } from '../types';
import { ARAL_READING_ITEMS } from '../data/aralReadingData';

/**
 * Session history of generated and viewed words and sentences to ensure
 * ZERO repetition across the entire session.
 */
const sessionSeenTexts = new Set<string>();

export function markReadingItemAsSeen(text: string): void {
  if (!text) return;
  sessionSeenTexts.add(text.trim().toLowerCase());
}

export function isReadingTextSeen(text: string): boolean {
  if (!text) return false;
  return sessionSeenTexts.has(text.trim().toLowerCase());
}

/**
 * Fetch a fresh, NON-REPEATING 1-word or sentence reading item generated live via Groq AI.
 */
export async function fetchLiveReadingItem(params: {
  gradeLevel: 4 | 5 | 6;
  language: ReadingLanguage;
  mode: 'one_word' | 'sentence';
}): Promise<ReadingItem> {
  const { gradeLevel, language, mode } = params;
  const excludeList = Array.from(sessionSeenTexts).slice(-50);

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 7500);

    const res = await fetch('/api/ai/live-reading', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        gradeLevel,
        language,
        mode,
        excludeList,
      }),
    });
    clearTimeout(timeout);

    if (res.ok) {
      const data = await res.json();
      if (data && data.success && data.item && data.item.text) {
        const item: ReadingItem = {
          id: data.item.id || `groq-${Date.now()}`,
          gradeLevel: data.item.gradeLevel || gradeLevel,
          language: data.item.language || language,
          category: mode,
          categoryLabel: mode === 'one_word' ? '1 Word Reading' : 'Sentence Reading',
          text: data.item.text,
          phoneticGuide: data.item.phoneticGuide || data.item.text,
          tagalogGuide: data.item.tagalogGuide || 'Makabuluhang aralin sa pagbasa.',
          sampleSentence: data.item.sampleSentence || '',
          distractors: Array.isArray(data.item.distractors) && data.item.distractors.length >= 3
            ? data.item.distractors
            : [
                mode === 'one_word' ? 'KATAPATAN' : 'Magtulungan tayo sa lahat ng oras.',
                mode === 'one_word' ? 'KAPAYAPAAN' : 'Ang katotohanan ang sandigan ng tiwala.',
                mode === 'one_word' ? 'KARANGALAN' : 'Ingatan natin ang ating kalikasan.',
              ],
          emoji: mode === 'one_word' ? '🔤' : '📖',
        };

        markReadingItemAsSeen(item.text);
        return item;
      }
    }
  } catch (err) {
    console.warn('[Groq Reading Service] Live fetch error, using curated pool:', err);
  }

  // Fallback to curated ARAL reading items with anti-repetition check
  const candidates = ARAL_READING_ITEMS.filter(
    (item) =>
      item.gradeLevel === gradeLevel &&
      item.language === language &&
      item.category === mode
  );

  const unseen = candidates.filter((item) => !sessionSeenTexts.has(item.text.trim().toLowerCase()));
  const pool = unseen.length > 0 ? unseen : candidates;
  const picked = pool[Math.floor(Math.random() * pool.length)] || candidates[0];

  if (picked) {
    markReadingItemAsSeen(picked.text);
    return picked;
  }

  // Absolute safety fallback
  const fallbackText = mode === 'one_word' ? 'MASIGASIG' : 'Masigasig na nag-aaral ang mga mag-aaral.';
  markReadingItemAsSeen(fallbackText);
  return {
    id: `fb-${Date.now()}`,
    gradeLevel,
    language,
    category: mode,
    categoryLabel: mode === 'one_word' ? '1 Word Reading' : 'Sentence Reading',
    text: fallbackText,
    phoneticGuide: 'MA-SI-GA-SIG',
    tagalogGuide: 'Matiyaga sa pag-aaral.',
    distractors: mode === 'one_word' ? ['DALUBHASA', 'KATATAGAN', 'KASAYSAYAN'] : [
      'Kapit-bisig na nilinis ng mga residente ang kanilang pamayanan.',
      'Ang pangangalaga sa kalikasan ay dakilang pananagutan ng bawat isa.',
      'Bukas-palad na namahagi ng tulong ang mga kabataan sa mga nasalanta.',
    ],
    emoji: '🌟',
  };
}
