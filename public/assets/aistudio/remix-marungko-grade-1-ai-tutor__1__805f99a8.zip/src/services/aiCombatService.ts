import { MathItem, MathOperation } from '../types';
import { MATH_CURRICULUM_ITEMS } from '../data/mathData';
import { READING_COMBAT_POOL, ReadingCombatWord } from '../data/combatReadingData';

export type CombatSubject = 'reading' | 'math' | 'english';
export type CombatGradeLevel = 4 | 5 | 6;

export interface CombatChallenge {
  id: string;
  mode: CombatSubject;
  gradeLevel: CombatGradeLevel;
  // Reading / English attributes
  targetWord?: string;
  syllables?: string[];
  phoneticGuide?: string;
  clue?: string;
  readingPassage?: string;
  // Math attributes
  mathQuestion?: string;
  mathEmoji?: string;
  mathHint?: string;
  // Compatibility aliases
  equation?: string;
  questionText?: string;
  visualEmoji?: string;
  // Common attributes
  options: string[];
  correctAnswer: string;
  correctIndex: number;
  explanation: string;
}

/**
 * Session tracking of asked words, passages, and math questions to strictly GUARANTEE
 * that no words, reading passages, or questions are EVER repeated during combat.
 */
const askedReadingWordSignatures = new Set<string>();
const askedReadingPassageSignatures = new Set<string>();
const askedEnglishWordSignatures = new Set<string>();
const askedEnglishPassageSignatures = new Set<string>();
const askedMathQuestionSignatures = new Set<string>();

/**
 * Pre-fetched queues of AI-generated challenges for instantaneous zero-latency battle turns.
 */
const readingQueues = new Map<CombatGradeLevel, CombatChallenge[]>();
const englishQueues = new Map<CombatGradeLevel, CombatChallenge[]>();
const mathQueues = new Map<CombatGradeLevel, CombatChallenge[]>();

for (let g = 4; g <= 6; g++) {
  readingQueues.set(g as CombatGradeLevel, []);
  englishQueues.set(g as CombatGradeLevel, []);
  mathQueues.set(g as CombatGradeLevel, []);
}

let isPrefetchingReading = false;
let isPrefetchingEnglish = false;
let isPrefetchingMath = false;

// =========================================================================
// Curated Multi-Grade Reading Vocabulary & Reading Passage Pools (Grades 1 to 6)
// =========================================================================
interface CuratedReadingItem {
  word: string;
  syllables: string[];
  phoneticGuide: string;
  clue: string;
  readingPassage: string;
  distractors: string[];
}

const GRADE_READING_POOLS: Record<CombatGradeLevel, CuratedReadingItem[]> = {
  4: [
    { word: 'KALIKASAN', syllables: ['KA', 'LI', 'KA', 'SAN'], phoneticGuide: 'KA-LI-KA-SAN', clue: 'Likas na yaman, kabundukan, at karagatan ng bansa', readingPassage: 'Pangalagaan natin ang kalikasan upang maiwasan ang pagbaha.', distractors: ['KAPALIGIRAN', 'KASAYSAYAN', 'KATUBIGAN'] },
    { word: 'KASAYSAYAN', syllables: ['KA', 'SAY', 'SA', 'YAN'], phoneticGuide: 'KA-SAY-SA-YAN', clue: 'Talaan ng mahahalagang kaganapan sa nakaraan ng bayan', readingPassage: 'Pinag-aralan ng klase ang makulay na kasaysayan ng Pilipinas.', distractors: ['KALINANGAN', 'PANITIKAN', 'KABAYANIHAN'] },
    { word: 'PAGTUTULUNGAN', syllables: ['PAG', 'TU', 'TU', 'LU', 'NGAN'], phoneticGuide: 'PAG-TU-TU-LU-NGAN', clue: 'Sama-samang pagkilos upang mabilis matapos ang gawain', readingPassage: 'Dahil sa pagtutulungan, naging maunlad ang kanilang pamayanan.', distractors: ['BAYANIHAN', 'PAKIKIPAGKAPWA', 'PAGKAKAISA'] },
    { word: 'KAYAMANAN', syllables: ['KA', 'YA', 'MA', 'NAN'], phoneticGuide: 'KA-YA-MA-NAN', clue: 'Mahahalagang yaman, karunungan, o biyayang taglay', readingPassage: 'Ang edukasyon at karunungan ay hindi mananakaw na kayamanan.', distractors: ['SALAPI', 'KABUTIHAN', 'GINTO'] },
    { word: 'PAMAYANAN', syllables: ['PA', 'MA', 'YA', 'NAN'], phoneticGuide: 'PA-MA-YA-NAN', clue: 'Pangkat ng mamamayang namumuhay sa isang teritoryo', readingPassage: 'Nagtutulungan ang mga mamamayan sa malinis na pamayanan.', distractors: ['LALAWIGAN', 'LUNGSOD', 'BARANGAY'] },
    { word: 'BAYANIHAN', syllables: ['BA', 'YA', 'NI', 'HAN'], phoneticGuide: 'BA-YA-NI-HAN', clue: 'Katutubong tradisyon ng kusang-loob na pagtulong sa kapwa', readingPassage: 'Buhay na buhay ang diwa ng bayanihan sa panahon ng sakuna.', distractors: ['PAGKAKAIBIGAN', 'PAGTUTULUNGAN', 'PAKIKISAMA'] },
    { word: 'KATUTUBO', syllables: ['KA', 'TU', 'TU', 'BO'], phoneticGuide: 'KA-TU-TU-BO', clue: 'Unang pangkat na naninirahan sa isang rehiyon o lupain', readingPassage: 'Igalang at pahalagahan natin ang sining ng mga katutubo.', distractors: ['MAMAMAYAN', 'KABABAYAN', 'KALAHI'] },
    { word: 'SALAWIKAIN', syllables: ['SA', 'LA', 'WI', 'KA', 'IN'], phoneticGuide: 'SA-LA-WI-KA-IN', clue: 'Matatandang kasabihang may taglay na gintong aral', readingPassage: 'Puno ng malalim na karunungan ang mga lumang salawikain.', distractors: ['BUGTONG', 'KASABIHAN', 'IDYOMA'] },
    { word: 'PAGPAPASALAMAT', syllables: ['PAG', 'PA', 'PA', 'SA', 'LA', 'MAT'], phoneticGuide: 'PAG-PA-PA-SA-LA-MAT', clue: 'Pagtanaw ng utang na loob at pasasalamat sa biyayang natanggap', readingPassage: 'Taos-pusong pagpapasalamat ang ipinaabot ng mag-aaral.', distractors: ['PAGPAPAHALAGA', 'PAGKILALA', 'PAGMAMAHAL'] },
  ],
  5: [
    { word: 'PANGANGALAGA', syllables: ['PA', 'NGA', 'NGA', 'LA', 'GA'], phoneticGuide: 'PA-NGA-NGA-LA-GA', clue: 'Pag-aaruga, pag-iingat, at proteksyon sa kalikasan at kapwa', readingPassage: 'Mahalaga ang pangangalaga sa mga bakawan at yamang-dagat.', distractors: ['PAG-AARUGA', 'PAGBABANTAY', 'PAG-IINGAT'] },
    { word: 'RESPONSIBILIDAD', syllables: ['RES', 'PON', 'SI', 'BI', 'LI', 'DAD'], phoneticGuide: 'RES-PON-SI-BI-LI-DAD', clue: 'Tungkulin at pananagutang dapat gampanan nang buong puso', readingPassage: 'Responsibilidad ng bawat bata na mag-aral at maging magalang.', distractors: ['PANANAGUTAN', 'TUNGKULIN', 'OBLIGASYON'] },
    { word: 'PAGPAPAHALAGA', syllables: ['PAG', 'PA', 'PA', 'HA', 'LA', 'GA'], phoneticGuide: 'PAG-PA-PA-HA-LA-GA', clue: 'Pagbibigay halaga at paggalang sa magagandang asal', readingPassage: 'Ipakita ang pagpapahalaga sa sakripisyo ng ating mga guro.', distractors: ['PAGGALANG', 'PAGKILALA', 'PAGMAMAHAL'] },
    { word: 'KALUSUGAN', syllables: ['KA', 'LU', 'SU', 'GAN'], phoneticGuide: 'KA-LU-SU-GAN', clue: 'Kalagayan ng katawan at kaisipan na malayo sa karamdaman', readingPassage: 'Ang wastong pagkain at ehersisyo ang sandigan ng kalusugan.', distractors: ['LAKAS', 'KATATAGAN', 'KASIGLAHAN'] },
    { word: 'KINABUKASAN', syllables: ['KI', 'NA', 'BU', 'KA', 'SAN'], phoneticGuide: 'KI-NA-BU-KA-SAN', clue: 'Mga darating na panahon at kinabukasan ng susunod na salinlahi', readingPassage: 'Mag-aral nang masigasig para sa isang maaliwalas na kinabukasan.', distractors: ['KASALUKUYAN', 'PANGARAP', 'BUKAS'] },
    { word: 'KAPAYAPAAN', syllables: ['KA', 'PA', 'YA', 'PA', 'AN'], phoneticGuide: 'KA-PA-YA-PA-AN', clue: 'Katahimikan, pagkakasundo, at kawalan ng hidwaan sa lipunan', readingPassage: 'Nagsusumikap ang bawat pamayanan na mapanatili ang kapayapaan.', distractors: ['KATAHIMIKAN', 'PAGKASUNDO', 'KATATAGAN'] },
    { word: 'PAGKAKAIBIGAN', syllables: ['PAG', 'KA', 'KA', 'I', 'BI', 'GAN'], phoneticGuide: 'PAG-KA-KA-I-BI-GAN', clue: 'Banal na ugnayan ng mga taong nagtutulungan at nagmamahalan', readingPassage: 'Lalong tumibay ang kanilang pagkakaibigan sa gitna ng pagsubok.', distractors: ['SAMAHAN', 'UGNAYAN', 'PAKIKISAMA'] },
    { word: 'PAGKUKUSA', syllables: ['PAG', 'KU', 'KU', 'SA'], phoneticGuide: 'PAG-KU-KU-SA', clue: 'Kusang pagkilos nang hindi na kailangang utusan ng iba', readingPassage: 'May pagkukusa siyang naglinis ng kanilang silid-aralan.', distractors: ['KASIPAGAN', 'KATAPATAN', 'PAGKILOS'] },
    { word: 'MAKATOTOHANAN', syllables: ['MA', 'KA', 'TO', 'TO', 'HA', 'NAN'], phoneticGuide: 'MA-KA-TO-TO-HA-NAN', clue: 'Nagsasabi ng tunay na pangyayari at hindi kathang-isip', readingPassage: 'Makatotohanan ang mga impormasyong ibinahagi sa ulat.', distractors: ['MAKATUWID', 'MAKABULUHAN', 'MAKABAGO'] },
  ],
  6: [
    { word: 'KATAPATAN', syllables: ['KA', 'TA', 'PA', 'TAN'], phoneticGuide: 'KA-TA-PA-TAN', clue: 'Pagsasabi ng totoo, pagkamatapat, at pagiging marangal', readingPassage: 'Ang katapatan sa lahat ng oras ang pundasyon ng dangal ng tao.', distractors: ['KABUTIHAN', 'KATARUNGAN', 'KALINISAN'] },
    { word: 'PAGKAKAISA', syllables: ['PAG', 'KA', 'KA', 'I', 'SA'], phoneticGuide: 'PAG-KA-KA-I-SA', clue: 'Sama-samang lakas at damdamin tungo sa iisang mithiin', readingPassage: 'Nakamit ang tagumpay ng buong koponan dahil sa kanilang pagkakaisa.', distractors: ['PAGTUTULUNGAN', 'BAYANIHAN', 'KASUNDUAN'] },
    { word: 'TEKNOLOHIYA', syllables: ['TEK', 'NO', 'LO', 'HI', 'YA'], phoneticGuide: 'TEK-NO-LO-HI-YA', clue: 'Makabagong imbensyon at agham na nagpapabilis ng gawain', readingPassage: 'Gamitin ang makabagong teknolohiya sa kapaki-pakinabang na pagkatuto.', distractors: ['IMBENSYON', 'KOMPYUTER', 'AGHAM'] },
    { word: 'KARANGALAN', syllables: ['KA', 'RA', 'NGA', 'LAN'], phoneticGuide: 'KA-RA-NGA-LAN', clue: 'Mataas na reputasyon, dangal, at papuring ipinagmamalaki', readingPassage: 'Isang dakilang karangalan ang maglingkod sa sariling bayan.', distractors: ['DANGAL', 'KAPURIHAN', 'TAGUMPAY'] },
    { word: 'KALAYAAN', syllables: ['KA', 'LA', 'YA', 'AN'], phoneticGuide: 'KA-LA-YA-AN', clue: 'Karapatang mamuhay nang malaya at walang pananakop', readingPassage: 'Ipinaglaban ng ating mga magigiting na bayani ang ating kalayaan.', distractors: ['KASARINLAN', 'KAPAYAPAAN', 'KATARUNGAN'] },
    { word: 'KATARUNGAN', syllables: ['KA', 'TA', 'RU', 'NGAN'], phoneticGuide: 'KA-TA-RU-NGAN', clue: 'Pantay-pantay at makatarungang pagtrato sa batas at lipunan', readingPassage: 'Dapat manaig ang katarungan para sa kapakanan ng lahat ng tao.', distractors: ['KATAPATAN', 'PAGKAPANTAY', 'KALAYAAN'] },
    { word: 'DIGNIDAD', syllables: ['DIG', 'NI', 'DAD'], phoneticGuide: 'DIG-NI-DAD', clue: 'Likas na dangal, halaga, at karapatan ng bawat nilalang', readingPassage: 'Igalang natin ang dangal at dignidad ng bawat kapwa tao.', distractors: ['KARANGALAN', 'KATAUHAN', 'HALAGA'] },
    { word: 'PANANAGUTAN', syllables: ['PA', 'NA', 'NA', 'GU', 'TAN'], phoneticGuide: 'PA-NA-NA-GU-TAN', clue: 'Pananagutan sa bawat pasya, kilos, at pananalita', readingPassage: 'Tuparin natin ang ating pananagutan bilang mamamayang Pilipino.', distractors: ['TUNGKULIN', 'RESPONSIBILIDAD', 'AKUSASYON'] },
    { word: 'SOBERANYA', syllables: ['SO', 'BE', 'RAN', 'YA'], phoneticGuide: 'SO-BE-RAN-YA', clue: 'Pinakamataas na kapangyarihan ng isang malayang estado', readingPassage: 'Ipagtanggol natin ang soberanya at kasarinlan ng Pilipinas.', distractors: ['KASARINLAN', 'KALAYAAN', 'PAMAHALAAN'] },
    { word: 'KABAYANIHAN', syllables: ['KA', 'BA', 'YA', 'NI', 'HAN'], phoneticGuide: 'KA-BA-YA-NI-HAN', clue: 'Pambihirang gawa ng pagmamahal at pag-aalay sa bayan', readingPassage: 'Ipinamalas ng ating mga manggagawa ang tunay na kabayanihan.', distractors: ['KATAPANGAN', 'KADAKILAAN', 'PAGMAMAHAL'] },
  ],
};

// =========================================================================
// Procedural Reading Generator (Guarantees limitless non-repeating reading passages)
// =========================================================================
function generateProceduralReadingItem(grade: CombatGradeLevel): CuratedReadingItem {
  const subjectsByGrade: Record<CombatGradeLevel, { words: string[]; contexts: string[] }> = {
    4: {
      contexts: [
        'Ipinakita ng mga kabataan ang kanilang pagmamahal sa kalikasan.',
        'Matiyagang nagsasaliksik ang pangkat upang makatuklas ng bago.',
        'Ang pangangalaga sa mga anyong-tubig ay pananagutan ng lahat.',
        'Bawat rehiyon sa ating bansa ay may natatanging tradisyon.',
      ],
      words: ['TRADISYON', 'PAGKILALA', 'KATATAGAN', 'ANYONG-LUPA', 'KARAPATAN', 'MAMAMAYAN', 'KULTURA'],
    },
    5: {
      contexts: [
        'Mahalagang maunawaan ng bawat indibidwal ang kahalagahan ng pagkakaisa.',
        'Ang pananagutan sa kapaligiran ay nagbubunga ng kasaganaan.',
        'Ipinaglaban ng mga bayani ang dangal at kinabukasan ng bansa.',
      ],
      words: ['KASAGANAAN', 'KAPAKANAN', 'KATARUNGAN', 'PAKIKIBAKA', 'PAGKUKUSA', 'KAGALINGAN'],
    },
    6: {
      contexts: [
        'Ang masusing pagsusuri sa mga datos ay nagbubunga ng tamang desisyon.',
        'Ang tunay na lider ay naglilingkod nang may katapatan at kababaang-loob.',
        'Ang pagtatanggol sa soberanya ay sagradong tungkulin ng bawat mamamayan.',
      ],
      words: ['PAMUMUNO', 'KABABAANG-LOOB', 'PAGSUSURI', 'INTEGRIDAD', 'KATATAGAN', 'PANANAMPALATAYA'],
    },
  };

  const pool = subjectsByGrade[grade] || subjectsByGrade[4];
  const word = pool.words[Math.floor(Math.random() * pool.words.length)];
  const contextSentence = pool.contexts[Math.floor(Math.random() * pool.contexts.length)];

  // Build syllables
  const syl = word.match(/.{1,2}/g) || [word];
  const phonetic = syl.join(' - ');

  return {
    word,
    syllables: syl,
    phoneticGuide: phonetic,
    clue: `Basahin nang wasto ang salitang "${word}"`,
    readingPassage: `${contextSentence} Pansinin ang salitang "${word}".`,
    distractors: [
      word.split('').reverse().join(''),
      word.slice(0, 2) + 'AN',
      'KA' + word.slice(-2),
    ],
  };
}

// =========================================================================
// Curated Multi-Grade English Reading Pools (Grades 4 to 6)
// DepEd ARAL Program Curated Reading Vocabulary
// =========================================================================
const GRADE_ENGLISH_POOLS: Record<CombatGradeLevel, CuratedReadingItem[]> = {
  4: [
    { word: 'DISCOVER', syllables: ['DIS', 'COV', 'ER'], phoneticGuide: 'dih-SKUV-er', clue: 'To find or learn something new for the first time', readingPassage: 'Scientists discover new stars in the night sky.', distractors: ['RECOVER', 'UNCOVER', 'DELIVER'] },
    { word: 'COMMUNITY', syllables: ['COM', 'MU', 'NI', 'TY'], phoneticGuide: 'kuh-MYOO-nih-tee', clue: 'A group of people living together in one area', readingPassage: 'Neighbors help each other in our peaceful community.', distractors: ['OPPORTUNITY', 'COMMUNICATION', 'SECURITY'] },
    { word: 'ENVIRONMENT', syllables: ['EN', 'VI', 'RON', 'MENT'], phoneticGuide: 'en-VY-run-munt', clue: 'The natural world of land, water, air, and trees', readingPassage: 'We plant green trees to protect our environment.', distractors: ['GOVERNMENT', 'DEVELOPMENT', 'EXPERIMENT'] },
    { word: 'COOPERATION', syllables: ['CO', 'OP', 'ER', 'A', 'TION'], phoneticGuide: 'koh-op-er-AY-shun', clue: 'Working together willingly to achieve a common goal', readingPassage: 'Cooperation among classmates makes group projects fun.', distractors: ['CELEBRATION', 'CONVERSATION', 'OPERATION'] },
    { word: 'CELEBRATION', syllables: ['CEL', 'E', 'BRA', 'TION'], phoneticGuide: 'sel-uh-BRAY-shun', clue: 'A joyful gathering or party for a special event', readingPassage: 'The town held a grand celebration for the harvest.', distractors: ['COOPERATION', 'MEDITATION', 'GENERATION'] },
    { word: 'IMPORTANT', syllables: ['IM', 'POR', 'TANT'], phoneticGuide: 'im-POR-tunt', clue: 'Having great value, significance, or meaning', readingPassage: 'Reading every day is important for learning.', distractors: ['IMPATIENT', 'IMPRESSIVE', 'INVENTOR'] },
  ],
  5: [
    { word: 'RESPONSIBILITY', syllables: ['RE', 'SPON', 'SI', 'BIL', 'I', 'TY'], phoneticGuide: 'rih-spon-suh-BIL-ih-tee', clue: 'A duty or obligation to take care of something', readingPassage: 'Taking care of household chores is my responsibility.', distractors: ['POSSIBILITY', 'ABILITY', 'PRODUCTIVITY'] },
    { word: 'GENEROSITY', syllables: ['GEN', 'ER', 'OS', 'I', 'TY'], phoneticGuide: 'jen-er-OS-ih-tee', clue: 'The quality of being kind and sharing with others', readingPassage: 'Her generosity brought warm meals to hungry families.', distractors: ['CURIOSITY', 'VELOCITY', 'CAPACITY'] },
    { word: 'KNOWLEDGE', syllables: ['KNOWL', 'EDGE'], phoneticGuide: 'NOL-ij', clue: 'Information, skills, and understanding gained by study', readingPassage: 'Reading books expands our knowledge of the world.', distractors: ['COLLEGE', 'COURAGE', 'PACKAGE'] },
    { word: 'APPRECIATION', syllables: ['AP', 'PRE', 'CI', 'A', 'TION'], phoneticGuide: 'uh-pree-shee-AY-shun', clue: 'Recognizing the good qualities of someone or something', readingPassage: 'We expressed deep appreciation to our teachers.', distractors: ['PARTICIPATION', 'ANTICIPATION', 'APPLICATION'] },
    { word: 'COMMUNICATION', syllables: ['COM', 'MU', 'NI', 'CA', 'TION'], phoneticGuide: 'kuh-myoo-nih-KAY-shun', clue: 'Sharing information, thoughts, and feelings clearly', readingPassage: 'Clear communication helps friends solve problems peacefully.', distractors: ['COMMUNITY', 'CONVERSATION', 'CELEBRATION'] },
    { word: 'CONSERVATION', syllables: ['CON', 'SER', 'VA', 'TION'], phoneticGuide: 'kon-ser-VAY-shun', clue: 'Protecting and saving natural resources from waste', readingPassage: 'Water conservation ensures clean water for the future.', distractors: ['CONVERSATION', 'OBSERVATION', 'RESERVATION'] },
  ],
  6: [
    { word: 'PERSEVERANCE', syllables: ['PER', 'SE', 'VER', 'ANCE'], phoneticGuide: 'per-suh-VEER-uns', clue: 'Continuing effort to achieve success despite difficulty', readingPassage: 'Through hard work and perseverance, Maria reached her dream.', distractors: ['PERFORMANCE', 'PREFERENCE', 'IMPORTANCE'] },
    { word: 'CIVILIZATION', syllables: ['CIV', 'I', 'LI', 'ZA', 'TION'], phoneticGuide: 'siv-uh-lih-ZAY-shun', clue: 'An advanced stage of human society and culture', readingPassage: 'Ancient civilizations built great libraries and monuments.', distractors: ['PARTICIPATION', 'CELEBRATION', 'ORGANIZATION'] },
    { word: 'SUSTAINABLE', syllables: ['SUS', 'TAIN', 'A', 'BLE'], phoneticGuide: 'suh-STAY-nuh-bul', clue: 'Able to be maintained without harming the environment', readingPassage: 'Solar energy provides clean and sustainable power.', distractors: ['RELIABLE', 'REMARKABLE', 'VALUABLE'] },
    { word: 'PARTICIPATION', syllables: ['PAR', 'TIC', 'I', 'PA', 'TION'], phoneticGuide: 'par-tis-ih-PAY-shun', clue: 'The action of taking part in an activity or event', readingPassage: 'Active participation in school clubs builds leadership.', distractors: ['CIVILIZATION', 'ANTICIPATION', 'APPRECIATION'] },
    { word: 'EXTRAORDINARY', syllables: ['EX', 'TRAOR', 'DI', 'NAR', 'Y'], phoneticGuide: 'ek-stror-duh-ner-ee', clue: 'Very unusual, remarkable, and beyond the ordinary', readingPassage: 'The young inventor created an extraordinary water filter.', distractors: ['ORDINARY', 'REVOLUTIONARY', 'DISCIPLINARY'] },
    { word: 'BIODIVERSITY', syllables: ['BI', 'O', 'DI', 'VER', 'SI', 'TY'], phoneticGuide: 'by-oh-dy-VER-sih-tee', clue: 'The variety of living plants and animals in an ecosystem', readingPassage: 'Tropical rainforests have rich biodiversity of wildlife.', distractors: ['UNIVERSITY', 'COMMUNITY', 'SECURITY'] },
  ],
};

function generateProceduralEnglishItem(grade: CombatGradeLevel): CuratedReadingItem {
  const englishThemesByGrade: Record<CombatGradeLevel, { words: string[]; contexts: string[] }> = {
    4: {
      words: ['DISCOVER', 'COMMUNITY', 'ENVIRONMENT', 'CELEBRATION', 'COOPERATION', 'IMPORTANT', 'HARVEST'],
      contexts: [
        'Children discover fascinating sea shells along the shore.',
        'Our community gathers every month to clean the park.',
        'Protecting our natural environment is our common duty.',
      ],
    },
    5: {
      words: ['RESPONSIBILITY', 'GENEROSITY', 'KNOWLEDGE', 'APPRECIATION', 'COMMUNICATION', 'CONSERVATION'],
      contexts: [
        'Taking care of younger siblings is a valued family duty.',
        'Books provide limitless knowledge about distant galaxies.',
        'Generosity brings peace and warmth to all people.',
      ],
    },
    6: {
      words: ['PERSEVERANCE', 'CIVILIZATION', 'SUSTAINABLE', 'PARTICIPATION', 'EXTRAORDINARY', 'BIODIVERSITY'],
      contexts: [
        'Through perseverance and steady practice, the athlete succeeded.',
        'Preserving biodiversity maintains balance in our ecosystem.',
        'Active civic participation helps democracy flourish.',
      ],
    },
  };

  const pool = englishThemesByGrade[grade] || englishThemesByGrade[4];
  const word = pool.words[Math.floor(Math.random() * pool.words.length)];
  const context = pool.contexts[Math.floor(Math.random() * pool.contexts.length)];
  const syl = word.match(/.{1,3}/g) || [word];

  return {
    word,
    syllables: syl,
    phoneticGuide: syl.join(' - '),
    clue: `Read and pronounce the word "${word}" carefully`,
    readingPassage: `${context} Focus on the word "${word}".`,
    distractors: [
      word.split('').reverse().join(''),
      word.slice(0, 3) + 'ING',
      'UN' + word.slice(-3),
    ],
  };
}

// =========================================================================
// Procedural Math Question Generator (Grades 4 to 6)
// STRICTLY IN ENGLISH & GROUNDED ENTIRELY IN REAL DAILY LIFE SITUATIONS!
// DepEd ARAL Program Math Focus: multi-digit operations, fractions, decimals, perimeter, area, volume, ratios, PEMDAS.
// =========================================================================
function generateProceduralMathItem(grade: CombatGradeLevel): {
  question: string;
  emoji: string;
  correctAnswer: string;
  distractors: string[];
  explanation: string;
  hint: string;
} {
  const emojis = ['🌾', '🍋', '🪴', '🎒', '🍌', '🪙', '📐', '📦', '🛒', '🍎', '🥛', '📚'];
  const emoji = emojis[Math.floor(Math.random() * emojis.length)];

  if (grade === 4) {
    const type = Math.random();
    if (type < 0.35) {
      // Sacks of rice harvest
      const morning = Math.floor(Math.random() * 50) + 125; // 125 to 174
      const afternoon = Math.floor(Math.random() * 50) + 130; // 130 to 179
      const total = morning + afternoon;
      return {
        question: `A local farmer harvested ${morning} sacks of rice in the morning and ${afternoon} sacks in the afternoon. How many sacks were harvested in total?`,
        emoji: '🌾',
        correctAnswer: `${total} sacks`,
        distractors: [`${total + 10} sacks`, `${total - 10} sacks`, `${total + 20} sacks`],
        explanation: `Add the sacks: ${morning} + ${afternoon} = ${total} sacks.`,
        hint: 'Add the morning and afternoon harvest counts.',
      };
    } else if (type < 0.7) {
      // Measuring liquid in pitcher
      const totalMl = 950;
      const poured = Math.floor(Math.random() * 6) * 50 + 250; // 250 to 500
      const remaining = totalMl - poured;
      return {
        question: `A water pitcher holds ${totalMl} milliliters of fresh lemonade. If Sophia pours ${poured} milliliters for her family, how many milliliters remain?`,
        emoji: '🍋',
        correctAnswer: `${remaining} ml`,
        distractors: [`${remaining + 50} ml`, `${remaining - 50} ml`, `${remaining + 100} ml`],
        explanation: `Subtract poured liquid: ${totalMl} ml - ${poured} ml = ${remaining} ml left.`,
        hint: 'Subtract the poured volume from the initial volume.',
      };
    } else {
      // Garden perimeter
      const length = Math.floor(Math.random() * 5) + 8; // 8 to 12
      const width = Math.floor(Math.random() * 4) + 4;   // 4 to 7
      const perimeter = 2 * (length + width);
      return {
        question: `A rectangular community vegetable garden has a length of ${length} meters and a width of ${width} meters. What is its perimeter?`,
        emoji: '🪴',
        correctAnswer: `${perimeter} meters`,
        distractors: [`${perimeter + 4} meters`, `${length * width} meters`, `${perimeter - 2} meters`],
        explanation: `Perimeter of a rectangle = 2 × (length + width) = 2 × (${length} + ${width}) = ${perimeter} meters.`,
        hint: 'Perimeter formula: P = 2 × (length + width).',
      };
    }
  }

  if (grade === 5) {
    const type = Math.random();
    if (type < 0.35) {
      // Store discount percentage
      const originalPrice = [200, 300, 400, 500][Math.floor(Math.random() * 4)];
      const discountPercent = [10, 20, 25, 50][Math.floor(Math.random() * 4)];
      const discountAmount = (originalPrice * discountPercent) / 100;
      return {
        question: `A student backpack originally priced at ₱${originalPrice} is on sale with a ${discountPercent}% discount. What is the discount amount in pesos?`,
        emoji: '🎒',
        correctAnswer: `₱${discountAmount}`,
        distractors: [`₱${discountAmount + 25}`, `₱${Math.max(10, discountAmount - 20)}`, `₱${discountAmount + 50}`],
        explanation: `${discountPercent}% of ₱${originalPrice} = (${discountPercent} / 100) × ${originalPrice} = ₱${discountAmount}.`,
        hint: 'Multiply the original price by the percentage in decimal form.',
      };
    } else if (type < 0.7) {
      // Fruit weight decimals
      const mangoKg = Math.round((Math.random() * 2 + 1.5) * 10) / 10; // 1.5 to 3.5
      const bananaKg = Math.round((Math.random() * 2 + 1.2) * 10) / 10; // 1.2 to 3.2
      const totalKg = Math.round((mangoKg + bananaKg) * 10) / 10;
      return {
        question: `Sarah bought ${mangoKg} kilograms of ripe mangoes and ${bananaKg} kilograms of bananas at the market. What is the total weight in kilograms?`,
        emoji: '🍌',
        correctAnswer: `${totalKg} kg`,
        distractors: [`${Math.round((totalKg + 0.5) * 10) / 10} kg`, `${Math.round((totalKg - 0.3) * 10) / 10} kg`, `${totalKg + 1} kg`],
        explanation: `Align the decimal points: ${mangoKg} kg + ${bananaKg} kg = ${totalKg} kg.`,
        hint: 'Line up the decimal points when adding decimals.',
      };
    } else {
      // Daily allowance savings
      const daily = [15, 20, 25, 30][Math.floor(Math.random() * 4)];
      const days = [5, 6, 7, 8][Math.floor(Math.random() * 4)];
      const totalSaved = daily * days;
      return {
        question: `Carlos saves ₱${daily} from his daily school allowance every day for ${days} days. How much money did he save in total?`,
        emoji: '🪙',
        correctAnswer: `₱${totalSaved}`,
        distractors: [`₱${totalSaved + daily}`, `₱${totalSaved - daily}`, `₱${totalSaved + 20}`],
        explanation: `Multiply daily savings: ₱${daily} × ${days} days = ₱${totalSaved}.`,
        hint: 'Multiply the daily amount by the number of days.',
      };
    }
  }

  // Grade 6: Real-life ratios, averages, percentages, and grocery budgets
  const type = Math.random();
  if (type < 0.35) {
    // Real-life ratio
    const boysRatio = [2, 3][Math.floor(Math.random() * 2)];
    const girlsRatio = [3, 4, 5][Math.floor(Math.random() * 3)];
    const factor = [4, 5, 6][Math.floor(Math.random() * 3)];
    const boysCount = boysRatio * factor;
    const girlsCount = girlsRatio * factor;
    return {
      question: `In a school music club, the ratio of boys to girls is ${boysRatio} to ${girlsRatio}. If there are ${boysCount} boys, how many girls are in the club?`,
      emoji: '🎵',
      correctAnswer: `${girlsCount} girls`,
      distractors: [`${girlsCount + 2} girls`, `${girlsCount - factor} girls`, `${boysCount + girlsRatio} girls`],
      explanation: `The multiplier is ${boysCount} ÷ ${boysRatio} = ${factor}. Multiply the girls ratio: ${girlsRatio} × ${factor} = ${girlsCount} girls.`,
      hint: 'Find the scaling multiplier by dividing the known quantity by its ratio part.',
    };
  } else if (type < 0.7) {
    // Three-day savings average
    const d1 = 120;
    const d2 = 150;
    const d3 = 180;
    const avg = (d1 + d2 + d3) / 3;
    return {
      question: `Lucas saved ₱${d1} on Monday, ₱${d2} on Tuesday, and ₱${d3} on Wednesday. What is his average daily savings in pesos?`,
      emoji: '📊',
      correctAnswer: `₱${avg}`,
      distractors: [`₱${avg + 15}`, `₱${avg - 10}`, `₱${avg + 25}`],
      explanation: `Add the savings: ₱${d1} + ₱${d2} + ₱${d3} = ₱${d1 + d2 + d3}. Divide by 3 days: ₱${d1 + d2 + d3} ÷ 3 = ₱${avg}.`,
      hint: 'Find the sum of all values, then divide by the number of days.',
    };
  } else {
    // Grocery budget and change
    const bill = 1000;
    const cost = Math.floor(Math.random() * 30) * 5 + 725; // 725 to 870
    const change = bill - cost;
    return {
      question: `Mrs. Santos paid with a ₱${bill} bill for family groceries amounting to ₱${cost}. How much change should she receive?`,
      emoji: '🛒',
      correctAnswer: `₱${change}`,
      distractors: [`₱${change + 10}`, `₱${change - 10}`, `₱${change + 5}`],
      explanation: `Subtract the cost from the cash given: ₱${bill} - ₱${cost} = ₱${change} change.`,
      hint: 'Subtract the total bill from the ₱1,000 banknote.',
    };
  }
}

// =========================================================================
// Helpers & Core Service
// =========================================================================

function shuffleArray<T>(arr: T[]): T[] {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

/**
 * Fetch fresh AI challenges from backend API endpoint with strict non-repetition
 */
export async function requestAiCombatChallenges(params: {
  mode: CombatSubject;
  gradeLevel: CombatGradeLevel;
  count?: number;
}): Promise<CombatChallenge[]> {
  try {
    const { mode, gradeLevel, count = 2 } = params;
    const excludeWords =
      mode === 'english'
        ? Array.from(askedEnglishWordSignatures).slice(-60)
        : Array.from(askedReadingWordSignatures).slice(-60);
    const excludeQuestions = Array.from(askedMathQuestionSignatures).slice(-60);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8500);

    const res = await fetch('/api/ai/combat-challenge', {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mode,
        gradeLevel,
        excludeWords,
        excludeQuestions,
        count,
      }),
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.challenges) && data.challenges.length > 0) {
        const valid: CombatChallenge[] = [];
        for (const item of data.challenges) {
          if (mode === 'english' && (item.targetWord || item.word) && Array.isArray(item.options || item.choices)) {
            const wordUpper = String(item.targetWord || item.word).trim().toUpperCase();
            if (wordUpper.length > 0 && !askedEnglishWordSignatures.has(wordUpper)) {
              const rawOpts = Array.isArray(item.options) ? item.options : item.choices;
              let options = rawOpts.map((o: any) => String(o).trim().toUpperCase());
              if (!options.includes(wordUpper)) {
                options[0] = wordUpper;
              }
              options = Array.from(new Set(options.filter(Boolean)));
              while (options.length < 4) {
                options.push(`WORD-${options.length + 1}`);
              }
              options = shuffleArray(options.slice(0, 4));

              valid.push({
                id: `ai-ec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                mode: 'english',
                gradeLevel,
                targetWord: wordUpper,
                equation: item.readingPassage || wordUpper,
                questionText: item.readingPassage || wordUpper,
                syllables: Array.isArray(item.syllables) && item.syllables.length > 0 ? item.syllables : [wordUpper],
                phoneticGuide: item.phoneticGuide || wordUpper,
                clue: item.clue || 'Read the word aloud or choose the correct spelling',
                readingPassage: item.readingPassage || undefined,
                visualEmoji: '📚',
                options,
                correctAnswer: wordUpper,
                correctIndex: options.indexOf(wordUpper),
                explanation: `Correct! The word is "${wordUpper}".`,
              });
            }
          } else if (mode === 'reading' && (item.targetWord || item.word) && Array.isArray(item.options || item.choices)) {
            const wordUpper = String(item.targetWord || item.word).trim().toUpperCase();
            if (wordUpper.length > 0 && !askedReadingWordSignatures.has(wordUpper)) {
              const rawOpts = Array.isArray(item.options) ? item.options : item.choices;
              let options = rawOpts.map((o: any) => String(o).trim().toUpperCase());
              if (!options.includes(wordUpper)) {
                options[0] = wordUpper;
              }
              options = Array.from(new Set(options.filter(Boolean)));
              while (options.length < 4) {
                options.push(`PAGBASA-${options.length + 1}`);
              }
              options = shuffleArray(options.slice(0, 4));

              valid.push({
                id: `ai-rc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                mode: 'reading',
                gradeLevel,
                targetWord: wordUpper,
                equation: item.readingPassage || wordUpper,
                questionText: item.readingPassage || wordUpper,
                syllables: Array.isArray(item.syllables) && item.syllables.length > 0 ? item.syllables : [wordUpper],
                phoneticGuide: item.phoneticGuide || wordUpper,
                clue: item.clue || 'Basahin nang wasto ang salita',
                readingPassage: item.readingPassage || undefined,
                visualEmoji: '📖',
                options,
                correctAnswer: wordUpper,
                correctIndex: options.indexOf(wordUpper),
                explanation: `Tama ang pagbasa sa salitang "${wordUpper}"!`,
              });
            }
          } else if (
            mode === 'math' &&
            (item.mathQuestion || item.question || item.problem || item.equation || item.questionText)
          ) {
            const qStr = String(
              item.mathQuestion || item.question || item.problem || item.equation || item.questionText || ''
            ).trim();
            const correctStr = String(
              item.correctAnswer !== undefined ? item.correctAnswer : (item.answer !== undefined ? item.answer : '')
            ).trim();

            if (qStr.length > 0 && correctStr.length > 0 && !askedMathQuestionSignatures.has(qStr.toLowerCase())) {
              const rawOpts = Array.isArray(item.options)
                ? item.options
                : Array.isArray(item.choices)
                ? item.choices
                : [];
              let options = rawOpts.map((o: any) => String(o).trim());
              if (!options.includes(correctStr)) {
                options.unshift(correctStr);
              }
              options = Array.from(new Set(options.filter(Boolean)));
              while (options.length < 4) {
                const numeric = parseFloat(correctStr);
                if (!isNaN(numeric)) {
                  options.push(`${numeric + options.length}`);
                } else {
                  options.push(`Choice ${options.length + 1}`);
                }
              }
              options = shuffleArray(options.slice(0, 4));

              valid.push({
                id: `ai-mc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                mode: 'math',
                gradeLevel,
                mathQuestion: qStr,
                equation: qStr,
                questionText: qStr,
                mathEmoji: item.mathEmoji || item.emoji || '🍎',
                visualEmoji: item.mathEmoji || item.emoji || '🍎',
                mathHint: item.mathHint || item.hint || 'Solve the real-life math problem carefully.',
                clue: item.mathHint || item.hint || 'Solve the real-life math problem carefully.',
                options,
                correctAnswer: correctStr,
                correctIndex: options.indexOf(correctStr),
                explanation: item.explanation || `The correct answer is ${correctStr}.`,
              });
            }
          }
        }
        return valid;
      }
    }
  } catch (err) {
    console.warn('[AI Combat Challenge] Fetch fallback:', err);
  }
  return [];
}

/**
 * Pre-fetch challenges in the background for zero-latency combat turns
 */
export async function prefetchCombatChallenges(
  mode: CombatSubject,
  gradeLevel: CombatGradeLevel
): Promise<void> {
  const queue =
    mode === 'english'
      ? englishQueues.get(gradeLevel)
      : mode === 'reading'
      ? readingQueues.get(gradeLevel)
      : mathQueues.get(gradeLevel);

  if (!queue || queue.length >= 3) return;

  if (mode === 'english') {
    if (isPrefetchingEnglish) return;
    isPrefetchingEnglish = true;
    try {
      const fresh = await requestAiCombatChallenges({ mode: 'english', gradeLevel, count: 2 });
      fresh.forEach((f) => queue.push(f));
    } finally {
      isPrefetchingEnglish = false;
    }
  } else if (mode === 'reading') {
    if (isPrefetchingReading) return;
    isPrefetchingReading = true;
    try {
      const fresh = await requestAiCombatChallenges({ mode: 'reading', gradeLevel, count: 2 });
      fresh.forEach((f) => queue.push(f));
    } finally {
      isPrefetchingReading = false;
    }
  } else {
    if (isPrefetchingMath) return;
    isPrefetchingMath = true;
    try {
      const fresh = await requestAiCombatChallenges({ mode: 'math', gradeLevel, count: 2 });
      fresh.forEach((f) => queue.push(f));
    } finally {
      isPrefetchingMath = false;
    }
  }
}

/**
 * Get a guaranteed fresh, NON-REPEATING combat challenge for Reading, English, or Math.
 * Prioritizes AI generation with strict anti-repetition tracking.
 */
export async function getCombatChallenge(params: {
  mode: CombatSubject;
  gradeLevel: CombatGradeLevel;
  attackTitle?: string;
  attackIcon?: string;
  forceFreshAi?: boolean;
}): Promise<CombatChallenge> {
  const { mode, gradeLevel, forceFreshAi = false } = params;

  // 1. If not forcing fresh, check pre-fetched AI challenge queue for instant zero-latency turn
  const queue =
    mode === 'english'
      ? englishQueues.get(gradeLevel)
      : mode === 'reading'
      ? readingQueues.get(gradeLevel)
      : mathQueues.get(gradeLevel);

  if (!forceFreshAi && queue && queue.length > 0) {
    while (queue.length > 0) {
      const candidate = queue.shift()!;
      if (mode === 'english' && candidate.targetWord) {
        if (!askedEnglishWordSignatures.has(candidate.targetWord.toUpperCase())) {
          askedEnglishWordSignatures.add(candidate.targetWord.toUpperCase());
          if (candidate.readingPassage) {
            askedEnglishPassageSignatures.add(candidate.readingPassage.toLowerCase());
          }
          setTimeout(() => prefetchCombatChallenges(mode, gradeLevel), 300);
          return candidate;
        }
      } else if (mode === 'reading' && candidate.targetWord) {
        if (!askedReadingWordSignatures.has(candidate.targetWord.toUpperCase())) {
          askedReadingWordSignatures.add(candidate.targetWord.toUpperCase());
          if (candidate.readingPassage) {
            askedReadingPassageSignatures.add(candidate.readingPassage.toLowerCase());
          }
          setTimeout(() => prefetchCombatChallenges(mode, gradeLevel), 300);
          return candidate;
        }
      } else if (mode === 'math' && candidate.mathQuestion) {
        if (!askedMathQuestionSignatures.has(candidate.mathQuestion.toLowerCase())) {
          askedMathQuestionSignatures.add(candidate.mathQuestion.toLowerCase());
          setTimeout(() => prefetchCombatChallenges(mode, gradeLevel), 300);
          return candidate;
        }
      }
    }
  }

  // 2. If queue empty or forceFreshAi requested, try on-demand AI call with 2.2s quick timeout
  try {
    const aiFresh = await Promise.race([
      requestAiCombatChallenges({ mode, gradeLevel, count: 2 }),
      new Promise<CombatChallenge[]>((resolve) => setTimeout(() => resolve([]), 2200)),
    ]);

    if (aiFresh && aiFresh.length > 0) {
      const picked = aiFresh[0];
      if (mode === 'english' && picked.targetWord) {
        askedEnglishWordSignatures.add(picked.targetWord.toUpperCase());
        if (picked.readingPassage) {
          askedEnglishPassageSignatures.add(picked.readingPassage.toLowerCase());
        }
      } else if (mode === 'reading' && picked.targetWord) {
        askedReadingWordSignatures.add(picked.targetWord.toUpperCase());
        if (picked.readingPassage) {
          askedReadingPassageSignatures.add(picked.readingPassage.toLowerCase());
        }
      } else if (mode === 'math' && picked.mathQuestion) {
        askedMathQuestionSignatures.add(picked.mathQuestion.toLowerCase());
      }
      // Put remaining in queue
      if (aiFresh.length > 1 && queue) {
        aiFresh.slice(1).forEach((item) => queue.push(item));
      }
      return picked;
    }
  } catch (err) {
    console.warn('[AI Combat Challenge] Quick fetch skipped:', err);
  }

  // 3. Fallback to rich curated pools or procedural engine with STRICT NON-REPETITION
  if (mode === 'english') {
    const pool = GRADE_ENGLISH_POOLS[gradeLevel] || GRADE_ENGLISH_POOLS[4];
    let candidates = pool.filter((item) => !askedEnglishWordSignatures.has(item.word.toUpperCase()));

    // If grade pool exhausted, pull unasked from other grades (4, 5, 6)
    if (candidates.length === 0) {
      for (const g of [4, 5, 6] as CombatGradeLevel[]) {
        const otherPool = GRADE_ENGLISH_POOLS[g] || [];
        candidates = otherPool.filter((item) => !askedEnglishWordSignatures.has(item.word.toUpperCase()));
        if (candidates.length > 0) break;
      }
    }

    let picked: CuratedReadingItem;
    if (candidates.length > 0) {
      picked = candidates[Math.floor(Math.random() * candidates.length)];
    } else {
      picked = generateProceduralEnglishItem(gradeLevel);
    }

    askedEnglishWordSignatures.add(picked.word.toUpperCase());
    if (picked.readingPassage) {
      askedEnglishPassageSignatures.add(picked.readingPassage.toLowerCase());
    }

    const rawOptions = [picked.word, ...picked.distractors];
    const options = shuffleArray(Array.from(new Set(rawOptions))).slice(0, 4);

    const challenge: CombatChallenge = {
      id: `local-ec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      mode: 'english',
      gradeLevel,
      targetWord: picked.word,
      equation: picked.readingPassage || picked.word,
      questionText: picked.readingPassage || picked.word,
      syllables: picked.syllables,
      phoneticGuide: picked.phoneticGuide,
      clue: picked.clue,
      readingPassage: picked.readingPassage,
      visualEmoji: '📚',
      options,
      correctAnswer: picked.word,
      correctIndex: options.indexOf(picked.word),
      explanation: `🎉 Excellent! The word is "${picked.word}".`,
    };

    setTimeout(() => prefetchCombatChallenges('english', gradeLevel), 200);
    return challenge;
  } else if (mode === 'reading') {
    const pool = GRADE_READING_POOLS[gradeLevel] || GRADE_READING_POOLS[4];
    let candidates = pool.filter((item) => !askedReadingWordSignatures.has(item.word.toUpperCase()));

    // If grade pool exhausted, pull unasked from other grades (4, 5, 6)
    if (candidates.length === 0) {
      for (const g of [4, 5, 6] as CombatGradeLevel[]) {
        const otherPool = GRADE_READING_POOLS[g] || [];
        candidates = otherPool.filter((item) => !askedReadingWordSignatures.has(item.word.toUpperCase()));
        if (candidates.length > 0) break;
      }
    }

    let picked: CuratedReadingItem;
    if (candidates.length > 0) {
      picked = candidates[Math.floor(Math.random() * candidates.length)];
    } else {
      picked = generateProceduralReadingItem(gradeLevel);
    }

    askedReadingWordSignatures.add(picked.word.toUpperCase());
    if (picked.readingPassage) {
      askedReadingPassageSignatures.add(picked.readingPassage.toLowerCase());
    }

    const rawOptions = [picked.word, ...picked.distractors];
    const options = shuffleArray(Array.from(new Set(rawOptions))).slice(0, 4);

    const challenge: CombatChallenge = {
      id: `local-rc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      mode: 'reading',
      gradeLevel,
      targetWord: picked.word,
      equation: picked.readingPassage || picked.word,
      questionText: picked.readingPassage || picked.word,
      syllables: picked.syllables,
      phoneticGuide: picked.phoneticGuide,
      clue: picked.clue,
      readingPassage: picked.readingPassage,
      visualEmoji: '📖',
      options,
      correctAnswer: picked.word,
      correctIndex: options.indexOf(picked.word),
      explanation: `🎉 Tumpak! Ang wastong baybay at bigkas ay "${picked.word}".`,
    };

    setTimeout(() => prefetchCombatChallenges('reading', gradeLevel), 200);
    return challenge;
  } else {
    // Mode === 'math' -> 100% English & Daily Life Situations (Zero game mechanics!)
    let attempts = 0;
    let mathData: {
      question: string;
      emoji: string;
      correctAnswer: string;
      distractors: string[];
      explanation: string;
      hint: string;
    };

    do {
      mathData = generateProceduralMathItem(gradeLevel);
      attempts++;
    } while (askedMathQuestionSignatures.has(mathData.question.toLowerCase()) && attempts < 20);

    askedMathQuestionSignatures.add(mathData.question.toLowerCase());

    const rawOptions = [mathData.correctAnswer, ...mathData.distractors];
    const options = shuffleArray(Array.from(new Set(rawOptions))).slice(0, 4);

    const challenge: CombatChallenge = {
      id: `local-mc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      mode: 'math',
      gradeLevel,
      mathQuestion: mathData.question,
      equation: mathData.question,
      questionText: mathData.question,
      mathEmoji: mathData.emoji,
      visualEmoji: mathData.emoji,
      mathHint: mathData.hint,
      clue: mathData.hint,
      options,
      correctAnswer: mathData.correctAnswer,
      correctIndex: options.indexOf(mathData.correctAnswer),
      explanation: mathData.explanation,
    };

    setTimeout(() => prefetchCombatChallenges('math', gradeLevel), 200);
    return challenge;
  }
}

/**
 * Reset asked history if user explicitly starts a new game session
 */
export function resetCombatChallengeHistory(): void {
  askedReadingWordSignatures.clear();
  askedReadingPassageSignatures.clear();
  askedEnglishWordSignatures.clear();
  askedEnglishPassageSignatures.clear();
  askedMathQuestionSignatures.clear();
  readingQueues.forEach((q) => (q.length = 0));
  englishQueues.forEach((q) => (q.length = 0));
  mathQueues.forEach((q) => (q.length = 0));
}
