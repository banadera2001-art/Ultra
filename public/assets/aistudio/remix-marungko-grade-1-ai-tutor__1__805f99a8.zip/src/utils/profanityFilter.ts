/**
 * Comprehensive Filipino & English Profanity and Bad Word Censor
 * Used for Blox Fruit multiplayer chat and pet arena interactions.
 */

// Common Filipino/Tagalog vulgarities, curses, and derogatory terms
const FILIPINO_BAD_WORDS: string[] = [
  'gago',
  'gaga',
  'tanga',
  'tarantado',
  'tarantada',
  'ulol',
  'gunggong',
  'putangina',
  'tangina',
  'tangena',
  'tang ina',
  'putang ina',
  'puta',
  'pakshet',
  'pakyu',
  'pakyawin',
  'leche',
  'letse',
  'bwisit',
  'buwisit',
  'punyeta',
  'inutil',
  'peste',
  'pesteng yawa',
  'yawa',
  'hayop ka',
  'tarantado ka',
  'gago ka',
  'tite',
  'bayag',
  'pekpek',
  'bilat',
  'puke',
  'burat',
  'tamod',
  'kantot',
  'kantutan',
  'chupa',
  'jakol',
  'kupal',
  'hudas',
  'pokpok',
  'putragis',
  'hindot',
  'hinayupak',
  'bobo',
  'engot',
];

// Common English vulgarities and offensive slurs
const ENGLISH_BAD_WORDS: string[] = [
  'fuck',
  'fucking',
  'fucked',
  'fucker',
  'fuk',
  'shit',
  'bullshit',
  'bitch',
  'bitches',
  'bitching',
  'asshole',
  'ass',
  'bastard',
  'cunt',
  'dick',
  'pussy',
  'cock',
  'slut',
  'whore',
  'nigger',
  'nigga',
  'fag',
  'faggot',
  'crap',
  'damn',
  'motherfucker',
];

// Combined list
const ALL_BAD_WORDS = Array.from(new Set([...FILIPINO_BAD_WORDS, ...ENGLISH_BAD_WORDS]));

// Leetspeak character mapping
const LEET_MAP: Record<string, string> = {
  '@': 'a',
  '4': 'a',
  '8': 'b',
  '3': 'e',
  '1': 'i',
  '!': 'i',
  '0': 'o',
  '$': 's',
  '5': 's',
  '7': 't',
  '+': 't',
  'v': 'u',
};

/**
 * Normalize text to detect obfuscated words (e.g. g@g0, t@ng4, f*ck)
 */
function normalizeForProfanity(str: string): string {
  let s = str.toLowerCase();
  for (const [leet, char] of Object.entries(LEET_MAP)) {
    s = s.split(leet).join(char);
  }
  // Strip non-alphanumeric except spaces
  return s.replace(/[^a-z0-9\s]/g, '');
}

/**
 * Filter and censor bad words in text, replacing bad words with asterisks (e.g. ****)
 */
export function censorProfanity(text: string): string {
  if (!text || typeof text !== 'string') return '';

  let censored = text;

  // 1. Direct word boundary matching for explicit bad words (case-insensitive)
  for (const word of ALL_BAD_WORDS) {
    // Regex matching whole word or space-separated variations
    const escapedWord = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`\\b${escapedWord}\\b`, 'gi');
    censored = censored.replace(regex, (match) => '*'.repeat(match.length));

    // Also match space-compressed or punctuated versions (e.g. "p u t a" or "g-a-g-o")
    if (word.length >= 3) {
      const spacedRegex = new RegExp(
        escapedWord.split('').join('[\\s._\\-*~]+'),
        'gi'
      );
      censored = censored.replace(spacedRegex, (match) => '*'.repeat(match.length));
    }
  }

  // 2. Also check leetspeak variations
  const words = censored.split(/\s+/);
  const cleanWords = words.map((w) => {
    const normalized = normalizeForProfanity(w);
    for (const bad of ALL_BAD_WORDS) {
      if (normalized === bad || (bad.length >= 4 && normalized.includes(bad))) {
        return '*'.repeat(w.length);
      }
    }
    return w;
  });

  return cleanWords.join(' ');
}

/**
 * Check if a text contains any profanity
 */
export function containsProfanity(text: string): boolean {
  if (!text) return false;
  const censored = censorProfanity(text);
  return censored !== text;
}
